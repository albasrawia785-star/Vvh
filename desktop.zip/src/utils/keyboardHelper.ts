import React, { useEffect } from 'react';

/**
 * Handles smooth auto-scrolling of focused input elements on mobile devices
 * when the soft keyboard expands, keeping the active field in the middle of the viewport.
 */
export const handleInputFocus = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => {
  const target = e.currentTarget;
  // Delay slightly to let the soft keyboard animation complete on iOS/Android
  setTimeout(() => {
    target.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, 220);
};

/**
 * React hook that listens to visualViewport resize events (triggered by soft keyboard)
 * and ensures active input fields remain visible above the keyboard.
 */
export const useModalKeyboardAdjust = (isOpen: boolean) => {
  useEffect(() => {
    if (!isOpen) return;

    const handleViewportResize = () => {
      const activeEl = document.activeElement;
      if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {
        (activeEl as HTMLElement).scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    };

    const vv = window.visualViewport;
    if (vv) {
      vv.addEventListener('resize', handleViewportResize);
      return () => vv.removeEventListener('resize', handleViewportResize);
    }
  }, [isOpen]);
};
