import React from 'react';
import { InstallmentRecord } from '../types';
import { formatNumber, formatDateDigits } from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';

interface InstallmentDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  installment: InstallmentRecord;
  onOpenSettleModal: (installment: InstallmentRecord) => void;
  onOpenEditModal?: (installment: InstallmentRecord) => void;
  onDelete: (id: number) => void;
}

export const InstallmentDetailsModal: React.FC<InstallmentDetailsModalProps> = ({
  isOpen,
  onClose,
  installment,
  onOpenSettleModal,
  onOpenEditModal,
  onDelete,
}) => {
  const { t, numberFormat, currency } = useI18n();
  if (!isOpen) return null;

  const totalPaid = installment.totalAmount - installment.remainingAmount;
  const progressPercent = Math.min(100, Math.round((totalPaid / (installment.totalAmount || 1)) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/60 backdrop-blur-xs p-0 sm:p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-100 flex flex-col max-h-[92dvh] overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <i className="fa-solid fa-file-invoice text-base"></i>
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight">{installment.name}</h2>
              <p className="text-[11px] text-slate-300 flex items-center gap-1.5 mt-0.5">
                <span>{installment.item}</span>
                {installment.phone && (
                  <>
                    <span>•</span>
                    <span dir="ltr" className="font-mono text-emerald-300">{formatDateDigits(installment.phone, numberFormat)}</span>
                  </>
                )}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            {onOpenEditModal && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenEditModal(installment);
                }}
                className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-emerald-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                title={t('common.edit', 'تعديل')}
              >
                <i className="fa-solid fa-pen-to-square text-xs"></i>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-white/80 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            >
              <i className="fa-solid fa-xmark text-sm"></i>
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Main Financial Card */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-white p-3 rounded-xl border border-slate-100">
                <span className="text-slate-400 text-[10.5px] block font-medium">{t('installments.totalAmount', 'مبلغ الأقساط الإجمالي')}</span>
                <span className="text-sm font-black text-slate-800 font-mono mt-0.5 block">
                  {formatNumber(installment.totalAmount, numberFormat)} <span className="text-[10px] font-normal text-slate-500">{currency}</span>
                </span>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-100">
                <span className="text-slate-400 text-[10.5px] block font-medium">{t('installments.downPayment', 'الدفعة المقدمة')}</span>
                <span className="text-sm font-black text-teal-700 font-mono mt-0.5 block">
                  {formatNumber(installment.downPayment, numberFormat)} <span className="text-[10px] font-normal text-slate-500">{currency}</span>
                </span>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-100">
                <span className="text-slate-400 text-[10.5px] block font-medium">{t('installments.paidAmount', 'إجمالي المسدد')}</span>
                <span className="text-sm font-black text-emerald-700 font-mono mt-0.5 block">
                  {formatNumber(totalPaid, numberFormat)} <span className="text-[10px] font-normal text-slate-500">{currency}</span>
                </span>
              </div>

              <div className={`p-3 rounded-xl border ${
                installment.remainingAmount <= 0
                  ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                  : 'bg-rose-50/70 border-rose-200 text-rose-900'
              }`}>
                <span className="text-[10.5px] block font-bold">{t('installments.remainingAmount', 'المتبقي المطلوب')}</span>
                <span className="text-sm font-black font-mono mt-0.5 block">
                  {formatNumber(installment.remainingAmount, numberFormat)} <span className="text-[10px] font-normal">{currency}</span>
                </span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="space-y-1.5 pt-1">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-600">
                <span>{t('installments.progressStatus', 'نسبة الإنجاز وسداد القسط')}</span>
                <span className="font-mono text-emerald-700">
                  {formatNumber(progressPercent, numberFormat)}%
                </span>
              </div>
              <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-teal-500 to-emerald-600 transition-all duration-300 rounded-full"
                  style={{ width: `${progressPercent}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Customer Identification & Address Info */}
          {(installment.nationalId || installment.address) && (
            <div className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-2.5 text-xs">
              <h3 className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                <i className="fa-solid fa-id-card-clip text-emerald-600"></i>
                <span>{t('installments.idAndAddress', 'بيانات التعريف والعنوان')}</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {installment.nationalId && (
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-[10.5px] text-slate-400 block font-medium">{t('debtors.nationalId', 'رقم البطاقة الوطنية')}</span>
                    <span className="font-mono font-bold text-slate-800 text-xs mt-0.5 block" dir="ltr">
                      {formatDateDigits(installment.nationalId, numberFormat)}
                    </span>
                  </div>
                )}

                {installment.address && (
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 sm:col-span-2">
                    <span className="text-[10.5px] text-slate-400 block font-medium">{t('debtors.address', 'عنوان السكن')}</span>
                    <span className="font-semibold text-slate-800 text-xs mt-0.5 block">
                      {installment.address}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Guarantor Info */}
          {(installment.guarantorEnabled || installment.guarantorName) && (
            <div className="p-3.5 rounded-2xl bg-purple-50/60 border border-purple-200/80 shadow-xs space-y-2.5 text-xs">
              <div className="flex items-center justify-between">
                <h3 className="font-black text-purple-900 flex items-center gap-1.5 text-xs">
                  <i className="fa-solid fa-user-shield text-purple-600"></i>
                  <span>{t('installments.guarantorInfo', 'بيانات الكفيل والضامن')}</span>
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 text-[10px] font-bold">
                  {t('installments.guarantor', 'الكفيل')}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {installment.guarantorName && (
                  <div className="p-2.5 rounded-xl bg-white border border-purple-100">
                    <span className="text-[10px] text-slate-400 block font-medium">{t('installments.guarantorName', 'اسم الكفيل')}</span>
                    <span className="font-bold text-purple-950 text-xs mt-0.5 block">
                      {installment.guarantorName}
                    </span>
                  </div>
                )}

                {installment.guarantorRelation && (
                  <div className="p-2.5 rounded-xl bg-white border border-purple-100">
                    <span className="text-[10px] text-slate-400 block font-medium">{t('installments.guarantorRelation', 'صلة القرابة')}</span>
                    <span className="font-bold text-slate-800 text-xs mt-0.5 block">
                      {installment.guarantorRelation}
                    </span>
                  </div>
                )}

                {installment.guarantorJob && (
                  <div className="p-2.5 rounded-xl bg-white border border-purple-100">
                    <span className="text-[10px] text-slate-400 block font-medium">{t('installments.guarantorJob', 'مهنة الكفيل')}</span>
                    <span className="font-semibold text-slate-800 text-xs mt-0.5 block">
                      {installment.guarantorJob}
                    </span>
                  </div>
                )}

                {installment.guarantorPhone && (
                  <div className="p-2.5 rounded-xl bg-white border border-purple-100 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-medium">{t('installments.guarantorPhone', 'هاتف الكفيل')}</span>
                      <span className="font-mono font-bold text-emerald-700 text-xs mt-0.5 block" dir="ltr">
                        {formatDateDigits(installment.guarantorPhone, numberFormat)}
                      </span>
                    </div>
                    <a
                      href={`tel:${installment.guarantorPhone}`}
                      className="w-7 h-7 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 flex items-center justify-center text-xs transition-colors"
                      title={t('debtors.callPhone', 'اتصال بالكفيل')}
                    >
                      <i className="fa-solid fa-phone"></i>
                    </a>
                  </div>
                )}

                {installment.guarantorAddress && (
                  <div className="p-2.5 rounded-xl bg-white border border-purple-100 sm:col-span-2">
                    <span className="text-[10px] text-slate-400 block font-medium">{t('installments.guarantorAddress', 'عنوان الكفيل')}</span>
                    <span className="font-semibold text-slate-800 text-xs mt-0.5 block">
                      {installment.guarantorAddress}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Dates Info */}
          <div className="grid grid-cols-2 gap-2.5 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-2.5">
              <i className="fa-solid fa-calendar-plus text-slate-400 text-sm"></i>
              <div>
                <span className="text-[10.5px] text-slate-400 block">{t('installments.registrationDate', 'تاريخ التسجيل')}</span>
                <span className="font-bold text-slate-700 font-mono block">{formatDateDigits(installment.registrationDate, numberFormat)}</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-2.5">
              <i className="fa-solid fa-calendar-check text-emerald-600 text-sm"></i>
              <div>
                <span className="text-[10.5px] text-slate-400 block">{t('installments.dueDate', 'تاريخ الاستحقاق')}</span>
                <span className="font-bold text-slate-800 font-mono block">{formatDateDigits(installment.nextDueDate, numberFormat)}</span>
              </div>
            </div>
          </div>

          {installment.notes && (
            <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200/80 text-xs text-amber-900">
              <span className="font-bold mb-0.5 flex items-center gap-1">
                <i className="fa-solid fa-note-sticky text-amber-700 text-xs"></i>
                <span>{t('common.notes', 'ملاحظات')}:</span>
              </span>
              <p className="text-[11.5px] leading-relaxed text-amber-950 font-medium">{installment.notes}</p>
            </div>
          )}

          {/* Payments History */}
          <div className="space-y-2">
            <h3 className="text-xs font-black text-slate-800 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <i className="fa-solid fa-clock-rotate-left text-teal-600 text-xs"></i>
                <span>{t('installments.paymentsHistory', 'سجل الدفعات والتسديدات')}</span>
              </span>
              <span className="text-[10.5px] font-normal text-slate-400 font-mono">
                ({formatNumber(installment.payments?.length || 0, numberFormat)})
              </span>
            </h3>

            {installment.payments && installment.payments.length > 0 ? (
              <div className="divide-y divide-slate-100 rounded-xl border border-slate-100 bg-white overflow-hidden max-h-44 overflow-y-auto">
                {installment.payments.map((p, idx) => (
                  <div key={p.id || idx} className="p-2.5 flex items-center justify-between text-xs hover:bg-slate-50">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center text-xs font-bold shrink-0">
                        <i className="fa-solid fa-arrow-down-left"></i>
                      </div>
                      <div>
                        <span className="font-black text-slate-800 block">
                          +{formatNumber(p.amount, numberFormat)} <span className="text-[10px] font-normal text-slate-500">{currency}</span>
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono block">
                          {formatDateDigits(p.date, numberFormat)} {p.notes ? `• ${p.notes}` : ''}
                        </span>
                      </div>
                    </div>
                    <div className="text-end">
                      <span className="text-[10px] text-slate-400 block">{t('installments.remainingAmount', 'المتبقي')}</span>
                      <span className="text-[11px] font-bold text-slate-600 font-mono">
                        {formatNumber(p.remainingAfter, numberFormat)} {currency}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 text-center rounded-xl bg-slate-50 border border-dashed border-slate-200 text-slate-400 text-xs">
                {t('installments.noPaymentsYet', 'لم يتم تسجيل أي دفعات إضافية بعد')}
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center gap-2 shrink-0">
          {installment.remainingAmount > 0 && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenSettleModal(installment);
              }}
              className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer shadow-xs"
            >
              <i className="fa-solid fa-hand-holding-dollar text-xs"></i>
              <span>{t('installments.payInstallment', 'تسديد قسط')}</span>
            </button>
          )}

          {onOpenEditModal && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenEditModal(installment);
              }}
              className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
              title={t('common.edit', 'تعديل')}
            >
              <i className="fa-solid fa-pen-to-square text-xs text-emerald-600"></i>
              <span>{t('common.edit', 'تعديل')}</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              onClose();
              onDelete(installment.id);
            }}
            className="py-2.5 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
            title={t('common.delete', 'حذف')}
          >
            <i className="fa-solid fa-trash-can text-xs"></i>
            <span>{t('common.delete', 'حذف')}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="py-2.5 px-4 rounded-xl bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
          >
            {t('common.close', 'إغلاق')}
          </button>
        </div>
      </div>
    </div>
  );
};

