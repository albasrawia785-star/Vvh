import React from 'react';
import { useI18n } from '../i18n/index.tsx';

interface ConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  onConfirm: () => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  title,
  message,
  confirmText,
  cancelText,
  onConfirm,
  onCancel,
  isLoading = false
}) => {
  const { t, dir } = useI18n();
  if (!isOpen) return null;

  const defaultConfirmText = confirmText || t('common.confirmDelete', "نعم، تأكيد الحذف");
  const defaultCancelText = cancelText || t('common.cancel', "إلغاء");

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex justify-center items-center z-50 p-4 animate-in fade-in duration-150" dir={dir}>
      <div className="bg-white rounded-3xl w-full max-w-sm p-6 shadow-2xl relative border border-slate-100 text-center">
        <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center text-lg mx-auto mb-3">
          <i className="fa-regular fa-trash-can"></i>
        </div>

        <h3 className="font-bold text-base text-slate-800 mb-1.5">{title}</h3>
        <p className="text-xs text-slate-500 mb-5 leading-relaxed">{message}</p>

        <div className="flex gap-2">
          <button
            type="button"
            onClick={onConfirm}
            disabled={isLoading}
            className="flex-1 bg-red-600 hover:bg-red-700 active:scale-95 text-white py-2.5 rounded-xl font-bold text-xs shadow-md shadow-red-500/20 cursor-pointer transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <i className="fa-solid fa-spinner fa-spin"></i>
                <span>{t('common.deleting', 'جاري الحذف...')}</span>
              </>
            ) : (
              <span>{defaultConfirmText}</span>
            )}
          </button>

          <button
            type="button"
            onClick={onCancel}
            disabled={isLoading}
            className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 py-2.5 rounded-xl font-bold text-xs cursor-pointer transition-all"
          >
            {defaultCancelText}
          </button>
        </div>
      </div>
    </div>
  );
};
