import React from 'react';
import { TabType, User } from '../types';
import { useI18n } from '../i18n/index.tsx';
import { formatNumber } from '../utils/formatters';
import { getUserRoleDisplayName } from '../utils/userUtils';

interface SidebarNavProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
  onOpenAddModal?: () => void;
  currentUser: User;
  overdueCount?: number;
  dueInstallmentsCount?: number;
  mode?: 'debts' | 'installments';
  onLogout: () => void;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  activeTab,
  onSelectTab,
  onOpenAddModal,
  currentUser,
  overdueCount = 0,
  dueInstallmentsCount = 0,
  mode = 'debts',
  onLogout,
}) => {
  const { t, numberFormat } = useI18n();
  const isInstallments = mode === 'installments';
  const activeOverdueBadgeCount = isInstallments ? dueInstallmentsCount : overdueCount;

  const navItems: {
    id: TabType;
    label: string;
    icon: string;
    badge?: number;
  }[] = [
    {
      id: 'home',
      label: isInstallments ? t('nav.installments', 'الأقساط') : t('nav.home', 'دفتر الديون'),
      icon: isInstallments ? 'fa-solid fa-file-invoice-dollar' : 'fa-solid fa-house-chimney',
    },
    {
      id: 'overdue',
      label: t('nav.overdue', 'المتأخرون'),
      icon: 'fa-solid fa-hourglass-half',
      badge: activeOverdueBadgeCount,
    },
    {
      id: 'reports',
      label: t('nav.reports', 'التقارير والإحصائيات'),
      icon: 'fa-solid fa-chart-simple',
    },
    ...(currentUser.role === 'admin'
      ? [
          {
            id: 'managers' as TabType,
            label: t('nav.managers', 'إدارة المدراء والفروع'),
            icon: 'fa-solid fa-users-gear',
          },
        ]
      : []),
    {
      id: 'settings',
      label: t('nav.settings', 'الإعدادات والنسخ'),
      icon: 'fa-solid fa-gear',
    },
  ];

  return (
    <aside
      className="hidden md:flex flex-col w-64 lg:w-72 bg-slate-900 text-slate-100 border-e border-slate-800 shrink-0 select-none h-full z-30 shadow-xl"
      aria-label="Sidebar Navigation"
    >
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-3 min-w-0">
          <div
            className={`w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-md shrink-0 ${
              isInstallments
                ? 'bg-gradient-to-tr from-emerald-600 to-teal-500'
                : 'bg-gradient-to-tr from-blue-600 to-indigo-500'
            }`}
          >
            <i className={isInstallments ? 'fa-solid fa-coins text-lg' : 'fa-solid fa-book-bookmark text-lg'}></i>
          </div>
          <div className="min-w-0">
            <h2 className="font-black text-sm lg:text-base text-white tracking-tight truncate">
              {isInstallments ? t('app.installmentsTitle', 'نظام الأقساط') : t('app.title', 'دفتر الديون السحابي')}
            </h2>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-[11px] text-slate-400 font-medium truncate">
                {currentUser.name} ({getUserRoleDisplayName(currentUser, t)})
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Button: Quick Add */}
      <div className="p-4">
        <button
          type="button"
          onClick={onOpenAddModal}
          className={`w-full py-3 px-4 rounded-xl text-white font-bold text-sm flex items-center justify-center gap-2.5 shadow-lg transition-all transform active:scale-95 cursor-pointer ${
            isInstallments
              ? 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-950/40'
              : 'bg-blue-600 hover:bg-blue-500 shadow-blue-950/40'
          }`}
        >
          <i className="fa-solid fa-plus text-base"></i>
          <span>{isInstallments ? t('installments.addInstallment', 'إضافة قسط جديد') : t('debtors.addDebtor', 'إضافة مدين جديد')}</span>
        </button>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 px-3 py-2 space-y-1.5 overflow-y-auto custom-scrollbar">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-bold transition-all cursor-pointer ${
                isActive
                  ? isInstallments
                    ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                    : 'bg-blue-500/15 text-blue-400 border border-blue-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <i className={`${item.icon} text-base w-5 text-center ${isActive ? (isInstallments ? 'text-emerald-400' : 'text-blue-400') : 'text-slate-500'}`}></i>
                <span className="truncate">{item.label}</span>
              </div>

              {typeof item.badge === 'number' && item.badge > 0 && (
                <span className="bg-rose-600 text-white text-[11px] font-black px-2 py-0.5 rounded-full font-mono shadow-xs">
                  {formatNumber(item.badge, numberFormat)}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* User Info & Logout Footer */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-950/40">
        <button
          type="button"
          onClick={onLogout}
          className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors text-xs font-bold cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <i className="fa-solid fa-arrow-right-from-bracket"></i>
            <span>{t('auth.logout', 'تسجيل الخروج')}</span>
          </div>
          <span className="text-[10px] text-slate-600 font-mono">v3.5 Desktop</span>
        </button>
      </div>
    </aside>
  );
};
