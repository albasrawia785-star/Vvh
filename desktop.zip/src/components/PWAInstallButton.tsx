import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useI18n } from '../i18n/index.tsx';

export const PWAInstallButton: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const { t, dir } = useI18n();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already installed or running standalone, hide the button
  if (isInstalled) {
    return null;
  }

  // Android / Chrome / Edge install prompt
  if (isInstallable) {
    return (
      <button
        id="pwaInstallBtn"
        type="button"
        onClick={install}
        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs active:scale-[0.98] transition-all cursor-pointer ${className}`}
        title={t('pwa.installDeviceTitle', 'تثبيت التطبيق على الجهاز')}
      >
        <i className="fa-solid fa-cloud-arrow-down text-xs"></i>
        <span>{t('pwa.installApp', 'تثبيت التطبيق')}</span>
      </button>
    );
  }

  // iOS Safari instruction modal
  if (isIOS) {
    return (
      <>
        <button
          id="pwaInstallIOSBtn"
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-700/15 hover:bg-emerald-700/25 text-emerald-800 text-xs font-bold border border-emerald-300 transition-all cursor-pointer ${className}`}
          title={t('pwa.installIOSTitle', 'تثبيت التطبيق على الآيفون والآيباد')}
        >
          <i className="fa-brands fa-apple text-xs"></i>
          <span>{t('pwa.installIOS', 'تثبيت PWA')}</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150" dir={dir}>
            <div className="w-full max-w-sm rounded-2xl bg-white p-5 shadow-2xl border border-slate-100 text-start space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                    <i className="fa-brands fa-apple text-base"></i>
                  </div>
                  <h3 className="text-sm font-bold text-slate-800">{t('pwa.iosModalTitle', 'تثبيت التطبيق على iPhone / iPad')}</h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center text-xs transition-colors"
                >
                  <i className="fa-solid fa-xmark"></i>
                </button>
              </div>

              <div className="space-y-3 text-xs text-slate-600 leading-relaxed">
                <div className="flex items-start gap-2.5 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0">1</span>
                  <p>{t('pwa.iosStep1', 'اضغط على زر المشاركة (Share) في شريط متصفح سفاري بالأسفل.')}</p>
                </div>
                <div className="flex items-start gap-2.5 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0">2</span>
                  <p>{t('pwa.iosStep2', 'مرر للأسفل واختر إضافة إلى الصفحة الرئيسية (Add to Home Screen).')}</p>
                </div>
                <div className="flex items-start gap-2.5 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0">3</span>
                  <p>{t('pwa.iosStep3', 'اضغط على إضافة (Add) بالأعلى ليفتح التطبيق كنافذة مستقلة وسريعة.')}</p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                {t('pwa.gotIt', 'فهمت، حسناً')}
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
