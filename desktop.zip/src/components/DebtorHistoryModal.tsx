import React, { useState } from 'react';
import { Debtor, DebtorTransaction } from '../types';
import { formatNumber, formatDateDigits, buildWhatsAppReminderUrl } from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';

interface DebtorHistoryModalProps {
  isOpen: boolean;
  debtor: Debtor | null;
  onClose: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const DebtorHistoryModal: React.FC<DebtorHistoryModalProps> = ({
  isOpen,
  debtor,
  onClose,
  onShowToast,
}) => {
  const { t, numberFormat, getCurrencySymbol, dir } = useI18n();
  const [filterType, setFilterType] = useState<'all' | 'add' | 'pay'>('all');

  if (!isOpen || !debtor) return null;

  const currSym = getCurrencySymbol();

  // Build history list, fallback to initial creation entry if empty
  const rawHistory: DebtorTransaction[] = debtor.history && debtor.history.length > 0
    ? debtor.history
    : [
        {
          id: `initial-${debtor.id}`,
          debtorId: debtor.id,
          type: 'initial',
          amount: debtor.amount,
          balanceAfter: debtor.amount,
          date: debtor.createdAt || new Date().toISOString(),
          description: t('debtorHistory.initialBalance', 'فتح حساب وتسجيل الرصيد الأولي'),
        },
      ];

  // Sort descending by date (newest first)
  const sortedHistory = [...rawHistory].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const filteredHistory = sortedHistory.filter((item) => {
    if (filterType === 'all') return true;
    if (filterType === 'add') return item.type === 'add' || item.type === 'initial';
    if (filterType === 'pay') return item.type === 'pay';
    return true;
  });

  // Calculate totals
  const totalAdded = rawHistory
    .filter((h) => h.type === 'add' || h.type === 'initial')
    .reduce((sum, h) => sum + h.amount, 0);

  const totalPaid = rawHistory
    .filter((h) => h.type === 'pay')
    .reduce((sum, h) => sum + h.amount, 0);

  const currentBalance = debtor.amount;

  const handleCopyStatement = () => {
    try {
      let text = `*${t('debtorHistory.statementHeader', 'كشف حساب وسجل عمليات:')} ${debtor.name}*\n`;
      text += `${t('debtorHistory.phone', 'الهاتف:')} ${debtor.phone || t('debtorHistory.unregistered', 'غير مسجل')}\n`;
      if (debtor.notes) {
        text += `${t('debtorHistory.notes', 'ملاحظات:')} ${debtor.notes}\n`;
      }
      text += `* ${t('debtorHistory.currentBalance', 'الرصيد المتبقي:')} ${formatNumber(currentBalance, numberFormat)} ${currSym}\n`;
      text += `* ${t('debtorHistory.totalDebts', 'إجمالي الديون:')} ${formatNumber(totalAdded, numberFormat)} ${currSym}\n`;
      text += `* ${t('debtorHistory.totalPaid', 'إجمالي المسدد:')} ${formatNumber(totalPaid, numberFormat)} ${currSym}\n`;
      text += `--------------------\n`;
      text += `*${t('debtorHistory.opsDetails', 'تفاصيل العمليات السابقة:')}*\n`;

      sortedHistory.forEach((tx, idx) => {
        const typeStr =
          tx.type === 'pay'
            ? t('common.settlePayment', 'تسديد دفعة')
            : tx.type === 'initial'
            ? t('debtorShare.initialType', 'رصيد أولي')
            : t('common.addDebt', 'إضافة دين');
        const sign = tx.type === 'pay' ? '-' : '+';
        text += `${idx + 1}) ${typeStr}: ${sign}${formatNumber(tx.amount, numberFormat)} ${currSym}\n`;
        text += `   ${t('common.date', 'التاريخ')}: ${formatDateDigits(tx.date, numberFormat)}\n`;
        if (tx.notes || (tx.description && tx.description !== 'إضافة دين جديد' && tx.description !== 'تسديد دفعة نقدية')) {
          text += `   ${t('common.notes', 'ملاحظة')}: ${tx.notes || tx.description}\n`;
        }
        text += `   ${t('debtorHistory.balanceAfter', 'الرصيد بعد العملية:')} ${formatNumber(tx.balanceAfter, numberFormat)} ${currSym}\n`;
      });

      navigator.clipboard.writeText(text);
      onShowToast(t('toast.copiedToClipboard', 'تم النسخ إلى الحافظة بنجاح'), 'success');
    } catch {
      onShowToast(t('toast.copyFailed', 'تعذر نسخ كشف الحساب'), 'error');
    }
  };

  const handleShareWhatsApp = () => {
    if (!debtor.phone) {
      onShowToast(t('toast.phoneRequiredWhatsApp', 'لا يوجد رقم هاتف مسجل لهذا العميل'), 'error');
      return;
    }

    let text = `${t('debtorShare.greeting', 'السلام عليكم')} ${debtor.name}،\n${t('debtorHistory.statementWhatsAppIntro', 'إليك كشف الحساب وسجل العمليات الخاص بك:')}\n`;
    text += `* ${t('debtorHistory.currentBalance', 'الرصيد المتبقي:')} ${formatNumber(currentBalance, numberFormat)} ${currSym}\n`;
    text += `* ${t('debtorHistory.totalDebts', 'إجمالي الديون:')} ${formatNumber(totalAdded, numberFormat)} ${currSym}\n`;
    text += `* ${t('debtorHistory.totalPaid', 'إجمالي المسدد:')} ${formatNumber(totalPaid, numberFormat)} ${currSym}\n`;
    text += `--------------------\n${t('debtorShare.recentOperations', 'آخر العمليات:')}\n`;

    sortedHistory.slice(0, 5).forEach((tx) => {
      const typeStr = tx.type === 'pay' ? t('debtorShare.paymentType', 'تسديد') : t('debtorShare.debtType', 'دين');
      const sign = tx.type === 'pay' ? '-' : '+';
      text += `• ${typeStr}: ${sign}${formatNumber(tx.amount, numberFormat)} ${currSym} (${formatDateDigits(tx.date, numberFormat)})\n`;
    });

    const url = buildWhatsAppReminderUrl(debtor.phone, debtor.name, undefined);
    const baseWithoutText = url.split('?')[0];
    const fullUrl = `${baseWithoutText}?text=${encodeURIComponent(text)}`;
    window.open(fullUrl, '_blank');
  };

  return (
    <div
      className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xs animate-in fade-in duration-150 select-none"
      onClick={onClose}
      dir={dir}
    >
      <div
        className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh] border border-slate-100 animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
        id="debtorHistoryModal"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-bold text-base shadow-md shadow-blue-500/20">
              <i className="fa-solid fa-clock-rotate-left"></i>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-slate-800">
                  {t('debtorHistory.modalTitle', 'سجل العمليات (History)')}
                </h2>
                <span className="text-[10px] bg-blue-100 text-blue-800 font-bold px-2 py-0.5 rounded-full font-mono">
                  {rawHistory.length}
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                <span className="font-bold text-slate-700">{debtor.name}</span>
                {debtor.phone && (
                  <>
                    <span className="text-slate-300">•</span>
                    <span className="font-mono text-slate-500 dir-ltr">{debtor.phone}</span>
                  </>
                )}
              </div>
              {debtor.notes && (
                <div className="mt-1 text-[11px] text-amber-800 bg-amber-50 border border-amber-200/80 px-2 py-0.5 rounded-lg inline-flex items-center gap-1.5 max-w-full">
                  <i className="fa-regular fa-note-sticky text-[10px] text-amber-600 shrink-0"></i>
                  <span className="truncate">{debtor.notes}</span>
                </div>
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center cursor-pointer transition-colors"
            title={t('common.close', 'إغلاق')}
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Financial Summary Cards */}
        <div className="p-3 sm:p-4 bg-slate-50 border-b border-slate-100">
          <div className="grid grid-cols-3 gap-2">
            {/* Total Added */}
            <div className="bg-white p-2.5 rounded-2xl border border-slate-100 text-center shadow-2xs">
              <div className="text-[10px] font-bold text-slate-400 mb-0.5">{t('debtorHistory.totalDebts', 'إجمالي الديون')}</div>
              <div className="text-xs sm:text-sm font-black text-rose-600 font-mono">
                {formatNumber(totalAdded, numberFormat)}
                <span className="text-[9px] font-normal text-slate-400 mx-0.5">{currSym}</span>
              </div>
            </div>

            {/* Total Paid */}
            <div className="bg-white p-2.5 rounded-2xl border border-slate-100 text-center shadow-2xs">
              <div className="text-[10px] font-bold text-slate-400 mb-0.5">{t('debtorHistory.totalPaid', 'إجمالي المسدد')}</div>
              <div className="text-xs sm:text-sm font-black text-emerald-600 font-mono">
                {formatNumber(totalPaid, numberFormat)}
                <span className="text-[9px] font-normal text-slate-400 mx-0.5">{currSym}</span>
              </div>
            </div>

            {/* Current Balance */}
            <div className="bg-white p-2.5 rounded-2xl border border-slate-100 text-center shadow-2xs">
              <div className="text-[10px] font-bold text-slate-400 mb-0.5">{t('debtorHistory.currentBalance', 'الرصيد المتبقي')}</div>
              <div
                className={`text-xs sm:text-sm font-black font-mono ${
                  currentBalance <= 0 ? 'text-emerald-600' : 'text-blue-700'
                }`}
              >
                {formatNumber(currentBalance, numberFormat)}
                <span className="text-[9px] font-normal text-slate-400 mx-0.5">{currSym}</span>
              </div>
            </div>
          </div>

          {/* Quick Filters */}
          <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-200/60">
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setFilterType('all')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  filterType === 'all'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100'
                }`}
              >
                {t('common.all', 'الكل')} ({rawHistory.length})
              </button>

              <button
                type="button"
                onClick={() => setFilterType('add')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  filterType === 'add'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100'
                }`}
              >
                {t('debtorHistory.filterDebts', 'ديون')} ({rawHistory.filter((h) => h.type === 'add' || h.type === 'initial').length})
              </button>

              <button
                type="button"
                onClick={() => setFilterType('pay')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  filterType === 'pay'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100'
                }`}
              >
                {t('debtorHistory.filterPayments', 'تسديدات')} ({rawHistory.filter((h) => h.type === 'pay').length})
              </button>
            </div>

            {/* Statement Actions */}
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handleCopyStatement}
                className="px-2 py-1 bg-white hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-bold border border-slate-200 flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                title={t('debtorHistory.copyStatement', 'نسخ كشف الحساب')}
              >
                <i className="fa-regular fa-copy text-[11px]"></i>
                <span className="hidden sm:inline">{t('common.copy', 'نسخ')}</span>
              </button>

              {debtor.phone && (
                <button
                  type="button"
                  onClick={handleShareWhatsApp}
                  className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-xs font-bold border border-emerald-200 flex items-center gap-1 cursor-pointer transition-colors"
                  title={t('debtorHistory.sendWhatsApp', 'مشاركة الكشف عبر واتساب')}
                >
                  <i className="fa-brands fa-whatsapp text-xs"></i>
                  <span className="hidden sm:inline">{t('common.whatsapp', 'واتساب')}</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Transactions List */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-2.5">
          {filteredHistory.length === 0 ? (
            <div className="text-center py-8 text-slate-400">
              <i className="fa-solid fa-receipt text-3xl text-slate-300 mb-2"></i>
              <p className="text-xs">{t('debtorHistory.noTransactions', 'لا توجد عمليات تطابق هذا الفلتر')}</p>
            </div>
          ) : (
            filteredHistory.map((tx) => {
              const isPay = tx.type === 'pay';
              const isInitial = tx.type === 'initial';

              return (
                <div
                  key={tx.id}
                  className={`p-3 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                    isPay
                      ? 'bg-emerald-50/40 border-emerald-100/80 hover:bg-emerald-50/70'
                      : isInitial
                      ? 'bg-amber-50/40 border-amber-100/80 hover:bg-amber-50/70'
                      : 'bg-rose-50/40 border-rose-100/80 hover:bg-rose-50/70'
                  }`}
                >
                  {/* Icon, Type, Date */}
                  <div className="flex items-start gap-2.5">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 text-sm font-bold shadow-2xs ${
                        isPay
                          ? 'bg-emerald-100 text-emerald-700'
                          : isInitial
                          ? 'bg-amber-100 text-amber-700'
                          : 'bg-rose-100 text-rose-700'
                      }`}
                    >
                      {isPay ? (
                        <i className="fa-solid fa-arrow-down"></i>
                      ) : isInitial ? (
                        <i className="fa-solid fa-wallet"></i>
                      ) : (
                        <i className="fa-solid fa-plus"></i>
                      )}
                    </div>

                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span
                          className={`text-xs font-black px-1.5 py-0.5 rounded-md ${
                            isPay
                              ? 'bg-emerald-100/80 text-emerald-800'
                              : isInitial
                              ? 'bg-amber-100/80 text-amber-800'
                              : 'bg-rose-100/80 text-rose-800'
                          }`}
                        >
                          {isPay ? t('common.settlePayment', 'تسديد دفعة') : isInitial ? t('debtorShare.initialType', 'رصيد أولي') : t('common.addDebt', 'إضافة دين')}
                        </span>
                        <span className="text-[11px] font-semibold text-slate-700">
                          {tx.description || (isPay ? t('debtorShare.paymentType', 'تسديد نقدي') : t('debtorShare.debtType', 'شراء بالدين'))}
                        </span>
                      </div>

                      {/* Date and Time */}
                      <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
                        <i className="fa-regular fa-calendar-days text-[10px]"></i>
                        <span>{formatDateDigits(tx.date, numberFormat)}</span>
                      </div>

                      {/* Transaction Note if present and distinct */}
                      {tx.notes && tx.notes !== tx.description && (
                        <div className="text-[10.5px] text-slate-600 mt-1.5 flex items-center gap-1.5 bg-slate-50 px-2 py-0.5 rounded-lg border border-slate-200/60 w-fit">
                          <i className="fa-solid fa-note-sticky text-amber-500 text-[10px]"></i>
                          <span>{tx.notes}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Amount and Balance after */}
                  <div className="text-left shrink-0">
                    <div
                      className={`text-sm sm:text-base font-black font-mono ${
                        isPay ? 'text-emerald-600' : 'text-rose-600'
                      }`}
                    >
                      {isPay ? '-' : '+'}
                      {formatNumber(tx.amount, numberFormat)}
                      <span className="text-[10px] font-normal text-slate-400 mx-1 font-sans">
                        {currSym}
                      </span>
                    </div>

                    <div className="text-[10.5px] text-slate-500 font-mono mt-0.5">
                      <span className="text-[9.5px] text-slate-400 font-sans mx-1">{t('debtorHistory.currentBalance', 'الرصيد')}:</span>
                      {formatNumber(tx.balanceAfter, numberFormat)} {currSym}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold cursor-pointer transition-colors"
          >
            {t('common.close', 'إغلاق')}
          </button>
        </div>
      </div>
    </div>
  );
};
