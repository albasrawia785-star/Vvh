import React, { useState } from 'react';
import { InstallmentRecord } from '../types';
import { useI18n } from '../i18n/index.tsx';
import { formatNumber, formatAmountInput, parseFormattedNumber, toEnglishDigits } from '../utils/formatters';
import { calculateNextMonthDueDate, computeInstallmentStatus } from '../utils/installmentHelpers';
import { handleInputFocus, useModalKeyboardAdjust } from '../utils/keyboardHelper';

interface AddInstallmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (installment: Omit<InstallmentRecord, 'id'>) => Promise<void>;
  userId: number;
}

export const AddInstallmentModal: React.FC<AddInstallmentModalProps> = ({
  isOpen,
  onClose,
  onAdd,
  userId,
}) => {
  const { t, currency } = useI18n();
  const [name, setName] = useState('');

  useModalKeyboardAdjust(isOpen);
  const [phone, setPhone] = useState('');
  const [item, setItem] = useState('');
  const [totalAmountStr, setTotalAmountStr] = useState('');
  const [downPaymentStr, setDownPaymentStr] = useState('');
  const [registrationDate, setRegistrationDate] = useState(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [nationalId, setNationalId] = useState('');
  const [address, setAddress] = useState('');

  // Guarantor Fields
  const [guarantorEnabled, setGuarantorEnabled] = useState(false);
  const [guarantorName, setGuarantorName] = useState('');
  const [guarantorAddress, setGuarantorAddress] = useState('');
  const [guarantorJob, setGuarantorJob] = useState('');
  const [guarantorRelation, setGuarantorRelation] = useState('');
  const [guarantorPhone, setGuarantorPhone] = useState('');

  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = toEnglishDigits(e.target.value);
    const cleanNumbers = raw.replace(/\D/g, '').slice(0, 11);
    setPhone(cleanNumbers);
    if (errorMsg) setErrorMsg(null);
  };

  const handleNationalIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = toEnglishDigits(e.target.value);
    const cleanNumbers = raw.replace(/\D/g, '').slice(0, 12);
    setNationalId(cleanNumbers);
    if (errorMsg) setErrorMsg(null);
  };

  const handleGuarantorPhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = toEnglishDigits(e.target.value);
    const cleanNumbers = raw.replace(/\D/g, '').slice(0, 11);
    setGuarantorPhone(cleanNumbers);
    if (errorMsg) setErrorMsg(null);
  };

  const totalAmount = parseFormattedNumber(totalAmountStr);
  const downPayment = parseFormattedNumber(downPaymentStr);
  const remainingAmount = Math.max(0, totalAmount - downPayment);
  const calculatedDueDate = calculateNextMonthDueDate(registrationDate);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const cleanName = name.trim();
    const cleanItem = item.trim();

    if (!cleanName) {
      setErrorMsg(t('modals.enterDebtorNameError', 'يرجى إدخال اسم صاحب الأقساط'));
      return;
    }
    if (!cleanItem) {
      setErrorMsg(t('modals.enterItemNameError', 'يرجى إدخال اسم أو تفاصيل السلعة'));
      return;
    }
    if (totalAmount <= 0) {
      setErrorMsg(t('modals.enterTotalAmountError', 'يرجى إدخال مبلغ الأقساط الإجمالي'));
      return;
    }
    if (downPayment > totalAmount) {
      setErrorMsg(t('modals.downPaymentTooLargeError', 'لا يمكن أن تكون الدفعة المقدمة أكبر من مبلغ القسط الكلي'));
      return;
    }
    if (!registrationDate) {
      setErrorMsg(t('modals.selectRegistrationDate', 'يرجى تحديد تاريخ التسجيل'));
      return;
    }

    const cleanPhone = phone.trim();
    if (cleanPhone && cleanPhone.length !== 11) {
      setErrorMsg(t('modals.phone11DigitsError', 'رقم الهاتف يجب أن يتكون من 11 رقماً (أو اتركه فارغاً)'));
      return;
    }

    const cleanNatId = nationalId.trim();
    if (cleanNatId && cleanNatId.length !== 12) {
      setErrorMsg(t('modals.nationalId12DigitsError', 'رقم البطاقة الوطنية يجب أن يتكون من 12 رقماً (أو اتركه فارغاً)'));
      return;
    }

    const cleanGPhone = guarantorPhone.trim();
    if (guarantorEnabled && cleanGPhone && cleanGPhone.length !== 11) {
      setErrorMsg(t('modals.guarantorPhone11DigitsError', 'رقم هاتف الكفيل يجب أن يتكون من 11 رقماً (أو اتركه فارغاً)'));
      return;
    }

    const nextDueDate = calculatedDueDate;
    const initialStatus = computeInstallmentStatus({
      remainingAmount,
      nextDueDate,
      registrationDate,
    });

    try {
      setIsSubmitting(true);
      await onAdd({
        name: cleanName,
        phone: cleanPhone,
        item: cleanItem,
        totalAmount,
        downPayment,
        remainingAmount,
        registrationDate,
        nextDueDate,
        userId,
        status: initialStatus,
        nationalId: cleanNatId || undefined,
        address: address.trim() || undefined,
        guarantorEnabled: guarantorEnabled || undefined,
        guarantorName: guarantorEnabled ? guarantorName.trim() || undefined : undefined,
        guarantorAddress: guarantorEnabled ? guarantorAddress.trim() || undefined : undefined,
        guarantorJob: guarantorEnabled ? guarantorJob.trim() || undefined : undefined,
        guarantorRelation: guarantorEnabled ? guarantorRelation.trim() || undefined : undefined,
        guarantorPhone: guarantorEnabled ? cleanGPhone || undefined : undefined,
        notes: notes.trim() || undefined,
        payments: downPayment > 0 ? [
          {
            id: `down-${Date.now()}`,
            installmentId: 0,
            amount: downPayment,
            date: registrationDate,
            remainingAfter: remainingAmount,
            notes: t('installments.downPaymentNote', 'الدفعة المقدمة عند التسجيل'),
          }
        ] : [],
        createdAt: new Date().toISOString(),
      });

      // Reset form
      setName('');
      setPhone('');
      setItem('');
      setTotalAmountStr('');
      setDownPaymentStr('');
      setNationalId('');
      setAddress('');
      setGuarantorEnabled(false);
      setGuarantorName('');
      setGuarantorAddress('');
      setGuarantorJob('');
      setGuarantorRelation('');
      setGuarantorPhone('');
      setNotes('');
      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || t('common.errorOccurred', 'حدث خطأ أثناء حفظ القسط'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/60 backdrop-blur-xs p-0 sm:p-4 animate-in fade-in duration-150 text-start">
      <div className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-100 flex flex-col max-h-[92dvh] overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-emerald-800 via-teal-800 to-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/10 flex items-center justify-center text-emerald-300 border border-white/10">
              <i className="fa-solid fa-file-invoice-dollar text-base"></i>
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight">{t('installments.addInstallment', 'تسجيل معاملة أقساط جديدة')}</h2>
              <p className="text-[10.5px] text-emerald-200/80 mt-0.5 font-medium">
                {t('installments.installmentsManagement', 'نظام إدارة الأقساط الشهرية')}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-white/80 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 pb-28 sm:pb-5 overflow-y-auto space-y-4">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2 animate-in fade-in">
              <i className="fa-solid fa-circle-exclamation shrink-0"></i>
              <span>{errorMsg}</span>
            </div>
          )}

          {/* 1. اسم صاحب الأقساط */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-user text-emerald-600 text-xs"></i>
              <span>{t('installments.debtorName', 'اسم صاحب الأقساط')}</span>
              <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              onFocus={handleInputFocus}
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-800 rounded-xl text-xs font-medium border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
            />
          </div>

          {/* 2. رقم الهاتف */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-phone text-emerald-600 text-xs"></i>
              <span>{t('debts.phoneNumber', 'رقم الهاتف')}</span>
              <span className="text-[10px] text-slate-400 font-normal">({t('common.optional', 'اختياري')})</span>
            </label>
            <input
              type="tel"
              dir="ltr"
              maxLength={11}
              value={phone}
              onChange={handlePhoneChange}
              onFocus={handleInputFocus}
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-800 rounded-xl text-xs font-mono border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
            />
          </div>

          {/* 3. السلعة */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-box-open text-emerald-600 text-xs"></i>
              <span>{t('installments.itemName', 'السلعة المباعة')}</span>
              <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={item}
              onChange={(e) => setItem(e.target.value)}
              onFocus={handleInputFocus}
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-800 rounded-xl text-xs font-medium border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
            />
          </div>

          {/* 4 & 5. مبلغ الأقساط + الدفعة المقدمة */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* مبلغ الأقساط الكلي */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-solid fa-coins text-emerald-600 text-xs"></i>
                <span>{t('installments.totalAmount', 'مبلغ الأقساط (الإجمالي)')}</span>
                <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  dir="ltr"
                  inputMode="numeric"
                  required
                  value={totalAmountStr}
                  onChange={(e) => setTotalAmountStr(formatAmountInput(e.target.value))}
                  onFocus={handleInputFocus}
                  className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-900 rounded-xl text-xs font-bold font-mono border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
                />
              </div>
            </div>

            {/* الدفعة المقدمة */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-solid fa-hand-holding-dollar text-teal-600 text-xs"></i>
                <span>{t('installments.downPayment', 'الدفعة المقدمة')}</span>
                <span className="text-[10px] text-slate-400 font-normal">({t('installments.downPaymentShort', 'المقدم')})</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  dir="ltr"
                  inputMode="numeric"
                  value={downPaymentStr}
                  onChange={(e) => setDownPaymentStr(formatAmountInput(e.target.value))}
                  onFocus={handleInputFocus}
                  className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-900 rounded-xl text-xs font-bold font-mono border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
                />
              </div>
            </div>
          </div>

          {/* خلاصة المتبقي بالأقساط */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-emerald-50 via-teal-50/50 to-slate-50 border border-emerald-200/80 flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-emerald-900 block">
                {t('installments.remainingToPay', 'المتبقي بالأقساط المطلوب تسديده')}:
              </span>
              <span className="text-[10px] text-emerald-700">
                ({t('installments.totalMinusDownPayment', 'الإجمالي - الدفعة المقدمة')})
              </span>
            </div>
            <div className="text-left">
              <span className="text-base font-black text-emerald-800 font-mono">
                {formatNumber(remainingAmount)}
              </span>
              <span className="text-[11px] font-bold text-emerald-600 mr-1">{currency}</span>
            </div>
          </div>

          {/* البطاقة الوطنية (اختياري) */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-id-card text-emerald-600 text-xs"></i>
              <span>{t('installments.nationalId', 'رقم البطاقة الوطنية')}</span>
              <span className="text-[10px] text-slate-400 font-normal">({t('common.optional', 'اختياري')})</span>
            </label>
            <div className="relative">
              <input
                type="text"
                dir="ltr"
                inputMode="numeric"
                maxLength={12}
                value={nationalId}
                onChange={handleNationalIdChange}
                className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-800 rounded-xl text-xs font-mono font-bold border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
              />
              <div className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xs">
                <i className="fa-solid fa-id-card"></i>
              </div>
            </div>
          </div>

          {/* عنوان السكن وأقرب نقطة دالة */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-location-dot text-emerald-600 text-xs"></i>
              <span>{t('installments.address', 'عنوان السكن وأقرب نقطة دالة')}</span>
              <span className="text-[10px] text-slate-400 font-normal">({t('common.optional', 'اختياري')})</span>
            </label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-800 rounded-xl text-xs font-medium border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all"
            />
          </div>

          {/* قائمة بيانات الكفيل */}
          <div className="border border-slate-200 rounded-2xl p-3.5 bg-slate-50/70 space-y-3">
            <label className="flex items-center gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={guarantorEnabled}
                onChange={(e) => setGuarantorEnabled(e.target.checked)}
                className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer accent-emerald-600"
              />
              <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                <i className="fa-solid fa-user-shield text-emerald-600"></i>
                <span>{t('installments.guarantorInfo', 'بيانات الكفيل')}</span>
                <span className="text-[10.5px] font-normal text-slate-500">({t('common.clickToEnable', 'اضغط للتفعيل')})</span>
              </span>
            </label>

            {guarantorEnabled && (
              <div className="pt-2 border-t border-slate-200/80 space-y-2.5 animate-in fade-in duration-150">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {t('installments.guarantorName', 'اسم الكفيل')}
                  </label>
                  <input
                    type="text"
                    value={guarantorName}
                    onChange={(e) => setGuarantorName(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      {t('installments.guarantorRelation', 'صلة القرابة')}
                    </label>
                    <input
                      type="text"
                      value={guarantorRelation}
                      onChange={(e) => setGuarantorRelation(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      {t('installments.guarantorJob', 'مهنة الكفيل')}
                    </label>
                    <input
                      type="text"
                      value={guarantorJob}
                      onChange={(e) => setGuarantorJob(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {t('installments.guarantorAddress', 'عنوان الكفيل')}
                  </label>
                  <input
                    type="text"
                    value={guarantorAddress}
                    onChange={(e) => setGuarantorAddress(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-emerald-600 text-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    {t('installments.guarantorPhone', 'رقم هاتف الكفيل')} ({t('common.optional', 'اختياري')})
                  </label>
                  <input
                    type="tel"
                    dir="ltr"
                    maxLength={11}
                    value={guarantorPhone}
                    onChange={handleGuarantorPhoneChange}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono outline-none focus:border-emerald-600 text-slate-800"
                  />
                </div>
              </div>
            )}
          </div>

          {/* 6. تاريخ التسجيل وتاريخ الاستحقاق المحسوب */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-solid fa-calendar-day text-emerald-600 text-xs"></i>
                <span>{t('common.date', 'تاريخ التسجيل')}</span>
                <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                required
                value={registrationDate}
                onChange={(e) => setRegistrationDate(toEnglishDigits(e.target.value))}
                className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-800 rounded-xl text-xs font-semibold border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all font-mono"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-solid fa-clock-rotate-left text-teal-600 text-xs"></i>
                <span>{t('installments.dueDateMonthly', 'تاريخ الاستحقاق (بعد شهر)')}</span>
              </label>
              <div className="px-3.5 py-2.5 bg-slate-100/80 rounded-xl border border-slate-200/80 text-xs font-bold text-slate-800 flex items-center justify-between">
                <span className="font-mono" dir="ltr">{calculatedDueDate}</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  {t('common.automatic', 'تلقائي')}
                </span>
              </div>
            </div>
          </div>

          {/* ملاحظات إضافية */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <i className="fa-solid fa-note-sticky text-slate-400 text-xs"></i>
              <span>{t('common.notes', 'ملاحظات المعاملة')} ({t('common.optional', 'اختياري')})</span>
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3.5 py-2 bg-slate-50 hover:bg-slate-100/70 focus:bg-white text-slate-800 rounded-xl text-xs font-medium border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 outline-none transition-all resize-none"
            ></textarea>
          </div>

          {/* Actions */}
          <div className="pt-2 flex items-center gap-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-extrabold shadow-md shadow-emerald-600/20 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                  <span>{t('common.saving', 'جاري حفظ المعاملة...')}</span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-check text-xs"></i>
                  <span>{t('installments.saveInstallment', 'حفظ معاملة القسط')}</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer"
            >
              {t('common.cancel', 'إلغاء')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
