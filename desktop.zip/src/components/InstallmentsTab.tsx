import React, { useState, useMemo } from 'react';
import { InstallmentFilterType, InstallmentRecord } from '../types';
import { formatNumber } from '../utils/formatters';
import { InstallmentCard } from './InstallmentCard';
import { AddInstallmentModal } from './AddInstallmentModal';
import { SettleInstallmentPaymentModal } from './SettleInstallmentPaymentModal';
import { InstallmentDetailsModal } from './InstallmentDetailsModal';
import { EditInstallmentModal } from './EditInstallmentModal';
import { useI18n } from '../i18n/index.tsx';

interface InstallmentsTabProps {
  installments: InstallmentRecord[];
  onAddInstallment: (inst: Omit<InstallmentRecord, 'id'>) => Promise<void>;
  onUpdateInstallment: (inst: InstallmentRecord) => Promise<void>;
  onSettlePayment: (installmentId: number, amount: number, date: string, notes?: string) => Promise<void>;
  onDeleteInstallment: (id: number) => Promise<void>;
  userId: number;
  isTrialMode?: boolean;
  onTrialLimitReached?: () => void;
  numberFormat?: 'english' | 'arabic';
}

export const InstallmentsTab: React.FC<InstallmentsTabProps> = ({
  installments,
  onAddInstallment,
  onUpdateInstallment,
  onSettlePayment,
  onDeleteInstallment,
  userId,
  isTrialMode = false,
  onTrialLimitReached,
  numberFormat: propsNumFormat,
}) => {
  const { t, numberFormat: ctxNumFormat } = useI18n();
  const numberFormat = propsNumFormat || ctxNumFormat;

  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<InstallmentFilterType>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedForDetails, setSelectedForDetails] = useState<InstallmentRecord | null>(null);
  const [selectedForSettle, setSelectedForSettle] = useState<InstallmentRecord | null>(null);
  const [selectedForEdit, setSelectedForEdit] = useState<InstallmentRecord | null>(null);

  const handleOpenAddModal = () => {
    if (isTrialMode && installments.length >= 2) {
      if (onTrialLimitReached) {
        onTrialLimitReached();
      }
      return;
    }
    setIsAddModalOpen(true);
  };

  // Statistics
  const stats = useMemo(() => {
    let totalInstallmentValue = 0;
    let totalRemaining = 0;
    let totalDownAndPaid = 0;
    let dueCount = 0;
    let overdueCount = 0;
    let completedCount = 0;

    installments.forEach((inst) => {
      totalInstallmentValue += inst.totalAmount || 0;
      totalRemaining += inst.remainingAmount || 0;
      totalDownAndPaid += (inst.totalAmount || 0) - (inst.remainingAmount || 0);

      if (inst.status === 'due') dueCount++;
      if (inst.status === 'overdue') overdueCount++;
      if (inst.status === 'completed') completedCount++;
    });

    return {
      totalCount: installments.length,
      totalInstallmentValue,
      totalRemaining,
      totalDownAndPaid,
      dueCount,
      overdueCount,
      dueAndOverdueCount: dueCount + overdueCount,
      completedCount,
    };
  }, [installments]);

  // Filter & Search
  const filteredInstallments = useMemo(() => {
    return installments.filter((inst) => {
      // 1. Search filter
      const search = searchTerm.trim().toLowerCase();
      if (search) {
        const nameMatch = (inst.name || '').toLowerCase().includes(search);
        const itemMatch = (inst.item || '').toLowerCase().includes(search);
        const phoneMatch = inst.phone ? String(inst.phone).includes(search) : false;
        if (!nameMatch && !itemMatch && !phoneMatch) return false;
      }

      // 2. Status filter
      if (filter === 'due_and_overdue') {
        return inst.status === 'due' || inst.status === 'overdue';
      }
      if (filter === 'due') {
        return inst.status === 'due';
      }
      if (filter === 'overdue') {
        return inst.status === 'overdue';
      }
      if (filter === 'active') {
        return inst.status === 'active';
      }
      if (filter === 'completed') {
        return inst.status === 'completed';
      }

      return true;
    });
  }, [installments, searchTerm, filter]);

  return (
    <div className="flex flex-col h-full animate-in fade-in duration-200">
      {/* Sticky Top Controls & Filters */}
      <div className="shrink-0 space-y-2.5 pb-2.5 bg-slate-50 z-20">
        {/* Search Bar */}
        <div className="relative">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={t('installments.searchPlaceholder', 'بحث بالاسم، نوع السلعة، أو رقم الهاتف...')}
            className="w-full pl-9 pr-9 py-2.5 bg-white hover:bg-slate-50 focus:bg-white text-slate-800 placeholder:text-slate-400 rounded-2xl text-xs font-semibold border border-slate-200/80 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 shadow-2xs outline-none transition-all"
          />
          <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-xs">
            <i className="fa-solid fa-magnifying-glass"></i>
          </span>
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm('')}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer p-1"
              title={t('common.clear', 'مسح')}
            >
              <i className="fa-solid fa-xmark"></i>
            </button>
          )}
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
          <button
            type="button"
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
              filter === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {t('common.all', 'الكل')} ({formatNumber(installments.length, numberFormat)})
          </button>

          <button
            type="button"
            onClick={() => setFilter('due_and_overdue')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1 ${
              filter === 'due_and_overdue'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-white text-rose-700 border border-rose-200 hover:bg-rose-50'
            }`}
          >
            <i className="fa-solid fa-bell text-[11px]"></i>
            <span>{t('installments.filterDueAndOverdue', 'المستحقة والمتأخرة')} ({formatNumber(stats.dueAndOverdueCount, numberFormat)})</span>
          </button>

          <button
            type="button"
            onClick={() => setFilter('active')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
              filter === 'active'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white text-blue-700 border border-blue-200 hover:bg-blue-50'
            }`}
          >
            {t('common.active', 'المتبقي')}
          </button>

          <button
            type="button"
            onClick={() => setFilter('completed')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
              filter === 'completed'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-emerald-700 border border-emerald-200 hover:bg-emerald-50'
            }`}
          >
            {t('common.completed', 'مسددة بالكامل')} ({formatNumber(stats.completedCount, numberFormat)})
          </button>
        </div>
      </div>

      {/* Scrollable Installment Customer Cards Area */}
      <div className="flex-1 overflow-y-auto overscroll-contain pb-32 sm:pb-36 space-y-2.5 pt-1 focus:outline-none">
        {filteredInstallments.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
            {filteredInstallments.map((inst) => (
              <InstallmentCard
                key={inst.id}
                installment={inst}
                onOpenDetails={(item) => setSelectedForDetails(item)}
                onOpenSettleModal={(item) => setSelectedForSettle(item)}
                onOpenEditModal={(item) => setSelectedForEdit(item)}
                onDelete={(id) => onDeleteInstallment(id)}
                numberFormat={numberFormat}
              />
            ))}
          </div>
        ) : (
          <div className="p-8 rounded-3xl bg-white border border-dashed border-slate-200 text-center space-y-3">
            <div className="w-12 h-12 mx-auto rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xl">
              <i className="fa-solid fa-clock-rotate-left"></i>
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-slate-800">
                {searchTerm ? t('installments.noSearchResults', 'لم يتم العثور على أي قسط يطابق بحثك') : t('installments.emptyNoInstallments', 'لا توجد معاملات أقساط مسجلة بعد')}
              </h3>
              <p className="text-xs text-slate-400">
                {searchTerm
                  ? t('installments.noSearchResultsDesc', 'جرّب البحث باسم آخر أو إزالة التصفية')
                  : t('installments.emptyNoInstallmentsDesc', 'يمكنك البدء بتسجيل معاملات الأقساط الشهرية لسلعك من الزر أعلاه أو زر (+) بالأسفل')}
              </p>
            </div>
            {!searchTerm && (
              <button
                type="button"
                onClick={handleOpenAddModal}
                className="py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer inline-flex items-center gap-1.5"
              >
                <i className="fa-solid fa-plus text-xs"></i>
                <span>{t('installments.addFirstInstallment', 'تسجيل أول معاملة قسط')}</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Modals */}
      <AddInstallmentModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAdd={onAddInstallment}
        userId={userId}
      />

      {selectedForEdit && (
        <EditInstallmentModal
          isOpen={!!selectedForEdit}
          onClose={() => setSelectedForEdit(null)}
          installment={selectedForEdit}
          onSave={onUpdateInstallment}
        />
      )}

      {selectedForSettle && (
        <SettleInstallmentPaymentModal
          isOpen={!!selectedForSettle}
          onClose={() => setSelectedForSettle(null)}
          installment={selectedForSettle}
          onSettle={onSettlePayment}
        />
      )}

      {selectedForDetails && (
        <InstallmentDetailsModal
          isOpen={!!selectedForDetails}
          onClose={() => setSelectedForDetails(null)}
          installment={selectedForDetails}
          onOpenSettleModal={(inst) => setSelectedForSettle(inst)}
          onOpenEditModal={(inst) => setSelectedForEdit(inst)}
          onDelete={onDeleteInstallment}
        />
      )}
    </div>
  );
};

