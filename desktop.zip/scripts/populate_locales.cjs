const fs = require('fs');

const ar = JSON.parse(fs.readFileSync('src/locales/ar.json', 'utf8'));
const en = JSON.parse(fs.readFileSync('src/locales/en.json', 'utf8'));
const ku = JSON.parse(fs.readFileSync('src/locales/ku.json', 'utf8'));

// Helper to set nested property
function setNested(obj, path, val) {
  const parts = path.split('.');
  let curr = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    if (!curr[parts[i]] || typeof curr[parts[i]] !== 'object') {
      curr[parts[i]] = {};
    }
    curr = curr[parts[i]];
  }
  curr[parts[parts.length - 1]] = val;
}

const missing = JSON.parse(fs.readFileSync('missing_keys.json', 'utf8'));
console.log('Total keys to process:', Object.keys(missing).length);

// Dictionary of translations for all missing keys
const translations = {
  // overdue
  "overdue.statusLate": {
    ar: "كمتأخر عن السداد",
    en: "Overdue for payment",
    ku: "دواکەوتوو لە دانەوە"
  },
  
  // modals
  "modals.enterDebtorNameError": {
    ar: "يرجى كتابة اسم المدين",
    en: "Please enter debtor name",
    ku: "تکایە ناوی قەرزدار بنووسە"
  },
  "modals.phone11DigitsError": {
    ar: "رقم الهاتف يجب أن يتكون من 11 رقماً (أو اتركه فارغاً)",
    en: "Phone number must be 11 digits (or leave empty)",
    ku: "ژمارەی مۆبایل دەبێت 11 ژمارە بێت (یان بە بەتاڵی بەجێی بهێڵە)"
  },
  "modals.enterItemNameError": {
    ar: "يرجى إدخال اسم أو تفاصيل السلعة",
    en: "Please enter item name or details",
    ku: "تکایە ناوی کاڵا یان وردەکارییەکان بنووسە"
  },
  "modals.enterTotalAmountError": {
    ar: "يرجى إدخال مبلغ الأقساط الإجمالي",
    en: "Please enter total installment amount",
    ku: "تکایە بڕی گشتیی قیست بنووسە"
  },
  "modals.downPaymentTooLargeError": {
    ar: "لا يمكن أن تكون الدفعة المقدمة أكبر من مبلغ القسط الكلي",
    en: "Down payment cannot exceed total installment amount",
    ku: "پێشەکی نابێت لە بڕی گشتیی قیست زیاتر بێت"
  },
  "modals.selectRegistrationDate": {
    ar: "يرجى تحديد تاريخ التسجيل",
    en: "Please select registration date",
    ku: "تکایە بەرواری تۆمارکردن دیاریبکە"
  },
  "modals.nationalId12DigitsError": {
    ar: "رقم البطاقة الوطنية يجب أن يتكون من 12 رقماً (أو اتركه فارغاً)",
    en: "National ID must be 12 digits (or leave empty)",
    ku: "ژمارەی کارتی نیشتمانی دەبێت 12 ژمارە بێت (یان بە بەتاڵی بەجێی بهێڵە)"
  },
  "modals.guarantorPhone11DigitsError": {
    ar: "رقم هاتف الكفيل يجب أن يتكون من 11 رقماً (أو اتركه فارغاً)",
    en: "Guarantor phone must be 11 digits (or leave empty)",
    ku: "ژمارەی مۆبایلی کەفیل دەبێت 11 ژمارە بێت (یان بە بەتاڵی بەجێی بهێڵە)"
  },
  "modals.nameMin2Chars": {
    ar: "الاسم يجب أن يتكون من حرفين على الأقل",
    en: "Name must be at least 2 characters",
    ku: "ناو دەبێت لانی کەم لە 2 پیت پێکبێت"
  },
  "modals.enterInstallmentPayerNameError": {
    ar: "يرجى إدخال اسم صاحب الأقساط",
    en: "Please enter installment payer name",
    ku: "تکایە ناوی خاوەن قیست بنووسە"
  },
  "modals.downPaymentNegativeError": {
    ar: "الدفعة المقدمة لا يمكن أن تكون سالبة",
    en: "Down payment cannot be negative",
    ku: "پێشەکی نابێت ژمارەی نەرێنی بێت"
  },
  "modals.downPaymentExceedsTotalError": {
    ar: "الدفعة المقدمة لا يمكن أن تتجاوز المبلغ الإجمالي",
    en: "Down payment cannot exceed total amount",
    ku: "پێشەکی نابێت لە بڕی گشتی زیاتر بێت"
  },
  "modals.enterValidPaymentAmount": {
    ar: "يرجى إدخال مبلغ دفع صالح أكبر من الصفر",
    en: "Please enter a valid payment amount greater than zero",
    ku: "تکایە بڕە پارەیەکی دروست لە سفر زیاتر بنووسە"
  },
  "modals.enterPaymentAmountError": {
    ar: "يرجى إدخال مبلغ الدفعة بشكل صحيح",
    en: "Please enter a valid payment amount",
    ku: "تکایە بڕی پارەدان بە دروستی بنووسە"
  },
  "modals.paymentExceedsRemainingError": {
    ar: "المبلغ المدخل أكبر من المبلغ المتبقي على صاحب الأقساط",
    en: "Entered amount exceeds remaining balance on client",
    ku: "بڕی نووسراو لە بڕی ماوەی سەر کڕیار زیاترە"
  },
  "modals.enterAmountGreaterThanZero": {
    ar: "يرجى إدخال مبلغ أكبر من صفر",
    en: "Please enter an amount greater than zero",
    ku: "تکایە بڕێک لە سفر زیاتر بنووسە"
  },
  "overdue.totalOverdue": {
    ar: "إجمالي المتأخرات",
    en: "Total Overdue",
    ku: "کۆی گشتی دواکەوتووەکان"
  },
  "overdue.searchPlaceholder": {
    ar: "بحث بالاسم أو الهاتف أو السلعة بين المتأخرين...",
    en: "Search by name, phone, or item among overdue...",
    ku: "گەڕان بەپێی ناو، مۆبایل، یان کاڵا لە نێوان دواکەوتووان..."
  },
  "overdue.noOverdue": {
    ar: "لا يوجد متأخرون حالياً",
    en: "No Overdue Accounts Currently",
    ku: "لە ئێستادا هیچ دواکەوتوویەک نییە"
  },
  "overdue.allSettled": {
    ar: "كافة الحسابات والأقساط مسددة أو ضمن فترات السماح المحددة",
    en: "All accounts and installments are paid or within allowed grace periods",
    ku: "هەموو هەژمار و قیستەکان دراون یان لە ماوەی ڕێگەپێدراودان"
  },
  "overdue.overdueDebts": {
    ar: "ديون متأخرة",
    en: "Overdue Debts",
    ku: "قەرزی دواکەوتوو"
  },
  "overdue.overdueInstallments": {
    ar: "أقساط مستحقة ومتأخرة",
    en: "Due & Overdue Installments",
    ku: "قیستە شایستە و دواکەوتووەکان"
  },
  "modals.paymentExceedsRemaining": {
    ar: "مبلغ الدفعة لا يمكن أن يتجاوز المبلغ المتبقي",
    en: "Payment amount cannot exceed remaining balance",
    ku: "بڕی پارەدان نابێت لە بڕی ماوە زیاتر بێت"
  },
  "modals.enterValidDebtAmount": {
    ar: "يرجى إدخال مبلغ دين صالح أكبر من الصفر",
    en: "Please enter a valid debt amount greater than zero",
    ku: "تکایە بڕی قەرزێکی دروست لە سفر زیاتر بنووسە"
  },
  "modals.selectPaymentDate": {
    ar: "يرجى تحديد تاريخ السداد",
    en: "Please select payment date",
    ku: "تکایە بەرواری پارەدان دیاریبکە"
  },
  "modals.selectDebtDate": {
    ar: "يرجى تحديد تاريخ الدين",
    en: "Please select debt date",
    ku: "تکایە بەرواری قەرز دیاریبکە"
  },
  "modals.paymentRecordedSuccess": {
    ar: "تم تسجيل وتوثيق عملية السداد بنجاح",
    en: "Payment transaction recorded successfully",
    ku: "کرداری پارەدان بە سەرکەوتوویی تۆمارکرا"
  },
  "modals.debtAddedSuccess": {
    ar: "تمت إضافة الدين وتحديث الرصيد القائم بنجاح",
    en: "Debt added and balance updated successfully",
    ku: "قەرز زیادکرا و باڵانس بە سەرکەوتوویی نوێکرایەوە"
  },
  "modals.confirmDeleteTitle": {
    ar: "تأكيد حذف المدين",
    en: "Confirm Delete Debtor",
    ku: "دڵنیابوونەوە لە سڕینەوەی قەرزدار"
  },
  "modals.confirmDeleteDesc": {
    ar: "هل أنت متأكد من حذف هذا المدين؟ سيتم حذف كافة سجلات المعاملات والديون المرتبطة به نهائياً.",
    en: "Are you sure you want to delete this debtor? All associated records and transactions will be permanently removed.",
    ku: "ئایا دڵنیایت لە سڕینەوەی ئەم قەرزدارە؟ هەموو تۆمار و مامەڵەکانی پەیوەست بە تەواوی دەسڕێنەوە."
  },
  "modals.trialLimitInstallmentsMessage": {
    ar: "تم الوصول للحد الأقصى للنسخة التجريبية ({count} من أصحاب الأقساط فقط)",
    en: "Trial limit reached ({count} installment contracts only)",
    ku: "گەیشتوویتە سنووری وەشانی تاقیکاری (تەنها {count} خاوەن قیست)"
  },
  "modals.trialLimitDebtsMessage": {
    ar: "تم الوصول للحد الأقصى للنسخة التجريبية ({count} مدينين فقط)",
    en: "Trial limit reached ({count} debtors only)",
    ku: "گەیشتوویتە سنووری وەشانی تاقیکاری (تەنها {count} قەرزدار)"
  },
  "modals.trialBenefitsHeader": {
    ar: "يرجى الاشتراك في النسخة الكاملة من خلال مراسلة الإدارة للاستفادة من:",
    en: "Subscribe to the full version by contacting administration to enjoy:",
    ku: "تکایە بەشداری وەشانی تەواو بکە لەڕێگەی پەیوەندی بە بەڕێوەبەرایەتی بۆ سوودمەندبوون لە:"
  },
  "modals.trialBenefit1Debts": {
    ar: "تسجيل عدد غير محدود من المدينين والعمليات",
    en: "Unlimited debtors and transactions registration",
    ku: "تۆمارکردنی بێسنووری قەرزداران و مامەڵەکان"
  },
  "modals.trialBenefit1Installments": {
    ar: "تسجيل عدد غير محدود من أصحاب الأقساط والعمليات",
    en: "Unlimited installment contracts and transactions",
    ku: "تۆمارکردنی بێسنووری خاوەن قیستەکان و مامەڵەکان"
  },
  "modals.trialBenefit2": {
    ar: "مزامنة سحابية مشفرة وفورية لحماية بياناتك",
    en: "Real-time encrypted cloud sync to safeguard your data",
    ku: "هاوکاتکردنی هەوری پارێزراو و خێرا بۆ پاراستنی زانیارییەکانت"
  },
  "modals.trialBenefit3": {
    ar: "نسخ احتياطي واسترجاع متقدم وكشوفات حساب مفصلة",
    en: "Advanced backup, restore, and detailed account statements",
    ku: "پاشەکەوتی یەدەگ و گەڕاندنەوەی پێشکەوتوو و ڕاپۆرتی ورد"
  },
  "modals.trialWhatsAppMessageInstallments": {
    ar: "السلام عليكم، أود تفعيل النسخة الكاملة من نظام الأقساط ودفتر الديون لفتح عدد غير محدود من أصحاب الأقساط والمدينين والمزامنة السحابية.",
    en: "Hello, I would like to activate the full version of the Installments & Debt Ledger system for unlimited clients and cloud sync.",
    ku: "سڵاو، دەمەوێت وەشانی تەواوی سیستەمی قیست و دەفتەری قەرز چالاک بکەم بۆ کڕیاری بێسنوور و هاوکاتکردنی هەور."
  },
  "modals.trialWhatsAppMessageDebts": {
    ar: "السلام عليكم، أود تفعيل النسخة الكاملة من تطبيق دفتر الديون لفتح عدد غير محدود من المدينين والمزامنة السحابية.",
    en: "Hello, I would like to activate the full version of the Debt Ledger app for unlimited debtors and cloud sync.",
    ku: "سڵاو، دەمەوێت وەشانی تەواوی بەرنامەی دەفتەری قەرز چالاک بکەم بۆ قەرزداری بێسنوور و هاوکاتکردنی هەور."
  },

  // common
  "common.errorOccurred": {
    ar: "حدث خطأ أثناء تنفيذ العملية",
    en: "An error occurred during execution",
    ku: "هەڵەیەک ڕوویدا لە کاتی جێبەجێکردندا"
  },
  "common.saving": {
    ar: "جاري الحفظ...",
    en: "Saving...",
    ku: "پاشەکەوت دەکرێت..."
  },
  "common.clickToEnable": {
    ar: "اضغط للتفعيل",
    en: "Click to enable",
    ku: "کلیک بکە بۆ چالاککردن"
  },
  "common.automatic": {
    ar: "تلقائي",
    en: "Automatic",
    ku: "خۆکار"
  },
  "common.confirmDelete": {
    ar: "تأكيد الحذف",
    en: "Confirm Delete",
    ku: "دڵنیابوونەوە لە سڕینەوە"
  },
  "common.deleting": {
    ar: "جاري الحذف...",
    en: "Deleting...",
    ku: "دەسڕدرێتەوە..."
  },
  "common.networkError": {
    ar: "تعذر الاتصال بالخادم، يرجى المحاولة لاحقاً",
    en: "Could not connect to server, please try again later",
    ku: "پەیوەندی بە سێرڤەر نەکرا، تکایە دواتر هەوڵبدەرەوە"
  },
  "common.branch": {
    ar: "الفرع",
    en: "Branch",
    ku: "لق"
  },
  "common.viewHistory": {
    ar: "عرض السجل",
    en: "View History",
    ku: "پیشاندانی مێژوو"
  },
  "common.copiedToClipboard": {
    ar: "تم النسخ إلى الحافظة بنجاح",
    en: "Copied to clipboard successfully",
    ku: "بە سەرکەوتوویی لەبەرگیرایەوە"
  },
  "common.syncError": {
    ar: "حدث خطأ في المزامنة",
    en: "Sync error occurred",
    ku: "هەڵەیەک لە هاوکاتکردندا ڕوویدا"
  },
  "common.processing": {
    ar: "جاري المعالجة...",
    en: "Processing...",
    ku: "لە پرۆسەدایە..."
  },
  "common.regularDebt": {
    ar: "دين عادي",
    en: "Regular Debt",
    ku: "قەرزی ئاسایی"
  },
  "common.installments": {
    ar: "أقساط شهرية",
    en: "Monthly Installments",
    ku: "قیستی مانگانە"
  },

  // debtors
  "debtors.addDebtor": {
    ar: "إضافة مدين جديد",
    en: "Add New Debtor",
    ku: "زیادکردنی قەرزداری نوێ"
  },
  "debtors.addDebtorSubtitle": {
    ar: "تسجيل حساب دين جديد في الدفتر",
    en: "Register new debt account in ledger",
    ku: "تۆمارکردنی هەژماری قەرزی نوێ لە دەفتەر"
  },
  "debtors.saveDebtor": {
    ar: "حفظ المدين",
    en: "Save Debtor",
    ku: "پاشەکەوتکردنی قەرزدار"
  },
  "debtors.editDebtorInfo": {
    ar: "تعديل بيانات المدين",
    en: "Edit Debtor Info",
    ku: "دەستکاریکردنی زانیاری قەرزدار"
  },
  "debtors.updateNameAndPhone": {
    ar: "تحديث الاسم ورقم الهاتف",
    en: "Update Name and Phone Number",
    ku: "نوێکردنەوەی ناو و ژمارەی مۆبایل"
  },
  "debtors.currentInfo": {
    ar: "البيانات الحالية",
    en: "Current Information",
    ku: "زانیارییەکانی ئێستا"
  },
  "debtors.saveChanges": {
    ar: "حفظ التعديلات",
    en: "Save Changes",
    ku: "پاشەکەوتکردنی گۆڕانکارییەکان"
  },
  "debtors.shareStatement": {
    ar: "إرسال تذكير بالاستحقاق عبر واتساب",
    en: "Send payment reminder via WhatsApp",
    ku: "ناردنی بیرخستنەوەی پارەدان لەڕێگەی واتسئەپ"
  },
  "debtors.nationalId": {
    ar: "رقم البطاقة الوطنية",
    en: "National ID Number",
    ku: "ژمارەی کارتی نیشتمانی"
  },
  "debtors.address": {
    ar: "عنوان السكن",
    en: "Residential Address",
    ku: "ناونیشانی نیشتەجێبوون"
  },
  "debtors.callPhone": {
    ar: "اتصال بالهاتف",
    en: "Call Phone",
    ku: "پەیوەندی تەلەفۆنی"
  },
  "debtors.noPhone": {
    ar: "بدون هاتف",
    en: "No Phone",
    ku: "بێ ژمارەی مۆبایل"
  },
  "debtors.overdue": {
    ar: "متأخر",
    en: "Overdue",
    ku: "دواکەوتوو"
  },
  "debtors.highDebtBadge": {
    ar: "مرتفع",
    en: "High Debt",
    ku: "قەرزی بەرز"
  },
  "debtors.whatsappReminder": {
    ar: "تذكير واتساب",
    en: "WhatsApp Reminder",
    ku: "بیرخستنەوەی واتسئەپ"
  },
  "debtors.payDebt": {
    ar: "تسديد مبلغ",
    en: "Make Payment",
    ku: "دانەوەی بڕە پارە"
  },
  "debtors.toggleOverdue": {
    ar: "تبديل حالة التأخير",
    en: "Toggle Overdue Status",
    ku: "گۆڕینی دۆخی دواکەوتن"
  },
  "debtors.deleteDebtorPermanently": {
    ar: "حذف المدين نهائياً",
    en: "Delete Debtor Permanently",
    ku: "سڕینەوەی قەرزدار بە یەکجاری"
  },

  // debts
  "debts.debtorName": {
    ar: "اسم المدين",
    en: "Debtor Name",
    ku: "ناوی قەرزدار"
  },
  "debts.phoneNumber": {
    ar: "رقم الهاتف",
    en: "Phone Number",
    ku: "ژمارەی مۆبایل"
  },
  "debts.initialDebtAmount": {
    ar: "مبلغ الدين الأولي",
    en: "Initial Debt Amount",
    ku: "بڕی قەرزی سەرەتایی"
  },
  "debts.debtRegistrationDate": {
    ar: "تاريخ تسجيل الدين",
    en: "Debt Registration Date",
    ku: "بەرواری تۆمارکردنی قەرز"
  },
  "debts.emptyNoPhone": {
    ar: "لا يوجد رقم هاتف لهذا المدين",
    en: "No phone number available for this debtor",
    ku: "هیچ ژمارەی مۆبایلێک بۆ ئەم قەرزدارە نییە"
  },
  "debts.invalidPhone": {
    ar: "رقم الهاتف غير صحيح أو مكتوب بصيغة خاطئة",
    en: "Phone number is invalid or improperly formatted",
    ku: "ژمارەی مۆبایل نادروستە یان بە شێوازێکی هەڵە نووسراوە"
  },
  "debts.totalDebt": {
    ar: "الرصيد القائم",
    en: "Outstanding Balance",
    ku: "باڵانسی ماوە"
  },
  "debts.fullDebtSettledTitle": {
    ar: "تم تسديد كامل المبلغ",
    en: "Full Balance Settled",
    ku: "تەواوی بڕی پارەکە درایەوە"
  },
  "debts.fullDebtSettledDesc": {
    ar: "قام المدين بتسديد كافة المستحقات المترتبة بذمته بالكامل وأصبح رصيده",
    en: "The debtor has paid all dues completely and the balance is now",
    ku: "قەرزدار هەموو شایستە داراییەکانی بە تەواوی داوەتەوە و باڵانسەکەی ئێستا بووە بە"
  },
  "debts.settleKeepOrDeletePrompt": {
    ar: "هل ترغب في الاحتفاظ بالمدين في سجلك (ضمن قائمة خالي من الدين)، أم حذفه نهائياً؟",
    en: "Would you like to keep the debtor in your records (under Debt Free list), or delete permanently?",
    ku: "ئایا دەتەوێت قەرزدار لە تۆمارەکانتدا بمێنێتەوە (لە لیستی بێ قەرز)، یان بە یەکجاری بسڕدرێتەوە؟"
  },
  "debts.keepDebtorRecord": {
    ar: "الاحتفاظ بالمدين في السجل",
    en: "Keep Debtor in Records",
    ku: "هێشتنەوەی قەرزدار لە تۆماردا"
  },
  "debts.payAmount": {
    ar: "تسديد مبلغ من الدين",
    en: "Pay Debt Amount",
    ku: "دانەوەی بڕێک لە قەرز"
  },
  "debts.addDebt": {
    ar: "إضافة دين جديد",
    en: "Add New Debt",
    ku: "زیادکردنی قەرزی نوێ"
  },
  "debts.currentDebt": {
    ar: "الدين الحالي",
    en: "Current Debt",
    ku: "قەرزی ئێستا"
  },
  "debts.balanceAfterAction": {
    ar: "الرصيد بعد العملية",
    en: "Balance After Transaction",
    ku: "باڵانس دوای کرداری مامەڵە"
  },
  "debts.paidAmount": {
    ar: "المبلغ المسدد",
    en: "Paid Amount",
    ku: "بڕی دراو"
  },
  "debts.additionalDebtAmount": {
    ar: "مبلغ الدين الإضافي",
    en: "Additional Debt Amount",
    ku: "بڕی قەرزی زیاتر"
  },
  "debts.fullAmount": {
    ar: "كامل المبلغ",
    en: "Full Amount",
    ku: "تەواوی بڕەکە"
  },
  "debts.paymentPlaceholder": {
    ar: "مثال: تسديد نقدي، حوالة، دفعة أسبوعية...",
    en: "e.g. Cash payment, bank transfer, weekly payment...",
    ku: "نموونە: پارەدانی نەختینە، حەواڵە، پارەدانی هەفتانە..."
  },
  "debts.debtPlaceholder": {
    ar: "مثال: بضاعة، كارت شحن، مسواك...",
    en: "e.g. Goods, recharge cards, grocery...",
    ku: "نموونە: کەلوپەل، کارتی باڵانس، پێداویستی ڕۆژانە..."
  },
  "debts.paymentDate": {
    ar: "تاريخ التسديد",
    en: "Payment Date",
    ku: "بەرواری پارەدان"
  },
  "debts.resetToToday": {
    ar: "إعادة لتاريخ اليوم",
    en: "Reset to Today",
    ku: "گەڕاندنەوە بۆ بەرواری ئەمڕۆ"
  },
  "debts.todayDate": {
    ar: "تاريخ اليوم",
    en: "Today's Date",
    ku: "بەرواری ئەمڕۆ"
  },
  "debts.confirmPayment": {
    ar: "تأكيد التسديد",
    en: "Confirm Payment",
    ku: "دڵنیابوونەوە لە پارەدان"
  },
  "debts.confirmAddition": {
    ar: "تأكيد الإضافة",
    en: "Confirm Addition",
    ku: "دڵنیابوونەوە لە زیادکردن"
  },

  // installments
  "installments.downPaymentNote": {
    ar: "الدفعة المقدمة عند التسجيل",
    en: "Down payment upon registration",
    ku: "بڕی پێشەکی لە کاتی تۆمارکردندا"
  },
  "installments.installmentsManagement": {
    ar: "نظام إدارة الأقساط الشهرية",
    en: "Monthly Installments Management",
    ku: "سیستەمی بەڕێوەبردنی قیستی مانگانە"
  },
  "installments.debtorName": {
    ar: "اسم صاحب الأقساط",
    en: "Installment Payer Name",
    ku: "ناوی خاوەن قیست"
  },
  "installments.itemName": {
    ar: "السلعة المباعة",
    en: "Sold Item / Description",
    ku: "کاڵای فرۆشراو"
  },
  "installments.downPaymentShort": {
    ar: "المقدم",
    en: "Down Payment",
    ku: "پێشەکی"
  },
  "installments.remainingToPay": {
    ar: "المتبقي بالأقساط المطلوب تسديده",
    en: "Remaining Balance to Collect",
    ku: "بڕی ماوە بۆ دانەوە"
  },
  "installments.totalMinusDownPayment": {
    ar: "الإجمالي - الدفعة المقدمة",
    en: "Total - Down Payment",
    ku: "گشتی - پێشەکی"
  },
  "installments.guarantorInfo": {
    ar: "بيانات الكفيل",
    en: "Guarantor Information",
    ku: "زانیارییەکانی کەفیل"
  },
  "installments.dueDateMonthly": {
    ar: "تاريخ الاستحقاق (بعد شهر)",
    en: "Due Date (in 1 month)",
    ku: "بەرواری دانەوە (دوای یەک مانگ)"
  },
  "installments.saveInstallment": {
    ar: "حفظ معاملة القسط",
    en: "Save Installment Contract",
    ku: "پاشەکەوتکردنی مامەڵەی قیست"
  },
  "installments.editInstallmentTransaction": {
    ar: "تعديل تفاصيل معاملة القسط",
    en: "Edit Installment Details",
    ku: "دەستکاریکردنی وردەکارییەکانی قیست"
  },
  "installments.clientName": {
    ar: "اسم صاحب الأقساط",
    en: "Client Name",
    ku: "ناوی کڕیار"
  },
  "installments.itemPurchased": {
    ar: "السلعة المباعة",
    en: "Purchased Item",
    ku: "کاڵای کڕدراو"
  },
  "installments.totalMinusPaid": {
    ar: "الإجمالي - المقدم - الدفعات المسددة",
    en: "Total - Down Payment - Paid Installments",
    ku: "گشتی - پێشەکی - پارە دراوەکان"
  },
  "installments.dueDate": {
    ar: "تاريخ الاستحقاق القادم",
    en: "Next Due Date",
    ku: "بەرواری دانەوەی داهاتوو"
  },
  "installments.guarantor": {
    ar: "الكفيل",
    en: "Guarantor",
    ku: "کەفیل"
  },
  "installments.payInstallment": {
    ar: "تسديد قسط",
    en: "Pay Installment",
    ku: "دانەوەی قیست"
  },
  "installments.progressStatus": {
    ar: "نسبة الإنجاز وسداد القسط",
    en: "Installment Settlement Progress",
    ku: "ڕێژەی تەواوبوون و دانەوەی قیست"
  },
  "installments.idAndAddress": {
    ar: "بيانات التعريف والعنوان",
    en: "Identification & Address",
    ku: "زانیاری ناسنامە و ناونیشان"
  },
  "installments.searchPlaceholder": {
    ar: "ابحث بالاسم أو السلعة أو رقم الهاتف...",
    en: "Search by name, item, or phone...",
    ku: "گەڕان بەپێی ناو، کاڵا، یان مۆبایل..."
  },
  "installments.noFilteredInstallments": {
    ar: "لا توجد معاملات أقساط مطابقة للفلتر المحدد",
    en: "No installment contracts match selected filter",
    ku: "هیچ مامەڵەیەکی قیست هاوتای ئەم فلتەرە نییە"
  },
  "installments.regDate": {
    ar: "التسجيل",
    en: "Registration",
    ku: "تۆمارکردن"
  },
  "installments.remaining": {
    ar: "المتبقي للتحصيل",
    en: "Remaining to Collect",
    ku: "ماوە بۆ کۆکردنەوە"
  },
  "installments.noSearchResults": {
    ar: "لم يتم العثور على أي قسط يطابق بحثك",
    en: "No installment contract matches your search",
    ku: "هیچ قیستێک نەدۆزرایەوە کە هاوتای گەڕانەکەت بێت"
  },
  "installments.noSearchResultsDesc": {
    ar: "جرّب البحث باسم آخر أو إزالة التصفية",
    en: "Try searching with another keyword or clear filters",
    ku: "هەوڵبدە بە ناوێکی تر بگەڕێیت یان فلتەرەکان لابدەیت"
  },
  "installments.addFirstInstallment": {
    ar: "تسجيل أول معاملة قسط",
    en: "Register First Installment Contract",
    ku: "تۆمارکردنی یەکەمین مامەڵەی قیست"
  },
  "installments.settlePayment": {
    ar: "تسديد دفعة / قسط شهري",
    en: "Settle Payment / Monthly Installment",
    ku: "دانەوەی بڕە پارە / قیستی مانگانە"
  },
  "installments.currentRemaining": {
    ar: "المبلغ المتبقي حالياً",
    en: "Current Remaining Balance",
    ku: "بڕی ماوەی ئێستا"
  },
  "installments.receivedPaymentAmount": {
    ar: "مبلغ الدفعة المستلمة",
    en: "Received Payment Amount",
    ku: "بڕی پارەی وەرگیراو"
  },
  "installments.payFullRemaining": {
    ar: "تسديد كامل المتبقي",
    en: "Pay Full Remaining",
    ku: "دانەوەی تەواوی ماوە"
  },
  "installments.remainingAfterPayment": {
    ar: "المتبقي بعد هذه الدفعة",
    en: "Remaining After This Payment",
    ku: "ماوە دوای ئەم پارەدانە"
  },
  "installments.willBeClosedFullSettlement": {
    ar: "سيتم إغلاق القسط وتسجيله كـ 'مسدد بالكامل'",
    en: "The installment contract will be closed as 'Fully Paid'",
    ku: "مامەڵەی قیستەکە دادەخرێت و وەک 'تەواو دراوە' تۆمار دەکرێت"
  },
  "installments.nextDueDateAutoDeferred": {
    ar: "سيتم ترحيل موعد الاستحقاق القادم تلقائياً إلى الشهر التالي",
    en: "Next due date will automatically advance to next month",
    ku: "بەرواری دانەوەی داهاتوو خۆکارانە دەگوازرێتەوە بۆ مانگی دواتر"
  },
  "installments.confirmPayment": {
    ar: "تأكيد استلام الدفعة",
    en: "Confirm Payment Receipt",
    ku: "دڵنیابوونەوە لە وەرگرتنی پارە"
  },
  "installments.firstDueDate": {
    ar: "تاريخ الاستحقاق الأول (بعد شهر)",
    en: "First Due Date (in 1 month)",
    ku: "یەکەم بەرواری دانەوە (دوای یەک مانگ)"
  },
  "installments.setsMonthlyDueDate": {
    ar: "يحدد موعد الاستحقاق الشهري",
    en: "Sets monthly payment schedule",
    ku: "دیاریکردنی خشتەی مانگانەی دانەوە"
  },

  // nav
  "nav.mainNav": {
    ar: "التنقل الرئيسي",
    en: "Main Navigation",
    ku: "ڕێدۆزی سەرەکی"
  },
  "nav.add": {
    ar: "إضافة",
    en: "Add",
    ku: "زیادکردن"
  },
  "nav.debts": {
    ar: "الديون",
    en: "Debts",
    ku: "قەرزەکان"
  },

  // debtorHistory
  "debtorHistory.initialBalance": {
    ar: "فتح حساب وتسجيل الرصيد الأولي",
    en: "Account opening and initial balance",
    ku: "کردنەوەی هەژمار و تۆمارکردنی باڵانسی سەرەتایی"
  },

  // header
  "header.contactAdmin": {
    ar: "مراسلة الإدارة لتفعيل النسخة الكاملة",
    en: "Contact Admin to Activate Full Version",
    ku: "پەیوەندی بە بەڕێوەبەرایەتی بۆ چالاککردنی وەشانی تەواو"
  },

  // managers
  "managers.username": {
    ar: "اسم المستخدم",
    en: "Username",
    ku: "ناوی بەکارهێنەر"
  },
  "managers.password": {
    ar: "الرمز السري",
    en: "Password",
    ku: "تێپەڕەوشە"
  },
  "managers.branch": {
    ar: "اسم الفرع / المتجر",
    en: "Branch / Store Name",
    ku: "ناوی لق / فرۆشگا"
  },
  "managers.createBtn": {
    ar: "إنشاء حساب المدير الفرعي",
    en: "Create Branch Manager Account",
    ku: "دروستکردنی هەژماری بەڕێوەبەری لق"
  },
  "managers.delete": {
    ar: "حذف",
    en: "Delete",
    ku: "سڕینەوە"
  },

  // secretAdmin
  "secretAdmin.connectionSafe": {
    ar: "الاتصال بقاعدة البيانات مشفر ومحمي وآمن 100%!",
    en: "Database connection is 100% encrypted, secure, and protected!",
    ku: "پەیوەندی بە بنکەدراوە ١٠٠٪ پارێزراو و کۆدکراوە!"
  },
  "secretAdmin.unlockedBadge": {
    ar: "تم الفتح بـ 3 نقرات",
    en: "Unlocked with 3 clicks",
    ku: "بە ٣ کرتەکردن کرایەوە"
  },
  "secretAdmin.securityShieldTitle": {
    ar: "نظام الحماية العالمي (Zero-Token Architecture)",
    en: "Security Shield Architecture (Zero-Token)",
    ku: "سیستەمی پاراستنی جیهانی (Zero-Token)"
  },
  "secretAdmin.shieldActive": {
    ar: "درع نشط 100%",
    en: "Active Shield 100%",
    ku: "قەڵغانی چالاک ١٠٠٪"
  },
  "secretAdmin.shieldDesc": {
    ar: "كود التطبيق ونسخة الـ APK خالية تماماً من رمز قاعدة البيانات السري ورابطها المباشر. جميع الطلبات تمر حصرياً عبر جدار ناري خادم مع فحص Anti-SQL Injection.",
    en: "The application code and APK build are completely clean of raw database credentials. All requests route securely through server firewall with anti-injection protections.",
    ku: "کۆدی بەرنامەکە و وەشانی APK بە تەواوی پاکە لە تێپەڕەوشەی بنکەدراوە. هەموو داواکارییەکان لەڕێگەی خزمەتگوزاری پارێزراوەوە دەڕۆن."
  },
  "secretAdmin.serverUrlLabel": {
    ar: "رابط خادم التطبيق (APK & Hosting Server URL)",
    en: "Server URL (APK & Hosting)",
    ku: "ناونیشانی سێرڤەری بەرنامە (APK & Hosting)"
  },
  "secretAdmin.defaultAuto": {
    ar: "الافتراضي تلقائي",
    en: "Default (Auto)",
    ku: "بنەڕەتی (خۆکار)"
  },
  "secretAdmin.serverUrlDesc": {
    ar: "عند تحويل التطبيق إلى ملف APK أو رفعه على استضافة خاصة بك، يمكنك ربطه بعنوان خادم الـ API هنا:",
    en: "When packaging app into APK or hosting on custom domain, set your backend API URL here:",
    ku: "کاتی گۆڕینی بەرنامە بۆ APK یان هۆستکردنی لەسەر سێرڤەری خۆت، ناونیشانی سێرڤەر لێرە دیاریبکە:"
  },
  "secretAdmin.testDbConnection": {
    ar: "فحص الاتصال بقاعدة البيانات السحابية",
    en: "Test Cloud Database Connection",
    ku: "تاقیکردنەوەی پەیوەندی بە بنکەدراوەی هەور"
  },
  "secretAdmin.testNow": {
    ar: "فحص الآن",
    en: "Test Now",
    ku: "ئێستا تاقی بکەرەوە"
  },
  "secretAdmin.responseTime": {
    ar: "زمن الاستجابة",
    en: "Response Time",
    ku: "کاتی وەڵامدانەوە"
  },

  // status
  "status.debtFree": {
    ar: "خالي من الدين",
    en: "Debt Free",
    ku: "بێ قەرز"
  },

  // reports
  "reports.registeredContracts": {
    ar: "معاملة مسجلة",
    en: "Registered Contracts",
    ku: "مامەڵەی تۆمارکراو"
  },
  "reports.collectedInstallments": {
    ar: "المحصل (مقدمات ودفعات)",
    en: "Collected (Down & Payments)",
    ku: "کۆکراوە (پێشەکی و قیستەکان)"
  },
  "reports.collectionRatio": {
    ar: "نسبة التحصيل",
    en: "Collection Ratio",
    ku: "ڕێژەی کۆکردنەوە"
  },
  "reports.remainingToCollect": {
    ar: "المتبقي المطلوب تحصيله",
    en: "Remaining to Collect",
    ku: "بڕی ماوە بۆ کۆکردنەوە"
  },
  "reports.dueInstallmentsCount": {
    ar: "أقساط مستحقة حالياً",
    en: "Currently Due Installments",
    ku: "قیستە شایستەکانی ئێستا"
  },
  "reports.completedContracts": {
    ar: "المعاملات المكتملة",
    en: "Completed Contracts",
    ku: "مامەڵە تەواوبووەکان"
  },
  "reports.contracts": {
    ar: "معاملة",
    en: "contracts",
    ku: "مامەڵە"
  },
  "reports.fullySettled": {
    ar: "مسددة بالكامل",
    en: "Fully Settled",
    ku: "بە تەواوی دراوەتەوە"
  },
  "reports.allInstallments": {
    ar: "كافة الأقساط",
    en: "All Installments",
    ku: "هەموو قیستەکان"
  },
  "reports.dueAndOverdue": {
    ar: "المستحقة والمتأخرة",
    en: "Due and Overdue",
    ku: "شایستە و دواکەوتووەکان"
  },
  "reports.active": {
    ar: "النشطة",
    en: "Active",
    ku: "چالاکەکان"
  },
  "reports.completed": {
    ar: "المسددة بالكامل",
    en: "Fully Paid",
    ku: "تەواو دراوەکان"
  },
  "reports.outOf": {
    ar: "من أصل",
    en: "out of",
    ku: "لە کۆی"
  },
  "reports.paymentsHistory": {
    ar: "سجل الدفعات والتسديدات",
    en: "Payments & Settlements Log",
    ku: "تۆماری پارەدان و دانەوەکان"
  },
  "reports.noPaymentsYet": {
    ar: "لا توجد دفعات مسددة بعد",
    en: "No payments recorded yet",
    ku: "تا ئێستا هیچ پارەدانێک تۆمار نەکراوە"
  },
  "reports.debtsOnly": {
    ar: "الديون",
    en: "Debts",
    ku: "قەرزەکان"
  },
  "reports.installmentsOnly": {
    ar: "الأقساط",
    en: "Installments",
    ku: "قیستەکان"
  },
  "reports.allModules": {
    ar: "الكل",
    en: "All",
    ku: "هەموو"
  },
  "reports.initialBalance": {
    ar: "رصيد افتتاحي / دين سابق",
    en: "Opening Balance / Previous Debt",
    ku: "باڵانسی سەرەتایی / قەرزی پێشوو"
  },
  "reports.allPeriods": {
    ar: "الإجمالي العام لكافة الفترات",
    en: "Overall Total for All Periods",
    ku: "کۆی گشتی بۆ هەموو ماوەکان"
  },
  "reports.today": {
    ar: "اليوم",
    en: "Today",
    ku: "ئەمڕۆ"
  },
  "reports.thisWeek": {
    ar: "هذا الأسبوع (آخر 7 أيام)",
    en: "This Week (Last 7 Days)",
    ku: "ئەم هەفتەیە (٧ ڕۆژی ڕابردوو)"
  },
  "reports.thisMonth": {
    ar: "هذا الشهر",
    en: "This Month",
    ku: "ئەم مانگە"
  },
  "reports.lastMonth": {
    ar: "الشهر السابق",
    en: "Last Month",
    ku: "مانگی پێشوو"
  },
  "reports.customPeriod": {
    ar: "فترة مخصصة",
    en: "Custom Range",
    ku: "ماوەی دیاریکراو"
  },
  "reports.mainBranch": {
    ar: "الفرع الرئيسي",
    en: "Main Branch",
    ku: "لقی سەرەکی"
  },
  "reports.financialReport": {
    ar: "تقرير الحركة المالية وسجل المدينين",
    en: "Financial Statement & Debtors Log",
    ku: "ڕاپۆرتی جووڵەی دارایی و تۆماری قەرزداران"
  },
  "reports.branch": {
    ar: "الفرع",
    en: "Branch",
    ku: "لق"
  },
  "reports.user": {
    ar: "المستخدم",
    en: "User",
    ku: "بەکارهێنەر"
  },
  "reports.period": {
    ar: "الفترة",
    en: "Period",
    ku: "ماوە"
  },
  "reports.exportDate": {
    ar: "تاريخ الاستخراج",
    en: "Export Date",
    ku: "بەرواری دەرکردن"
  },
  "reports.operations": {
    ar: "عملية",
    en: "transactions",
    ku: "مامەڵە"
  },
  "reports.totalAmountsPaid": {
    ar: "إجمالي المبالغ المسددة للفترة",
    en: "Total Amounts Collected in Period",
    ku: "کۆی گشتی بڕە پارەی کۆکراوە لە ماوەکەدا"
  },
  "reports.netMovement": {
    ar: "صافي الحركة",
    en: "Net Movement",
    ku: "جووڵەی پوختە"
  },
  "reports.currentActiveDebts": {
    ar: "إجمالي الديون القائمة حالياً",
    en: "Total Active Outstanding Debt",
    ku: "کۆی گشتی قەرزە ماوەکانی ئێستا"
  },
  "reports.activeDebtorsInPeriod": {
    ar: "المدينين المتفاعلين في الفترة",
    en: "Active Debtors in Period",
    ku: "قەرزدارانی چالاک لە ماوەکەدا"
  },
  "reports.detailsByDebtor": {
    ar: "تفاصيل وسجل العمليات حسب المدينين",
    en: "Details & Transaction Log by Debtor",
    ku: "وردەکاری و تۆماری مامەڵەکان بەپێی قەرزدار"
  },
  "reports.outstandingBalance": {
    ar: "الرصيد القائم",
    en: "Outstanding Balance",
    ku: "باڵانسی ماوە"
  },
  "reports.debtsAdded": {
    ar: "ديون أضيفت",
    en: "Debts Added",
    ku: "قەرزی زیادکراو"
  },
  "reports.debtsPaid": {
    ar: "مسددات",
    en: "Payments",
    ku: "دراوەکان"
  },
  "reports.transactionsLog": {
    ar: "سجل الحركات",
    en: "Transactions Log",
    ku: "تۆماری جووڵەکان"
  },
  "reports.payment": {
    ar: "سداد",
    en: "Payment",
    ku: "دانەوە"
  },
  "reports.debt": {
    ar: "دين",
    en: "Debt",
    ku: "قەرز"
  },
  "reports.note": {
    ar: "ملاحظة",
    en: "Note",
    ku: "تێبینی"
  },
  "reports.andMoreTransactions": {
    ar: "وحركات أخرى",
    en: "and other transactions",
    ku: "و جووڵەی تر"
  },
  "reports.noTransactionsInPeriod": {
    ar: "لا توجد حركات مسجلة خلال هذه الفترة.",
    en: "No transactions recorded during this period.",
    ku: "هیچ جووڵەیەک لەم ماوەیەدا تۆمار نەکراوە."
  },
  "reports.reportCopiedSuccess": {
    ar: "تم نسخ التقرير المالي بنجاح",
    en: "Financial report copied successfully",
    ku: "ڕاپۆرتی دارایی بە سەرکەوتوویی لەبەرگیرایەوە"
  },
  "reports.copyFailed": {
    ar: "تعذر النسخ تلقائياً، يرجى المحاولة يدوياً",
    en: "Auto-copy failed, please copy manually",
    ku: "لەبەرگرتنەوەی خۆکار سەرکەوتوو نەبوو، تکایە بە دەست لەبەری بگرەوە"
  },
  "reports.debtsAndOpsReports": {
    ar: "تقارير الديون والعمليات",
    en: "Debts & Operations Reports",
    ku: "ڕاپۆرتەکانی قەرز و مامەڵەکان"
  },
  "reports.installmentsReports": {
    ar: "تقارير الأقساط الشهرية",
    en: "Monthly Installments Reports",
    ku: "ڕاپۆرتەکانی قیستی مانگانە"
  },
  "reports.debtBook": {
    ar: "دفتر الديون",
    en: "Debt Ledger",
    ku: "دەفتەری قەرز"
  },
  "reports.installmentsSystem": {
    ar: "نظام الأقساط",
    en: "Installments System",
    ku: "سیستەمی قیست"
  },
  "reports.debtsReports": {
    ar: "تقارير الديون",
    en: "Debts Reports",
    ku: "ڕاپۆرتەکانی قەرز"
  },
  "reports.debtorOperationsLog": {
    ar: "سجل العمليات المنسدل لكل مدين",
    en: "Expandable Transactions Log per Debtor",
    ku: "تۆماری مامەڵەی هەر قەرزدارێک"
  },
  "reports.collectionTrackingContracts": {
    ar: "تحصيل ومتابعة عقود الأقساط",
    en: "Collection & Tracking of Installment Contracts",
    ku: "کۆکردنەوە و بەدواداچوونی گرێبەستەکانی قیست"
  },
  "reports.copyReportTitle": {
    ar: "نسخ التقرير إلى الحافظة",
    en: "Copy Report to Clipboard",
    ku: "لەبەرگرتنەوەی ڕاپۆرت بۆ کلیپبۆرد"
  },
  "reports.copied": {
    ar: "تم النسخ",
    en: "Copied",
    ku: "لەبەرگیرایەوە"
  },
  "reports.copyReport": {
    ar: "نسخ التقرير",
    en: "Copy Report",
    ku: "لەبەرگرتنەوەی ڕاپۆرت"
  },
  "reports.shareWhatsAppTitle": {
    ar: "مشاركة التقرير عبر واتساب",
    en: "Share Report via WhatsApp",
    ku: "هاوبەشکردنی ڕاپۆرت لەڕێگەی واتسئەپ"
  },
  "reports.shareWhatsApp": {
    ar: "مشاركة واتساب",
    en: "WhatsApp Share",
    ku: "هاوبەشکردنی واتسئەپ"
  },
  "reports.selectTimePeriod": {
    ar: "تحديد الفترة الزمنية للتقرير:",
    en: "Select Report Time Period:",
    ku: "دیاریکردنی ماوەی کاتیی ڕاپۆرت:"
  },
  "reports.viewAll": {
    ar: "عرض الكل",
    en: "View All",
    ku: "پیشاندانی هەموو"
  },
  "reports.fromDateStart": {
    ar: "من تاريخ (بداية الفترة)",
    en: "From Date (Start of Period)",
    ku: "لە بەرواری (دەستپێکی ماوە)"
  },
  "reports.toDateEnd": {
    ar: "إلى تاريخ (نهاية الفترة)",
    en: "To Date (End of Period)",
    ku: "بۆ بەرواری (کۆتایی ماوە)"
  },
  "reports.addedDebts": {
    ar: "الديون المضافة",
    en: "Added Debts",
    ku: "قەرزی زیادکراو"
  },
  "reports.newAdditionOperations": {
    ar: "عملية إضافة جديدة",
    en: "New addition transaction",
    ku: "مامەڵەی زیادکردنی نوێ"
  },
  "reports.paidAmounts": {
    ar: "المبالغ المسددة",
    en: "Paid Amounts",
    ku: "بڕە پارەی دراو"
  },
  "reports.collectionPayments": {
    ar: "دفعة تحصيل",
    en: "Collection payment",
    ku: "پارەی کۆکراوە"
  },
  "reports.periodNetMovement": {
    ar: "صافي حركة الفترة",
    en: "Period Net Movement",
    ku: "جووڵەی پوختەی ماوەکە"
  },
  "reports.positiveSurplus": {
    ar: "فائض تحصيل نقدي إيجابي",
    en: "Positive net collection surplus",
    ku: "زیادەی پارەی کۆکراوەی ئەرێنی"
  },
  "reports.debtIncrease": {
    ar: "زيادة في حجم الديون",
    en: "Increase in total debt volume",
    ku: "زیادبوون لە قەبارەی قەرزەکان"
  },
  "reports.balancedMovement": {
    ar: "حركة مالية متوازنة",
    en: "Balanced financial movement",
    ku: "جووڵەی دارایی هاوسەنگ"
  },
  "reports.interactionDebtorsCount": {
    ar: "تفاعل",
    en: "interactions",
    ku: "مامەڵەکردن"
  },
  "reports.debtorSingular": {
    ar: "مدين",
    en: "debtor",
    ku: "قەرزدار"
  },
  "reports.transactionsLogByDebtors": {
    ar: "سجل العمليات حسب المدينين",
    en: "Transactions Log by Debtors",
    ku: "تۆماری مامەڵەکان بەپێی قەرزداران"
  },
  "reports.clickDebtorToExpand": {
    ar: "اضغط على اسم أي مدين لفتح القائمة المنسدلة وعرض تفاصيل كافة عملياته",
    en: "Click any debtor name to expand and view detailed transaction history",
    ku: "کرتە لەسەر ناوی هەر قەرزدارێک بکە بۆ کردنەوە و بینینی تەواوی مامەڵەکانی"
  },
  "reports.expandAllTitle": {
    ar: "فتح كافة القوائم المنسدلة",
    en: "Expand All Lists",
    ku: "کردنەوەی هەموو لیستەکان"
  },
  "reports.expandAll": {
    ar: "توسيع الكل",
    en: "Expand All",
    ku: "کردنەوەی هەموو"
  },
  "reports.collapseAllTitle": {
    ar: "طي كافة القوائم المنسدلة",
    en: "Collapse All Lists",
    ku: "داخستنی هەموو لیستەکان"
  },
  "reports.collapseAll": {
    ar: "طي الكل",
    en: "Collapse All",
    ku: "داخستنی هەموو"
  },
  "reports.allFilter": {
    ar: "الكل",
    en: "All",
    ku: "هەموو"
  },
  "reports.settlements": {
    ar: "تسديدات",
    en: "Settlements",
    ku: "دانەوەکان"
  },
  "reports.debts": {
    ar: "ديون",
    en: "Debts",
    ku: "قەرزەکان"
  },
  "reports.searchPlaceholder": {
    ar: "البحث باسم المدين أو الملاحظة أو المبلغ...",
    en: "Search by debtor name, note, or amount...",
    ku: "گەڕان بەپێی ناوی قەرزدار، تێبینی یان بڕ..."
  },
  "reports.noMatchingTransactions": {
    ar: "لا توجد حركات مطابقة في هذه الفترة",
    en: "No matching transactions in this period",
    ku: "هیچ مامەڵەیەکی هاوتا لەم ماوەیەدا نییە"
  },
  "reports.tryAnotherSearch": {
    ar: "جرب البحث بكلمة أخرى أو اختيار فترة زمنية مختلفة",
    en: "Try searching with another keyword or select a different date range",
    ku: "هەوڵبدە بە وشەیەکی تر بگەڕێیت یان ماوەیەکی کاتیی تر هەڵبژێرە"
  },
  "reports.noOpsRecordedInPeriod": {
    ar: "لم تسجل أي عمليات دين أو تسديد في النطاق الزمني المحدد",
    en: "No debt or payment transactions recorded in the selected period",
    ku: "هیچ مامەڵەیەکی قەرز یان دانەوە لەم ماوەیەدا تۆمار نەکراوە"
  },
  "reports.registeredOperations": {
    ar: "حركات مسجلة",
    en: "Registered transactions",
    ku: "مامەڵەی تۆمارکراو"
  },
  "reports.noPeriodOperations": {
    ar: "لا حركات بالفترة",
    en: "No transactions in period",
    ku: "هیچ مامەڵەیەک لە ماوەکەدا نییە"
  },
  "reports.totalAdditions": {
    ar: "إجمالي الإضافات",
    en: "Total Additions",
    ku: "کۆی گشتی زیادکراوەکان"
  },
  "reports.totalSettlements": {
    ar: "إجمالي المسددات",
    en: "Total Settlements",
    ku: "کۆی گشتی دانەوەکان"
  },
  "reports.debtorNetMovement": {
    ar: "صافي حركة المدين",
    en: "Debtor Net Movement",
    ku: "جووڵەی پوختەی قەرزدار"
  },
  "reports.noOpsRecordedForDebtorInPeriod": {
    ar: "لا توجد عمليات مسجلة لهذا المدين خلال فترة",
    en: "No transactions recorded for this debtor during the period",
    ku: "هیچ مامەڵەیەک بۆ ئەم قەرزدارە لەم ماوەیەدا تۆمار نەکراوە"
  },
  "reports.opsAndPaymentsList": {
    ar: "قائمة العمليات والتسديدات",
    en: "Operations & Settlements List",
    ku: "لیستی مامەڵەکان و دانەوەکان"
  },
  "reports.sortedNewestFirst": {
    ar: "مرتبة من الأحدث إلى الأقدم",
    en: "Sorted newest to oldest",
    ku: "ڕیزکراو لە نوێترینەوە بۆ کۆنترین"
  },
  "reports.paySettlement": {
    ar: "تسديد دفعة",
    en: "Make Payment",
    ku: "دانەوەی قیست/بڕ"
  },
  "reports.addDebt": {
    ar: "إضافة دين",
    en: "Add Debt",
    ku: "زیادکردنی قەرز"
  },
  "reports.balanceAfter": {
    ar: "الرصيد بعد",
    en: "Balance After",
    ku: "باڵانس دوای"
  },
  "reports.totalDisplayedDebtors": {
    ar: "إجمالي المدينين المعروضين",
    en: "Total Displayed Debtors",
    ku: "کۆی گشتی قەرزدارە پیشاندراوەکان"
  },
  "reports.resetCumulativeStats": {
    ar: "تصفير سجل التقارير والإحصائيات التراكمية",
    en: "Reset Cumulative Reports & Statistics",
    ku: "سفرکردنەوەی ڕاپۆرتەکان و ئامارە کەڵەکەبووەکان"
  }
};

// Apply all translations
let countAdded = 0;
for (const key in translations) {
  setNested(ar, key, translations[key].ar);
  setNested(en, key, translations[key].en);
  setNested(ku, key, translations[key].ku);
  countAdded++;
}

console.log('Populated ' + countAdded + ' keys into ar, en, ku');

// Check if any missing keys are not in translations
for (const key in missing) {
  if (!translations[key]) {
    console.log('Still unmapped key:', key, missing[key]);
  }
}

fs.writeFileSync('src/locales/ar.json', JSON.stringify(ar, null, 2), 'utf8');
fs.writeFileSync('src/locales/en.json', JSON.stringify(en, null, 2), 'utf8');
fs.writeFileSync('src/locales/ku.json', JSON.stringify(ku, null, 2), 'utf8');
console.log('Saved updated locale files');
