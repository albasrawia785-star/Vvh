package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String
)

@Entity(tableName = "menu_items")
data class MenuItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val price: Long, // Price in IQD (English numbers represented as Long)
    val categoryId: Int // Links to Category.id
)

@Entity(tableName = "shift_sessions")
data class ShiftSession(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val openTime: String,       // e.g. "18/07/2026 10:05"
    val closeTime: String?,     // null if active
    val openingFloat: Long,     // رأس المال الافتتاحي في القاصة
    val totalSales: Long,       // إجمالي المبيعات
    val netProfit: Long,        // صافي الأرباح
    val isOpen: Boolean = true
)
