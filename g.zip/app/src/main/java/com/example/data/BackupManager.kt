package com.example.data

import android.content.Context
import android.os.Environment
import com.example.print.CartItem
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File

class BackupManager(private val context: Context, private val repository: PosRepository) {

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    // Data structures for JSON serialization
    data class BackupPayload(
        val categories: List<Category>,
        val menuItems: List<MenuItem>
    )

    private val payloadAdapter = moshi.adapter(BackupPayload::class.java)

    /**
     * Exports the database to a file in the app's external files directory.
     * Returns the absolute path of the backup file on success, or null on failure.
     */
    suspend fun exportBackup(): String? = withContext(Dispatchers.IO) {
        try {
            val categories = repository.allCategories.first()
            val menuItems = repository.allMenuItems.first()
            val payload = BackupPayload(categories, menuItems)
            
            val jsonString = payloadAdapter.toJson(payload)
            
            val backupDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
            if (backupDir != null && !backupDir.exists()) {
                backupDir.mkdirs()
            }
            
            val backupFile = File(backupDir, "saas_pos_backup.json")
            backupFile.writeText(jsonString)
            return@withContext backupFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext null
        }
    }

    /**
     * Imports the database from the backup file in the app's external files directory.
     * Returns true on success, false on failure.
     */
    suspend fun importBackup(): Boolean = withContext(Dispatchers.IO) {
        try {
            val backupDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
            val backupFile = File(backupDir, "saas_pos_backup.json")
            if (!backupFile.exists()) return@withContext false
            
            val jsonString = backupFile.readText()
            val payload = payloadAdapter.fromJson(jsonString) ?: return@withContext false
            
            // Re-populate tables safely
            // To preserve foreign keys correctly and avoid integrity violations,
            // we first clear the tables, then insert categories one-by-one mapping their new IDs
            // to old IDs, and then insert menu items with their updated categoryIds.
            
            val oldToNewCategoryMap = mutableMapOf<Int, Int>()
            
            // Delete all current items
            for (item in repository.allMenuItems.first()) {
                repository.deleteMenuItem(item.id)
            }
            for (cat in repository.allCategories.first()) {
                repository.deleteCategory(cat.id)
            }
            
            // Insert restored categories
            for (cat in payload.categories) {
                val newId = repository.insertCategory(Category(name = cat.name))
                oldToNewCategoryMap[cat.id] = newId.toInt()
            }
            
            // Insert restored menu items
            for (item in payload.menuItems) {
                val mappedCatId = oldToNewCategoryMap[item.categoryId] ?: continue
                repository.insertMenuItem(
                    MenuItem(
                        name = item.name,
                        price = item.price,
                        categoryId = mappedCatId
                    )
                )
            }
            
            return@withContext true
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext false
        }
    }

    /**
     * Checks if a backup file exists in the documents folder.
     */
    fun hasBackupFile(): Boolean {
        val backupDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
        val backupFile = File(backupDir, "saas_pos_backup.json")
        return backupFile.exists()
    }
}
