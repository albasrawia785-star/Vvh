package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PosDao {
    // Categories
    @Query("SELECT * FROM categories ORDER BY id ASC")
    fun getAllCategories(): Flow<List<Category>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: Category): Long

    @Update
    suspend fun updateCategory(category: Category)

    @Query("DELETE FROM categories WHERE id = :id")
    suspend fun deleteCategoryById(id: Int)

    // Menu Items
    @Query("SELECT * FROM menu_items ORDER BY id ASC")
    fun getAllMenuItems(): Flow<List<MenuItem>>

    @Query("SELECT * FROM menu_items WHERE categoryId = :categoryId ORDER BY id ASC")
    fun getMenuItemsByCategory(categoryId: Int): Flow<List<MenuItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMenuItem(menuItem: MenuItem): Long

    @Update
    suspend fun updateMenuItem(menuItem: MenuItem)

    @Query("DELETE FROM menu_items WHERE id = :id")
    suspend fun deleteMenuItemById(id: Int)
    
    @Query("DELETE FROM menu_items WHERE categoryId = :categoryId")
    suspend fun deleteMenuItemsByCategory(categoryId: Int)

    // Shift Sessions
    @Query("SELECT * FROM shift_sessions WHERE isOpen = 1 LIMIT 1")
    fun getActiveShiftFlow(): Flow<ShiftSession?>

    @Query("SELECT * FROM shift_sessions WHERE isOpen = 1 LIMIT 1")
    suspend fun getActiveShift(): ShiftSession?

    @Query("SELECT * FROM shift_sessions ORDER BY id DESC")
    fun getShiftHistory(): Flow<List<ShiftSession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShift(session: ShiftSession): Long

    @Update
    suspend fun updateShift(session: ShiftSession)

    @Query("DELETE FROM shift_sessions WHERE id = :id")
    suspend fun deleteShiftById(id: Int)

    @Query("DELETE FROM shift_sessions")
    suspend fun clearAllShifts()

    @Query("DELETE FROM categories")
    suspend fun clearAllCategories()

    @Query("DELETE FROM menu_items")
    suspend fun clearAllMenuItems()
}
