package com.example.data

import kotlinx.coroutines.flow.Flow

class PosRepository(private val posDao: PosDao) {
    val allCategories: Flow<List<Category>> = posDao.getAllCategories()
    val allMenuItems: Flow<List<MenuItem>> = posDao.getAllMenuItems()

    // Shift Sessions
    val activeShiftFlow: Flow<ShiftSession?> = posDao.getActiveShiftFlow()
    val shiftHistory: Flow<List<ShiftSession>> = posDao.getShiftHistory()

    suspend fun getActiveShift(): ShiftSession? = posDao.getActiveShift()
    suspend fun insertShift(session: ShiftSession): Long = posDao.insertShift(session)
    suspend fun updateShift(session: ShiftSession) = posDao.updateShift(session)
    suspend fun deleteShift(id: Int) = posDao.deleteShiftById(id)
    suspend fun clearAllShifts() = posDao.clearAllShifts()
    suspend fun clearAllData() {
        posDao.clearAllMenuItems()
        posDao.clearAllCategories()
        posDao.clearAllShifts()
    }

    fun getMenuItemsByCategory(categoryId: Int): Flow<List<MenuItem>> = 
        posDao.getMenuItemsByCategory(categoryId)

    suspend fun insertCategory(category: Category): Long = 
        posDao.insertCategory(category)

    suspend fun updateCategory(category: Category) = 
        posDao.updateCategory(category)

    suspend fun deleteCategory(id: Int) {
        posDao.deleteCategoryById(id)
        // Cascade delete menu items belonging to this category
        posDao.deleteMenuItemsByCategory(id)
    }

    suspend fun insertMenuItem(menuItem: MenuItem): Long = 
        posDao.insertMenuItem(menuItem)

    suspend fun updateMenuItem(menuItem: MenuItem) = 
        posDao.updateMenuItem(menuItem)

    suspend fun deleteMenuItem(id: Int) = 
        posDao.deleteMenuItemById(id)
}
