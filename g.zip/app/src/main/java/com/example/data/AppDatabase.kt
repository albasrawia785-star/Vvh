package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [Category::class, MenuItem::class, ShiftSession::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun posDao(): PosDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "saas_pos_database"
                )
                .fallbackToDestructiveMigration()
                .addCallback(DatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        seedDatabase(database.posDao())
                    }
                }
            }

            private suspend fun seedDatabase(dao: PosDao) {
                // Seed Categories
                val grillId = dao.insertCategory(Category(name = "مشويات فخمة"))
                val fastFoodId = dao.insertCategory(Category(name = "وجبات سريعة"))
                val appetizerId = dao.insertCategory(Category(name = "مقبلات وسلطات"))
                val drinksId = dao.insertCategory(Category(name = "عصائر ومشروبات"))

                // Seed Menu Items for Grills
                dao.insertMenuItem(MenuItem(name = "كباب لحم عراقي فخم", price = 12000, categoryId = grillId.toInt()))
                dao.insertMenuItem(MenuItem(name = "تكة لحم غنم بالخبز الحار", price = 14000, categoryId = grillId.toInt()))
                dao.insertMenuItem(MenuItem(name = "كباب دجاج بالزعفران", price = 10000, categoryId = grillId.toInt()))
                dao.insertMenuItem(MenuItem(name = "شيش طاووق على الفحم", price = 9500, categoryId = grillId.toInt()))
                dao.insertMenuItem(MenuItem(name = "نصف دجاجة مسحب مشوية", price = 8000, categoryId = grillId.toInt()))

                // Seed Menu Items for Fast Food
                dao.insertMenuItem(MenuItem(name = "شاورما دجاج بخبز الصاج", price = 5000, categoryId = fastFoodId.toInt()))
                dao.insertMenuItem(MenuItem(name = "شاورما لحم عراقية أصلية", price = 6500, categoryId = fastFoodId.toInt()))
                dao.insertMenuItem(MenuItem(name = "برغر لحم دبل بالجبنة", price = 7000, categoryId = fastFoodId.toInt()))
                dao.insertMenuItem(MenuItem(name = "بيتزا إيطالية سوبر سوبريم", price = 11000, categoryId = fastFoodId.toInt()))
                dao.insertMenuItem(MenuItem(name = "زنغر دجاج مقرمش حار", price = 6000, categoryId = fastFoodId.toInt()))

                // Seed Menu Items for Appetizers
                dao.insertMenuItem(MenuItem(name = "حمص بطحينة بزيت الزيتون", price = 3000, categoryId = appetizerId.toInt()))
                dao.insertMenuItem(MenuItem(name = "متبل باذنجان مشوي", price = 3500, categoryId = appetizerId.toInt()))
                dao.insertMenuItem(MenuItem(name = "تبولة لبنانية فريش", price = 3000, categoryId = appetizerId.toInt()))
                dao.insertMenuItem(MenuItem(name = "سلطة كولسلو كريمية", price = 2500, categoryId = appetizerId.toInt()))
                dao.insertMenuItem(MenuItem(name = "بطاطا مقلية مقرمشة (فرايز)", price = 2500, categoryId = appetizerId.toInt()))

                // Seed Menu Items for Drinks
                dao.insertMenuItem(MenuItem(name = "عصير برتقال طبيعي بارد", price = 4000, categoryId = drinksId.toInt()))
                dao.insertMenuItem(MenuItem(name = "عصير ليمون ونعناع منعش", price = 3500, categoryId = drinksId.toInt()))
                dao.insertMenuItem(MenuItem(name = "ميلك شيك شوكولاتة فاخر", price = 5000, categoryId = drinksId.toInt()))
                dao.insertMenuItem(MenuItem(name = "مشروب غازي ببسي بارد", price = 1000, categoryId = drinksId.toInt()))
                dao.insertMenuItem(MenuItem(name = "شاي عراقي مهيل بالاستكان", price = 1000, categoryId = drinksId.toInt()))
            }
        }
    }
}
