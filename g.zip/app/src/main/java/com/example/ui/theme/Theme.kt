package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = NavyPrimary,
    onPrimary = Color.White,
    primaryContainer = NavySecondary,
    onPrimaryContainer = Color.White,
    secondary = AmberAccent,
    onSecondary = Color.White,
    background = LightBackground,
    onBackground = DarkText,
    surface = PureWhite,
    onSurface = DarkText,
    surfaceVariant = SoftGrayBorder,
    onSurfaceVariant = SoftText,
    error = CrimsonError,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF94A3B8), // Muted slate-blue
    onPrimary = Color(0xFF0F172A),
    primaryContainer = NavyPrimary,
    onPrimaryContainer = Color.White,
    secondary = Color(0xFFF59E0B),
    onSecondary = Color(0xFF0F172A),
    background = Color(0xFF0F172A), // Slate 900
    onBackground = Color(0xFFF1F5F9),
    surface = Color(0xFF1E293B),    // Slate 800
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF334155),
    onSurfaceVariant = Color(0xFF94A3B8),
    error = Color(0xFFEF4444),
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // We enforce our branded POS theme so that it remains professional and cohesive.
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
