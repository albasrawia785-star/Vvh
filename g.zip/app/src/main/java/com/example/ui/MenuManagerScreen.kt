package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Category
import com.example.data.MenuItem
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuManagerScreen(
    viewModel: PosViewModel
) {
    val categories by viewModel.categories.collectAsState()
    val menuItems by viewModel.menuItems.collectAsState()

    var activeSubTab by remember { mutableStateOf(0) } // 0 = Meals, 1 = Categories

    // Add Meal Dialog State
    var showAddMealDialog by remember { mutableStateOf(false) }
    var mealNameInput by remember { mutableStateOf("") }
    var mealPriceInput by remember { mutableStateOf("") }
    var selectedCatForMeal by remember { mutableStateOf<Category?>(null) }

    // Edit Meal Dialog State
    var showEditMealDialog by remember { mutableStateOf(false) }
    var editingMenuItem by remember { mutableStateOf<MenuItem?>(null) }

    // Add/Edit Category State
    var showAddCatDialog by remember { mutableStateOf(false) }
    var catNameInput by remember { mutableStateOf("") }
    
    var showEditCatDialog by remember { mutableStateOf(false) }
    var editingCategory by remember { mutableStateOf<Category?>(null) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(LightBackground)
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "إدارة المنيو وقائمة الطعام",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF000000) // Pure Black for primary texts
                    )
                }

                // Add button based on active sub tab
                Button(
                    onClick = {
                        if (activeSubTab == 0) {
                            mealNameInput = ""
                            mealPriceInput = ""
                            selectedCatForMeal = categories.firstOrNull()
                            showAddMealDialog = true
                        } else {
                            catNameInput = ""
                            showAddCatDialog = true
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                    modifier = Modifier.testTag("admin_add_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (activeSubTab == 0) "إضافة وجبة جديدة" else "إضافة قسم جديد",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sub Tab Selectors
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(10.dp))
                    .border(1.dp, SoftGrayBorder, RoundedCornerShape(10.dp))
                    .padding(4.dp)
            ) {
                // Tab: Meals
                Box(
                    modifier = Modifier
                        .weight(1.0f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (activeSubTab == 0) NavyPrimary else Color.Transparent)
                        .clickable { activeSubTab = 0 }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "قائمة المواد والوجبات (${menuItems.size})",
                        color = if (activeSubTab == 0) Color.White else SoftText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                // Tab: Categories
                Box(
                    modifier = Modifier
                        .weight(1.0f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (activeSubTab == 1) NavyPrimary else Color.Transparent)
                        .clickable { activeSubTab = 1 }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "أقسام المنيو والترتيب (${categories.size})",
                        color = if (activeSubTab == 1) Color.White else SoftText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Database Lists
            if (activeSubTab == 0) {
                // Meals List
                if (menuItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1.0f)
                            .background(Color.White, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("قائمة الطعام فارغة حالياً. اضغط على زر إضافة وجبة جديدة في الأعلى!", color = SoftText, fontSize = 14.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .weight(1.0f)
                            .fillMaxWidth()
                            .testTag("admin_meals_list"),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(menuItems) { meal ->
                            val catName = categories.find { it.id == meal.categoryId }?.name ?: "غير محدد"
                            MealAdminRow(
                                meal = meal,
                                categoryName = catName,
                                onEdit = {
                                    editingMenuItem = meal
                                    mealNameInput = meal.name
                                    mealPriceInput = meal.price.toString()
                                    selectedCatForMeal = categories.find { it.id == meal.categoryId }
                                    showEditMealDialog = true
                                },
                                onDelete = { viewModel.deleteMenuItem(meal.id) }
                            )
                        }
                    }
                }
            } else {
                // Categories List
                if (categories.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1.0f)
                            .background(Color.White, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("لا توجد أقسام منيو مضافة حالياً.", color = SoftText, fontSize = 14.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .weight(1.0f)
                            .fillMaxWidth()
                            .testTag("admin_categories_list"),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(categories) { cat ->
                            CategoryAdminRow(
                                category = cat,
                                onEdit = {
                                    editingCategory = cat
                                    catNameInput = cat.name
                                    showEditCatDialog = true
                                },
                                onDelete = { viewModel.deleteCategory(cat.id) }
                            )
                        }
                    }
                }
            }
        }

        // --- Dialogs Section ---

        // 1. Add Category Dialog
        if (showAddCatDialog) {
            AlertDialog(
                onDismissRequest = { showAddCatDialog = false },
                title = { Text("إضافة قسم منيو جديد") },
                text = {
                    OutlinedTextField(
                        value = catNameInput,
                        onValueChange = { catNameInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("اسم القسم") },
                        placeholder = { Text("مثال: وجبات شرقية") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (catNameInput.isNotEmpty()) {
                                viewModel.addCategory(catNameInput)
                                showAddCatDialog = false
                            }
                        }
                    ) {
                        Text("إضافة وحفظ")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddCatDialog = false }) {
                        Text("إلغاء")
                    }
                }
            )
        }

        // 2. Edit Category Dialog
        if (showEditCatDialog && editingCategory != null) {
            AlertDialog(
                onDismissRequest = { showEditCatDialog = false },
                title = { Text("تعديل اسم القسم") },
                text = {
                    OutlinedTextField(
                        value = catNameInput,
                        onValueChange = { catNameInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("اسم القسم") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (catNameInput.isNotEmpty()) {
                                viewModel.editCategory(editingCategory!!.copy(name = catNameInput))
                                showEditCatDialog = false
                            }
                        }
                    ) {
                        Text("حفظ التعديل")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEditCatDialog = false }) {
                        Text("إلغاء")
                    }
                }
            )
        }

        // 3. Add Meal Dialog
        if (showAddMealDialog) {
            AlertDialog(
                onDismissRequest = { showAddMealDialog = false },
                title = { Text("إضافة مادة/وجبة جديدة") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        // Category Dropdown Simulator
                        Text("القسم التابع له:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        if (categories.isEmpty()) {
                            Text("الرجاء إضافة أقسام أولاً قبل الوجبات!", color = CrimsonError, fontSize = 12.sp)
                        } else {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(categories) { cat ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (selectedCatForMeal?.id == cat.id) NavyPrimary else Color.White)
                                            .border(1.dp, if (selectedCatForMeal?.id == cat.id) NavyPrimary else SoftGrayBorder, RoundedCornerShape(8.dp))
                                            .clickable { selectedCatForMeal = cat }
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = cat.name,
                                            color = if (selectedCatForMeal?.id == cat.id) Color.White else SoftText,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Name
                        OutlinedTextField(
                            value = mealNameInput,
                            onValueChange = { mealNameInput = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("اسم الوجبة / المادة") },
                            placeholder = { Text("مثال: قوزي عراقي بالرز") },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )

                        // Price
                        OutlinedTextField(
                            value = mealPriceInput,
                            onValueChange = { mealPriceInput = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("السعر بالدينار العراقي (د.ع)") },
                            placeholder = { Text("مثال: 12000") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val priceValue = mealPriceInput.toLongOrNull()
                            val selectedCatId = selectedCatForMeal?.id
                            if (mealNameInput.isNotEmpty() && priceValue != null && selectedCatId != null) {
                                viewModel.addMenuItem(mealNameInput, priceValue, selectedCatId)
                                showAddMealDialog = false
                            }
                        },
                        enabled = categories.isNotEmpty()
                    ) {
                        Text("إضافة وحفظ")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddMealDialog = false }) {
                        Text("إلغاء")
                    }
                }
            )
        }

        // 4. Edit Meal Dialog
        if (showEditMealDialog && editingMenuItem != null) {
            AlertDialog(
                onDismissRequest = { showEditMealDialog = false },
                title = { Text("تعديل تفاصيل الوجبة") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("القسم التابع له:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(categories) { cat ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (selectedCatForMeal?.id == cat.id) NavyPrimary else Color.White)
                                        .border(1.dp, if (selectedCatForMeal?.id == cat.id) NavyPrimary else SoftGrayBorder, RoundedCornerShape(8.dp))
                                        .clickable { selectedCatForMeal = cat }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = cat.name,
                                        color = if (selectedCatForMeal?.id == cat.id) Color.White else SoftText,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Name
                        OutlinedTextField(
                            value = mealNameInput,
                            onValueChange = { mealNameInput = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("اسم الوجبة / المادة") },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )

                        // Price
                        OutlinedTextField(
                            value = mealPriceInput,
                            onValueChange = { mealPriceInput = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("السعر بالدينار العراقي (د.ع)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val priceValue = mealPriceInput.toLongOrNull()
                            val selectedCatId = selectedCatForMeal?.id
                            if (mealNameInput.isNotEmpty() && priceValue != null && selectedCatId != null) {
                                viewModel.editMenuItem(
                                    editingMenuItem!!.copy(
                                        name = mealNameInput,
                                        price = priceValue,
                                        categoryId = selectedCatId
                                    )
                                )
                                showEditMealDialog = false
                            }
                        }
                    ) {
                        Text("حفظ التعديلات")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEditMealDialog = false }) {
                        Text("إلغاء")
                    }
                }
            )
        }
    }
}

@Composable
fun MealAdminRow(
    meal: MenuItem,
    categoryName: String,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SoftGrayBorder, RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(0.6f)) {
                Text(
                    text = meal.name,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = Color(0xFF000000) // Pure Black
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(NavyPrimary.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = categoryName,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = formatCurrency(meal.price),
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF000000), // Pure Black as requested
                        fontSize = 16.sp
                    )
                }
            }

            // Edit / Delete Buttons
            Row(
                modifier = Modifier.weight(0.4f),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier
                        .size(36.dp)
                        .background(LightBackground, RoundedCornerShape(8.dp))
                ) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit meal details", modifier = Modifier.size(16.dp), tint = NavyPrimary)
                }
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(36.dp)
                        .background(CrimsonError.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete meal", modifier = Modifier.size(16.dp), tint = CrimsonError)
                }
            }
        }
    }
}

@Composable
fun CategoryAdminRow(
    category: Category,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SoftGrayBorder, RoundedCornerShape(10.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(0.6f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(LightBackground, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Folder, contentDescription = "Folder Icon", tint = NavyPrimary, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = category.name,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = Color(0xFF000000) // Pure Black
                )
            }

            Row(
                modifier = Modifier.weight(0.4f),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier
                        .size(36.dp)
                        .background(LightBackground, RoundedCornerShape(8.dp))
                ) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit Category", modifier = Modifier.size(16.dp), tint = NavyPrimary)
                }
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(36.dp)
                        .background(CrimsonError.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete Category", modifier = Modifier.size(16.dp), tint = CrimsonError)
                }
            }
        }
    }
}
