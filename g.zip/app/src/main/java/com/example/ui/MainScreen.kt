package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LightBackground
import com.example.ui.theme.NavyPrimary
import kotlinx.coroutines.delay

@Composable
fun MainScreen(
    viewModel: PosViewModel,
    onLogout: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = Cashier, 1 = Menu Manager, 2 = Settings
    
    // Periodically monitor trial session expiration (forces immediate logout if expired)
    LaunchedEffect(Unit) {
        while (true) {
            delay(15000) // check every 15 seconds
            val user = viewModel.sessionManager.getUsername()
            if (user == "1" && viewModel.sessionManager.isTrialExpired()) {
                viewModel.logout()
                onLogout()
                break
            }
        }
    }

    // Adaptive sizing
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            bottomBar = {
                // Bottom bar only for vertical/compact layouts
                if (!isLandscape) {
                    NavigationBar(
                        containerColor = Color.White,
                        tonalElevation = 8.dp,
                        modifier = Modifier.testTag("bottom_nav_bar")
                    ) {
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = { Icon(Icons.Default.PointOfSale, contentDescription = "Cashier") },
                            label = { Text("الكاشير") },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = NavyPrimary,
                                indicatorColor = NavyPrimary
                            )
                        )

                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = "Menu Administration") },
                            label = { Text("إدارة المنيو") },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = NavyPrimary,
                                indicatorColor = NavyPrimary
                            )
                        )

                        NavigationBarItem(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            icon = { Icon(Icons.Default.Settings, contentDescription = "Settings and printer") },
                            label = { Text("الإعدادات") },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = NavyPrimary,
                                indicatorColor = NavyPrimary
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(LightBackground)
            ) {
                // Navigation Rail for landscape/widescreen layouts
                if (isLandscape) {
                    NavigationRail(
                        containerColor = Color.White,
                        header = {
                            Spacer(modifier = Modifier.height(14.dp))
                            Icon(
                                imageVector = Icons.Default.PointOfSale,
                                contentDescription = "App Logo",
                                tint = NavyPrimary,
                                modifier = Modifier.size(32.dp)
                            )
                        },
                        modifier = Modifier.testTag("side_navigation_rail")
                    ) {
                        Spacer(modifier = Modifier.weight(1f))
                        
                        NavigationRailItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = { Icon(Icons.Default.PointOfSale, contentDescription = "Cashier") },
                            label = { Text("الكاشير") },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = NavyPrimary,
                                indicatorColor = NavyPrimary
                            )
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        NavigationRailItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = "Menu Administration") },
                            label = { Text("إدارة المنيو") },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = NavyPrimary,
                                indicatorColor = NavyPrimary
                            )
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        NavigationRailItem(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                            label = { Text("الإعدادات") },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = NavyPrimary,
                                indicatorColor = NavyPrimary
                            )
                        )
                        
                        Spacer(modifier = Modifier.weight(1f))
                    }

                    VerticalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 1.dp)
                }

                // Active Tab Content
                Box(modifier = Modifier.weight(1.0f).fillMaxHeight()) {
                    when (selectedTab) {
                        0 -> CashierScreen(viewModel = viewModel)
                        1 -> MenuManagerScreen(viewModel = viewModel)
                        2 -> SettingsScreen(viewModel = viewModel, onLogout = onLogout)
                    }
                }
            }
        }
    }
}
