package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Navy Blue (Slate 800) Primary
val NavyPrimary = Color(0xFF1E293B)
val NavySecondary = Color(0xFF334155)
val NavyAccent = Color(0xFF0F172A)

// Background & Surfaces
val LightBackground = Color(0xFFF1F5F9) // Light gray slate background
val PureWhite = Color(0xFFFFFFFF)       // Pure white for containers/cards
val SoftText = Color(0xFF475569)        // Muted text gray
val DarkText = Color(0xFF0F172A)        // Strong header gray

// Supporting Accent (Amber/Orange)
val AmberAccent = Color(0xFFD97706)
val EmeraldSuccess = Color(0xFF059669)
val CrimsonError = Color(0xFFDC2626)
val SoftGrayBorder = Color(0xFFE2E8F0)
