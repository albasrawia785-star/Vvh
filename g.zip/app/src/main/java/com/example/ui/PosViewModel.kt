package com.example.ui

import android.app.Application
import android.bluetooth.BluetoothDevice
import android.graphics.Bitmap
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.auth.SessionManager
import com.example.data.*
import com.example.print.CartItem
import com.example.print.PrintManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PosViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext

    // Dependencies
    private val database: AppDatabase by lazy {
        AppDatabase.getDatabase(context, viewModelScope)
    }
    private val repository: PosRepository by lazy {
        PosRepository(database.posDao())
    }
    val sessionManager = SessionManager(context)
    val printManager = PrintManager(context)
    private val backupManager: BackupManager by lazy {
        BackupManager(context, repository)
    }

    // Dynamic configuration loaded from coco.json
    private val _storeName = MutableStateFlow("اسم المطعم الحالي")
    val storeName: StateFlow<String> = _storeName

    private val _storePhone = MutableStateFlow("07810936407")
    val storePhone: StateFlow<String> = _storePhone

    private val _ownerName = MutableStateFlow("اسم صاحب المطعم")
    val ownerName: StateFlow<String> = _ownerName

    // Auth screen states
    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError

    private val _trialLocked = MutableStateFlow(false)
    val trialLocked: StateFlow<Boolean> = _trialLocked

    // Selected POS Tab category
    private val _selectedCategoryId = MutableStateFlow<Int?>(null)
    val selectedCategoryId: StateFlow<Int?> = _selectedCategoryId

    // Database flow entities
    val categories: StateFlow<List<Category>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val menuItems: StateFlow<List<MenuItem>> = repository.allMenuItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Cart items state
    private val _cart = MutableStateFlow<Map<Int, CartItem>>(emptyMap())
    val cart: StateFlow<Map<Int, CartItem>> = _cart

    // Business Type and Order Configuration
    private val _businessType = MutableStateFlow("RESTAURANT") // "RESTAURANT" or "CAFE"
    val businessType: StateFlow<String> = _businessType

    private val _selectedOrderType = MutableStateFlow("DINE_IN") // "DINE_IN", "TAKEAWAY", "DELIVERY"
    val selectedOrderType: StateFlow<String> = _selectedOrderType

    private val _deliveryFee = MutableStateFlow(3000L)
    val deliveryFee: StateFlow<Long> = _deliveryFee

    val cartTotal: StateFlow<Long> = combine(_cart, _businessType, _selectedOrderType, _deliveryFee) { cartMap, bizType, orderType, fee ->
        val itemsTotal = cartMap.values.sumOf { it.price * it.quantity }
        if (bizType == "RESTAURANT" && orderType == "DELIVERY") {
            itemsTotal + fee
        } else {
            itemsTotal
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    // Printing options and preview state
    val receiptPreview: StateFlow<Bitmap?> = printManager.receiptPreview
    private val _isPrinting = MutableStateFlow(false)
    val isPrinting: StateFlow<Boolean> = _isPrinting

    private val _paperWidthMm = MutableStateFlow(58) // 58mm or 80mm
    val paperWidthMm: StateFlow<Int> = _paperWidthMm

    // Backup & Restore Statuses
    private val _backupStatus = MutableStateFlow<String?>(null)
    val backupStatus: StateFlow<String?> = _backupStatus

    private val _hasBackupFile = MutableStateFlow(false)
    val hasBackupFile: StateFlow<Boolean> = _hasBackupFile

    // Shift & Profits Session State Flows
    val activeShift: StateFlow<ShiftSession?> = repository.activeShiftFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val shiftHistory: StateFlow<List<ShiftSession>> = repository.shiftHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        _businessType.value = sessionManager.getBusinessType()
        loadConfigFromCocoJson()
        checkSession()
        checkBackupFile()
        
        // Auto select first category once loaded
        viewModelScope.launch {
            categories.collect { list ->
                if (list.isNotEmpty() && _selectedCategoryId.value == null) {
                    _selectedCategoryId.value = list.first().id
                }
            }
        }
    }

    private fun loadConfigFromCocoJson() {
        try {
            val jsonString = context.assets.open("coco.json").bufferedReader().use { it.readText() }
            val json = JSONObject(jsonString)
            _storeName.value = json.optString("STORE_NAME", "اسم المطعم الحالي")
            _storePhone.value = json.optString("STORE_PHONE", "07810936407")
            _ownerName.value = json.optString("OWNER_NAME", "اسم صاحب المطعم")
        } catch (e: Exception) {
            e.printStackTrace()
            _storeName.value = "كاشير الفخامة والذوق"
            _storePhone.value = "07810936407"
            _ownerName.value = "المطور علي"
        }
    }

    private fun checkSession() {
        _trialLocked.value = sessionManager.isTrialLocked()
        _isLoggedIn.value = sessionManager.isLoggedIn()
    }

    fun login(user: String, pass: String): Boolean {
        _authError.value = null
        
        // 1. Check if trial is locked completely
        if (user == "1" && sessionManager.isTrialLocked()) {
            _authError.value = "انتهت المدة التجريبية (24 ساعة)، يرجى التواصل مع المطور لشراء النسخة الأصلية وتفعيل الحساب"
            return false
        }

        // 2. Original User Authentication
        if (user == "ali" && pass == "19971997") {
            sessionManager.login("ali")
            _isLoggedIn.value = true
            Toast.makeText(context, "أهلاً بك يا ${ownerName.value}", Toast.LENGTH_LONG).show()
            return true
        }

        // 3. Trial User Authentication
        if (user == "1" && pass == "1") {
            sessionManager.login("1")
            
            // Re-evaluate expiry immediately just in case
            if (sessionManager.isTrialExpired()) {
                _authError.value = "انتهت المدة التجريبية (24 ساعة)، يرجى التواصل مع المطور لشراء النسخة الأصلية وتفعيل الحساب"
                _trialLocked.value = true
                _isLoggedIn.value = false
                return false
            }

            _isLoggedIn.value = true
            Toast.makeText(context, "تم تسجيل الدخول بالحساب التجريبي (متبقي: ${formatRemainingTime()})", Toast.LENGTH_LONG).show()
            return true
        }

        _authError.value = "اسم المستخدم أو كلمة المرور غير صحيحة"
        return false
    }

    fun formatRemainingTime(): String {
        val remainingMs = sessionManager.getTrialTimeRemainingMs()
        val hours = remainingMs / (1000 * 60 * 60)
        val minutes = (remainingMs % (1000 * 60 * 60)) / (1000 * 60)
        return "$hours ساعة و $minutes دقيقة"
    }

    fun logout() {
        sessionManager.logout()
        _isLoggedIn.value = false
        _cart.value = emptyMap()
    }

    fun selectCategory(categoryId: Int) {
        _selectedCategoryId.value = categoryId
    }

    // Cart Management
    fun addToCart(item: MenuItem) {
        val currentMap = _cart.value.toMutableMap()
        val existing = currentMap[item.id]
        if (existing != null) {
            currentMap[item.id] = existing.copy(quantity = existing.quantity + 1)
        } else {
            currentMap[item.id] = CartItem(
                id = item.id,
                name = item.name,
                price = item.price,
                quantity = 1
            )
        }
        _cart.value = currentMap
    }

    fun decreaseQuantity(itemId: Int) {
        val currentMap = _cart.value.toMutableMap()
        val existing = currentMap[itemId] ?: return
        if (existing.quantity > 1) {
            currentMap[itemId] = existing.copy(quantity = existing.quantity - 1)
        } else {
            currentMap.remove(itemId)
        }
        _cart.value = currentMap
    }

    fun increaseQuantity(itemId: Int) {
        val currentMap = _cart.value.toMutableMap()
        val existing = currentMap[itemId] ?: return
        currentMap[itemId] = existing.copy(quantity = existing.quantity + 1)
        _cart.value = currentMap
    }

    fun clearCart() {
        _cart.value = emptyMap()
    }

    // Printer Paper Selection
    fun setPaperWidth(width: Int) {
        _paperWidthMm.value = width
        triggerReceiptPreviewUpdate()
    }

    fun setBusinessType(type: String) {
        _businessType.value = type
        sessionManager.setBusinessType(type)
        if (type == "CAFE") {
            _selectedOrderType.value = "DINE_IN"
        }
        triggerReceiptPreviewUpdate()
    }

    fun setOrderType(type: String) {
        _selectedOrderType.value = type
        triggerReceiptPreviewUpdate()
    }

    fun setDeliveryFee(fee: Long) {
        _deliveryFee.value = fee
        triggerReceiptPreviewUpdate()
    }

    fun triggerReceiptPreviewUpdate() {
        val currentCart = _cart.value.values.toList()
        val isRestaurant = _businessType.value == "RESTAURANT"
        val isDelivery = isRestaurant && _selectedOrderType.value == "DELIVERY"
        val activeFee = if (isDelivery) _deliveryFee.value else 0L

        if (currentCart.isNotEmpty()) {
            val itemsSum = currentCart.sumOf { it.price * it.quantity }
            printManager.generateReceiptBitmap(
                storeName = _storeName.value,
                storePhone = _storePhone.value,
                items = currentCart,
                totalAmount = itemsSum + activeFee,
                paperWidthMm = _paperWidthMm.value,
                businessType = _businessType.value,
                orderType = _selectedOrderType.value,
                deliveryFee = activeFee
            )
        } else {
            // Nullify preview if cart is empty
            printManager.generateReceiptBitmap(
                storeName = _storeName.value,
                storePhone = _storePhone.value,
                items = listOf(CartItem(1, "نموذج وجبة تجريبية", 7500, 1)),
                totalAmount = 7500 + activeFee,
                paperWidthMm = _paperWidthMm.value,
                businessType = _businessType.value,
                orderType = _selectedOrderType.value,
                deliveryFee = activeFee
            )
        }
    }

    // Bluetooth discovery helper
    fun getPairedPrinters(): List<BluetoothDevice> {
        return printManager.getPairedDevices()
    }

    fun connectPrinter(device: BluetoothDevice, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val connected = printManager.connectToDevice(device)
            if (connected) {
                onSuccess()
            }
        }
    }

    fun printInvoice() {
        val currentCart = _cart.value.values.toList()
        if (currentCart.isEmpty()) {
            Toast.makeText(context, "سلة الطلبات فارغة!", Toast.LENGTH_SHORT).show()
            return
        }

        viewModelScope.launch {
            _isPrinting.value = true
            val addedAmount = cartTotal.value

            // Record sale in active shift session
            val active = repository.getActiveShift()
            if (active != null) {
                val newSales = active.totalSales + addedAmount
                val newProfit = active.netProfit + (addedAmount * 40 / 100) // 40% profit margin
                repository.updateShift(active.copy(
                    totalSales = newSales,
                    netProfit = newProfit
                ))
            }

            // Generate the image
            val isRestaurant = _businessType.value == "RESTAURANT"
            val isDelivery = isRestaurant && _selectedOrderType.value == "DELIVERY"
            val activeFee = if (isDelivery) _deliveryFee.value else 0L

            val receiptBitmap = printManager.generateReceiptBitmap(
                storeName = _storeName.value,
                storePhone = _storePhone.value,
                items = currentCart,
                totalAmount = addedAmount,
                paperWidthMm = _paperWidthMm.value,
                businessType = _businessType.value,
                orderType = _selectedOrderType.value,
                deliveryFee = activeFee
            )

            // Attempt Bluetooth print
            val success = printManager.printBitmap(receiptBitmap)
            if (success) {
                Toast.makeText(context, "تمت الطباعة وتسجيل الفاتورة بنجاح!", Toast.LENGTH_SHORT).show()
                clearCart()
            } else {
                Toast.makeText(
                    context, 
                    "تم تسجيل الفاتورة بنجاح في الحسابات! (تنبيه: لم يتم الاتصال بالطابعة عبر البلوتوث، يمكنك معاينة الوصل ورقياً على اليسار)", 
                    Toast.LENGTH_LONG
                ).show()
                clearCart() // Always clear cart and complete sale on POS checkout
            }
            _isPrinting.value = false
        }
    }

    // Dynamic Admin Controls (Category and Menu Item Editing)
    fun addCategory(name: String) {
        viewModelScope.launch {
            repository.insertCategory(Category(name = name))
        }
    }

    fun editCategory(category: Category) {
        viewModelScope.launch {
            repository.updateCategory(category)
        }
    }

    fun deleteCategory(id: Int) {
        viewModelScope.launch {
            repository.deleteCategory(id)
            if (_selectedCategoryId.value == id) {
                _selectedCategoryId.value = categories.value.firstOrNull()?.id
            }
        }
    }

    fun addMenuItem(name: String, price: Long, categoryId: Int) {
        viewModelScope.launch {
            repository.insertMenuItem(MenuItem(name = name, price = price, categoryId = categoryId))
        }
    }

    fun editMenuItem(menuItem: MenuItem) {
        viewModelScope.launch {
            repository.updateMenuItem(menuItem)
        }
    }

    fun deleteMenuItem(id: Int) {
        viewModelScope.launch {
            repository.deleteMenuItem(id)
        }
    }

    // Backup & Restore
    fun checkBackupFile() {
        _hasBackupFile.value = backupManager.hasBackupFile()
    }

    fun runExport() {
        if (!sessionManager.isOriginalUser()) {
            Toast.makeText(context, "النسخ الاحتياطي محظور للحسابات التجريبية!", Toast.LENGTH_LONG).show()
            return
        }
        viewModelScope.launch {
            val path = backupManager.exportBackup()
            if (path != null) {
                _backupStatus.value = "تم إنشاء نسخة احتياطية بنجاح في المستندات:\n$path"
                _hasBackupFile.value = true
            } else {
                _backupStatus.value = "فشل تصدير البيانات الاحتياطية"
            }
        }
    }

    fun runImport() {
        if (!sessionManager.isOriginalUser()) {
            Toast.makeText(context, "استعادة البيانات محظورة للحسابات التجريبية!", Toast.LENGTH_LONG).show()
            return
        }
        viewModelScope.launch {
            val success = backupManager.importBackup()
            if (success) {
                _backupStatus.value = "تمت استعادة كافة البيانات والمنيو بنجاح!"
                // Reset select tab
                _selectedCategoryId.value = categories.value.firstOrNull()?.id
            } else {
                _backupStatus.value = "فشل استيراد النسخة الاحتياطية. تأكد من وجود ملف saas_pos_backup.json"
            }
        }
    }

    fun clearBackupStatus() {
        _backupStatus.value = null
    }

    // Shift Lifecycle & Admin Actions
    fun openShift(openingFloat: Long) {
        viewModelScope.launch {
            val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US)
            val currentTime = sdf.format(Date())
            val newSession = ShiftSession(
                openTime = currentTime,
                closeTime = null,
                openingFloat = openingFloat,
                totalSales = 0L,
                netProfit = 0L,
                isOpen = true
            )
            repository.insertShift(newSession)
            Toast.makeText(context, "تم فتح نقطة البيع والوردية بنجاح!", Toast.LENGTH_SHORT).show()
        }
    }

    fun closeShift() {
        viewModelScope.launch {
            val current = repository.getActiveShift()
            if (current != null) {
                val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US)
                val currentTime = sdf.format(Date())
                val closedSession = current.copy(
                    closeTime = currentTime,
                    isOpen = false
                )
                repository.updateShift(closedSession)
                Toast.makeText(context, "تم إغلاق نقطة البيع والوردية بنجاح وتوثيق التقرير المالي!", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun deleteShiftSession(id: Int) {
        if (!sessionManager.isOriginalUser()) {
            Toast.makeText(context, "هذا الإجراء متاح لمالك النظام الأصلي فقط!", Toast.LENGTH_SHORT).show()
            return
        }
        viewModelScope.launch {
            repository.deleteShift(id)
            Toast.makeText(context, "تم حذف سجل الوردية بنجاح", Toast.LENGTH_SHORT).show()
        }
    }

    fun resetWholeDatabase() {
        if (!sessionManager.isOriginalUser()) {
            Toast.makeText(context, "هذا الإجراء متاح لمالك النظام الأصلي فقط!", Toast.LENGTH_SHORT).show()
            return
        }
        viewModelScope.launch {
            repository.clearAllData()
            Toast.makeText(context, "تم مسح وتصفير كافة بيانات النظام والورديات بالكامل بنجاح!", Toast.LENGTH_LONG).show()
        }
    }
}
