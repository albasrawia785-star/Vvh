package com.example.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@SuppressLint("MissingPermission")
@Composable
fun SettingsScreen(
    viewModel: PosViewModel,
    onLogout: () -> Unit
) {
    val isConnected by viewModel.printManager.isConnected.collectAsState()
    val connectedDeviceName by viewModel.printManager.selectedDeviceName.collectAsState()
    val paperWidth by viewModel.paperWidthMm.collectAsState()
    val receiptPreviewBitmap by viewModel.receiptPreview.collectAsState()
    
    val backupStatus by viewModel.backupStatus.collectAsState()
    val hasBackupFile by viewModel.hasBackupFile.collectAsState()
    
    val username = viewModel.sessionManager.getUsername() ?: ""
    val isOriginalUser = viewModel.sessionManager.isOriginalUser()

    // Bluetooth discovery devices state
    var pairedDevices by remember { mutableStateOf<List<android.bluetooth.BluetoothDevice>>(emptyList()) }

    // On open, load paired printers
    LaunchedEffect(Unit) {
        pairedDevices = viewModel.getPairedPrinters()
        viewModel.triggerReceiptPreviewUpdate()
    }

    // Check if wide/landscape
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(LightBackground)
        ) {
            // Main settings controls
            Column(
                modifier = Modifier
                    .weight(if (isLandscape) 0.55f else 1.0f)
                    .fillMaxHeight()
                    .padding(16.dp)
            ) {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1.0f)
                ) {
                    // Page Title
                    item {
                        Column {
                            Text(
                                text = "الإعدادات والطباعة والمزامنة",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyPrimary
                            )
                            Text(
                                text = "تهيئة طابعات البلوتوث والنسخ الاحتياطي وإدارة جلسة الدخول",
                                fontSize = 12.sp,
                                color = SoftText
                            )
                        }
                    }

                    // 1. Bluetooth Printer Management Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Bluetooth, contentDescription = "BT", tint = NavyPrimary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "إعدادات طابعة الفواتير البلوتوث",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = DarkText
                                    )
                                }
                                
                                Spacer(modifier = Modifier.height(10.dp))
                                
                                // Connection Status Banner
                                Surface(
                                    color = if (isConnected) EmeraldSuccess.copy(alpha = 0.12f) else SoftGrayBorder.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .background(if (isConnected) EmeraldSuccess else SoftText, RoundedCornerShape(50))
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = if (isConnected) "متصل بالطابعة: $connectedDeviceName" else "لا يوجد طابعة متصلة حالياً",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isConnected) EmeraldSuccess else SoftText
                                            )
                                        }

                                        if (isConnected) {
                                            TextButton(onClick = { viewModel.printManager.disconnect() }) {
                                                Text("قطع الاتصال", color = CrimsonError, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                Button(
                                    onClick = {
                                        pairedDevices = viewModel.getPairedPrinters()
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(52.dp)
                                        .testTag("bluetooth_discovery_button"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                                ) {
                                    Icon(Icons.Default.Bluetooth, contentDescription = "Scan Icon", tint = Color.White)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("البحث عن طابعات بلوتوث مجاورة", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("الأجهزة المقترنة المكتشفة:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    IconButton(onClick = {
                                        pairedDevices = viewModel.getPairedPrinters()
                                    }) {
                                        Icon(Icons.Default.Refresh, contentDescription = "Refresh paired list", tint = NavyPrimary)
                                    }
                                }

                                if (pairedDevices.isEmpty()) {
                                    Text(
                                        text = "لم يتم العثور على أجهزة بلوتوث مقترنة. يرجى إقران الطابعة أولاً من إعدادات النظام.",
                                        fontSize = 12.sp,
                                        color = SoftText,
                                        modifier = Modifier.padding(vertical = 4.dp)
                                    )
                                } else {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        pairedDevices.forEach { device ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(LightBackground, RoundedCornerShape(8.dp))
                                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column {
                                                    Text(text = device.name ?: "طابعة غير معروفة", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                                    Text(text = device.address, fontSize = 11.sp, color = SoftText)
                                                }
                                                
                                                Button(
                                                    onClick = {
                                                        viewModel.connectPrinter(device) {
                                                            pairedDevices = viewModel.getPairedPrinters()
                                                        }
                                                    },
                                                    shape = RoundedCornerShape(6.dp),
                                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                                                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                                                    modifier = Modifier.height(32.dp)
                                                ) {
                                                    Text("إقران واتصال", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 2. Printer Configurations
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.SettingsApplications, contentDescription = "Config", tint = NavyPrimary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "خيارات الطباعة وقياس الورق",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = DarkText
                                    )
                                }
                                
                                Spacer(modifier = Modifier.height(12.dp))

                                Text("عرض ورق الطباعة الحراري (Paper Size):", fontSize = 13.sp, color = SoftText)
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Button(
                                        onClick = { viewModel.setPaperWidth(58) },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1.0f),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (paperWidth == 58) NavyPrimary else SoftGrayBorder
                                        )
                                    ) {
                                        Text(
                                            text = "قياس 58 ملم (افتراضي)",
                                            color = if (paperWidth == 58) Color.White else DarkText,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }

                                    Button(
                                        onClick = { viewModel.setPaperWidth(80) },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1.0f),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (paperWidth == 80) NavyPrimary else SoftGrayBorder
                                        )
                                    ) {
                                        Text(
                                            text = "قياس 80 ملم (عريض)",
                                            color = if (paperWidth == 80) Color.White else DarkText,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 2.5 Business Type Selection
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth().testTag("business_type_card"),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Store, contentDescription = "Business Type", tint = NavyPrimary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "نوع النشاط التجاري",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = DarkText
                                    )
                                }
                                
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "اختر نوع النشاط لتخصيص شعار الفاتورة المطبوعة وعناصر سلة الطلبات تلقائياً:",
                                    fontSize = 12.sp,
                                    color = SoftText
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                val businessType by viewModel.businessType.collectAsState()

                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Button(
                                        onClick = { viewModel.setBusinessType("RESTAURANT") },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1.0f).testTag("biz_type_restaurant_btn"),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (businessType == "RESTAURANT") NavyPrimary else SoftGrayBorder
                                        )
                                    ) {
                                        Icon(
                                            Icons.Default.Restaurant, 
                                            contentDescription = "Restaurant",
                                            tint = if (businessType == "RESTAURANT") Color.White else DarkText,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "مطعم",
                                            color = if (businessType == "RESTAURANT") Color.White else DarkText,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }

                                    Button(
                                        onClick = { viewModel.setBusinessType("CAFE") },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1.0f).testTag("biz_type_cafe_btn"),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (businessType == "CAFE") NavyPrimary else SoftGrayBorder
                                        )
                                    ) {
                                        Icon(
                                            Icons.Default.LocalCafe, 
                                            contentDescription = "Cafe",
                                            tint = if (businessType == "CAFE") Color.White else DarkText,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "مقهى",
                                            color = if (businessType == "CAFE") Color.White else DarkText,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 3. Backup and Restore (Hidden/Blocked for Trial accounts!)
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CloudSync, contentDescription = "Backup", tint = NavyPrimary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "النسخ الاحتياطي والمزامنة",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = DarkText
                                    )
                                }
                                
                                Spacer(modifier = Modifier.height(10.dp))

                                if (!isOriginalUser) {
                                    // Blocked trial warning
                                    Surface(
                                        color = CrimsonError.copy(alpha = 0.1f),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.Lock, contentDescription = "Lock", tint = CrimsonError)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "ميزة النسخ الاحتياطي معطلة للحساب التجريبي. يرجى تفعيل الحساب الأصلي مدى الحياة.",
                                                color = CrimsonError,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                } else {
                                    Text(
                                        text = "يتيح لك النظام تصدير واستيراد منيو الوجبات والأسعار يدوياً وبدون إنترنت لحفظ بياناتك من الضياع.",
                                        fontSize = 12.sp,
                                        color = SoftText
                                    )

                                    Spacer(modifier = Modifier.height(14.dp))

                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Button(
                                            onClick = { viewModel.runExport() },
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier
                                                .weight(1.0f)
                                                .testTag("backup_export_btn"),
                                            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                                        ) {
                                            Icon(Icons.Default.FileUpload, contentDescription = "Backup Export", modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("تصدير الاحتياطي", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }

                                        Button(
                                            onClick = { viewModel.runImport() },
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier
                                                .weight(1.0f)
                                                .testTag("backup_restore_btn"),
                                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                            enabled = hasBackupFile
                                        ) {
                                            Icon(Icons.Default.FileDownload, contentDescription = "Backup Import", modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("استعادة المنيو", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    if (backupStatus != null) {
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Surface(
                                            color = MaterialTheme.colorScheme.primaryContainer,
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    text = backupStatus ?: "",
                                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                    fontSize = 11.sp,
                                                    modifier = Modifier.weight(0.9f)
                                                )
                                                IconButton(
                                                    onClick = { viewModel.clearBackupStatus() },
                                                    modifier = Modifier.weight(0.1f)
                                                ) {
                                                    Icon(Icons.Default.Close, contentDescription = "Dismiss", modifier = Modifier.size(14.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 4. Admin Reset System Panel (Visible to Original User 'ali' only!)
                    if (isOriginalUser) {
                        item {
                            var showResetDialog by remember { mutableStateOf(false) }
                            
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = CrimsonError.copy(alpha = 0.05f)),
                                border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonError.copy(alpha = 0.3f))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.DeleteSweep, contentDescription = "Reset System", tint = CrimsonError)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "منطقة التحكم وتصفير النظام (خاص بالمالك)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = CrimsonError
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "تنبيه: هذا الإجراء سيمسح جميع الوجبات، الأقسام، والمبيعات السابقة والورديات بشكل كامل ونهائي.",
                                        fontSize = 12.sp,
                                        color = CrimsonError
                                    )
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Button(
                                        onClick = { showResetDialog = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonError),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.Warning, contentDescription = "Warning", tint = Color.White)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("مسح الفواتير وتصفير نقطة البيع بالكامل", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            if (showResetDialog) {
                                AlertDialog(
                                    onDismissRequest = { showResetDialog = false },
                                    confirmButton = {
                                        Button(
                                            onClick = {
                                                viewModel.resetWholeDatabase()
                                                showResetDialog = false
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonError)
                                        ) {
                                            Text("تأكيد مسح وتصفير كل شيء", fontWeight = FontWeight.Bold, color = Color.White)
                                        }
                                    },
                                    dismissButton = {
                                        TextButton(onClick = { showResetDialog = false }) {
                                            Text("إلغاء", fontWeight = FontWeight.Bold, color = NavyPrimary)
                                        }
                                    },
                                    title = { Text("هل أنت متأكد من تصفير النظام؟", fontWeight = FontWeight.Bold, color = Color.Black) },
                                    text = { Text("هذا الإجراء سيقوم بحذف كافة المبيعات والورديات والمنيو نهائياً ولا يمكن التراجع عنه.", color = SoftText) }
                                )
                            }
                        }
                    }

                    // 5. Shift Sessions History (Visible to Original User 'ali' only!)
                    if (isOriginalUser) {
                        item {
                            val shiftHistory by viewModel.shiftHistory.collectAsState()
                            
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.History, contentDescription = "History", tint = NavyPrimary)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "أرشيف الورديات والتقارير المالية السابقة",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = DarkText
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))

                                    if (shiftHistory.isEmpty()) {
                                        Text("لا توجد ورديات مغلقة أو محفوظة في الأرشيف بعد.", color = SoftText, fontSize = 12.sp)
                                    } else {
                                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            shiftHistory.forEach { session ->
                                                Card(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    shape = RoundedCornerShape(8.dp),
                                                    colors = CardDefaults.cardColors(
                                                        containerColor = if (session.isOpen) NavyPrimary.copy(alpha = 0.05f) else LightBackground
                                                    ),
                                                    border = if (session.isOpen) androidx.compose.foundation.BorderStroke(1.dp, NavyPrimary.copy(alpha = 0.2f)) else null
                                                ) {
                                                    Column(modifier = Modifier.padding(12.dp)) {
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Text(
                                                                text = if (session.isOpen) "الوردية الحالية (نشطة)" else "وردية منتهية #${session.id}",
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 13.sp,
                                                                color = if (session.isOpen) NavyPrimary else DarkText
                                                            )
                                                            if (!session.isOpen) {
                                                                IconButton(
                                                                    onClick = { viewModel.deleteShiftSession(session.id) },
                                                                    modifier = Modifier.size(24.dp)
                                                                ) {
                                                                    Icon(Icons.Default.Delete, contentDescription = "Delete record", tint = CrimsonError, modifier = Modifier.size(16.dp))
                                                                }
                                                            }
                                                        }
                                                        Spacer(modifier = Modifier.height(6.dp))
                                                        Text("• وقت الفتح: ${session.openTime}", fontSize = 12.sp, color = DarkText)
                                                        session.closeTime?.let {
                                                            Text("• وقت الإغلاق: $it", fontSize = 12.sp, color = DarkText)
                                                        }
                                                        Text("• رأس المال: ${formatCurrency(session.openingFloat)}", fontSize = 12.sp, color = DarkText)
                                                        Text("• إجمالي المبيعات: ${formatCurrency(session.totalSales)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                                        Text("• صافي الأرباح (40%): ${formatCurrency(session.netProfit)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // If compact vertical, show the receipt preview inside settings list
                    if (!isLandscape) {
                        item {
                            ReceiptPreviewCard(receiptPreviewBitmap, paperWidth)
                        }
                    }
                }

                // 4. Session Logs and Logout Button at the bottom
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = SoftGrayBorder)
                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        viewModel.logout()
                        onLogout()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("logout_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonError),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Logout, contentDescription = "Log out", tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تسجيل الخروج الآمن", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }

            // Receipt preview panel (Visible on Landscape Mode)
            if (isLandscape) {
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .fillMaxHeight()
                        .background(SoftGrayBorder)
                )

                Column(
                    modifier = Modifier
                        .weight(0.45f)
                        .fillMaxHeight()
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    ReceiptPreviewCard(receiptPreviewBitmap, paperWidth)
                }
            }
        }
    }
}

@Composable
fun ReceiptPreviewCard(bitmap: Bitmap?, paperWidth: Int) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.ReceiptLong, contentDescription = "Receipt Preview icon", tint = NavyPrimary)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "معاينة شكل الوصل الورقي ($paperWidth ملم)",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = DarkText
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Visual simulation of a real receipt thermal paper roll
        Card(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .shadow(4.dp, RoundedCornerShape(4.dp))
                .border(1.dp, SoftGrayBorder, RoundedCornerShape(4.dp)),
            shape = RoundedCornerShape(4.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Simulated Printed Receipt",
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White)
                        .padding(8.dp)
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(16.dp)
                    ) {
                        CircularProgressIndicator(strokeWidth = 3.dp, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "يجري إعداد معاينة الوصل الورقي...",
                            fontSize = 11.sp,
                            color = SoftText,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}
