package com.example.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Category
import com.example.data.MenuItem
import com.example.print.CartItem
import com.example.ui.theme.*
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CashierScreen(
    viewModel: PosViewModel
) {
    val storeName by viewModel.storeName.collectAsState()
    val ownerName by viewModel.ownerName.collectAsState()
    
    val categories by viewModel.categories.collectAsState()
    val menuItems by viewModel.menuItems.collectAsState()
    val selectedCatId by viewModel.selectedCategoryId.collectAsState()
    
    val cart by viewModel.cart.collectAsState()
    val cartTotal by viewModel.cartTotal.collectAsState()
    
    val activeShift by viewModel.activeShift.collectAsState()
    var showCloseShiftDialog by remember { mutableStateOf(false) }
    
    var searchQuery by remember { mutableStateOf("") }
    
    // Check if device is in wide/landscape mode (SaaS Desktop/Tablet POS view)
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    
    var showMobileCartSheet by remember { mutableStateOf(false) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .background(LightBackground)
            ) {
                // Main menu grid column
                Column(
                    modifier = Modifier
                        .weight(if (isLandscape) 0.62f else 1.0f)
                        .fillMaxHeight()
                        .padding(12.dp)
                ) {
                    // Header Panel
                    HeaderWidget(storeName, ownerName, viewModel.sessionManager.getUsername() ?: "")

                    Spacer(modifier = Modifier.height(10.dp))

                    // Active Shift Summary Panel
                    activeShift?.let { shift ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(NavyPrimary, RoundedCornerShape(12.dp))
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(Color(0xFF10B981), RoundedCornerShape(50))
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("الوردية نشطة ومؤمنة", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("الفتح: ${shift.openTime} | رأس المال: ${formatCurrency(shift.openingFloat)}", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("المبيعات: ${formatCurrency(shift.totalSales)}", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                                    Text("الأرباح المقدرة (40%): ${formatCurrency(shift.netProfit)}", color = Color(0xFF10B981), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Button(
                                    onClick = { showCloseShiftDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonError),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    Icon(Icons.Default.PowerSettingsNew, contentDescription = "Close Shift", tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("إغلاق الوردية", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("menu_search"),
                    placeholder = { Text("ابحث عن وجبة أو مشروب...", fontSize = 14.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Icon") },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear Search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = SoftGrayBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Categories Row Tabs
                if (categories.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("الرجاء إضافة أقسام للمنيو من لوحة التحكم", color = SoftText, fontSize = 13.sp)
                    }
                } else {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // "الكل" tab
                        item {
                            CategoryTab(
                                categoryName = "كافة المواد",
                                isSelected = selectedCatId == null,
                                onClick = { viewModel.selectCategory(-1) } // represent all
                            )
                        }
                        items(categories) { cat ->
                            CategoryTab(
                                categoryName = cat.name,
                                isSelected = selectedCatId == cat.id,
                                onClick = { viewModel.selectCategory(cat.id) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Menu Items Grid
                val filteredItems = remember(menuItems, selectedCatId, searchQuery) {
                    menuItems.filter { item ->
                        val matchesCat = selectedCatId == null || selectedCatId == -1 || item.categoryId == selectedCatId
                        val matchesSearch = searchQuery.isEmpty() || item.name.contains(searchQuery, ignoreCase = true)
                        matchesCat && matchesSearch
                    }
                }

                if (filteredItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1.0f)
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.RestaurantMenu,
                                contentDescription = "Empty menu",
                                modifier = Modifier.size(54.dp),
                                tint = SoftText.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = if (menuItems.isEmpty()) "لا توجد وجبات مسجلة بعد" else "لم يتم العثور على وجبات مطابقة للبحث",
                                fontWeight = FontWeight.Bold,
                                color = DarkText,
                                fontSize = 15.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (menuItems.isEmpty()) "انتقل للوحة التحكم لإضافة قائمة الطعام والأسعار" else "جرب البحث بكلمات أخرى",
                                color = SoftText,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 145.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier
                            .weight(1.0f)
                            .testTag("menu_items_grid")
                    ) {
                        items(filteredItems) { item ->
                            MenuItemCard(
                                item = item,
                                onClick = {
                                    viewModel.addToCart(item)
                                    viewModel.triggerReceiptPreviewUpdate()
                                }
                            )
                        }
                    }
                }

                // If portrait mode, show a Floating Summary bar at the bottom to open the Cart BottomSheet
                if (!isLandscape && cart.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { showMobileCartSheet = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("mobile_cart_bar"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ShoppingCart, contentDescription = "Cart icon", tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "عرض سلة الطلبات (${cart.values.sumOf { it.quantity }})",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                            Text(
                                text = formatCurrency(cartTotal),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }

            // Right side Cart panel (Visible only in Landscape Mode)
            if (isLandscape) {
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .fillMaxHeight()
                        .background(SoftGrayBorder)
                )

                Column(
                    modifier = Modifier
                        .weight(0.38f)
                        .fillMaxHeight()
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(14.dp)
                ) {
                    CartWidget(
                        cart = cart.values.toList(),
                        cartTotal = cartTotal,
                        viewModel = viewModel
                    )
                }
            }
        }

        // Bottom sheet for compact vertical viewports
        if (!isLandscape && showMobileCartSheet) {
            ModalBottomSheet(
                onDismissRequest = { showMobileCartSheet = false },
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .navigationBarsPadding()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "سلة المبيعات الحالية",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = DarkText
                        )
                        IconButton(onClick = { viewModel.clearCart() }) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "Clear all", tint = CrimsonError)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Box(modifier = Modifier.weight(0.6f, fill = false)) {
                        if (cart.isEmpty()) {
                            showMobileCartSheet = false
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(cart.values.toList()) { item ->
                                    CartItemRow(item = item, viewModel = viewModel)
                                }
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = SoftGrayBorder)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Dynamic Order Options for Restaurant (Mobile sheet)
                    val businessType by viewModel.businessType.collectAsState()
                    val selectedOrderType by viewModel.selectedOrderType.collectAsState()
                    val deliveryFee by viewModel.deliveryFee.collectAsState()

                    if (businessType == "RESTAURANT") {
                        Text(
                            text = "نوع الطلب (المطعم):",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = SoftText
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val orderTypes = listOf(
                                "DINE_IN" to "صالة",
                                "TAKEAWAY" to "سفري",
                                "DELIVERY" to "دليفري"
                            )
                            orderTypes.forEach { (type, label) ->
                                val isSelected = selectedOrderType == type
                                Box(
                                    modifier = Modifier
                                        .weight(1.0f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { viewModel.setOrderType(type) }
                                        .testTag("mobile_order_type_$type")
                                        .then(
                                            if (isSelected) Modifier.background(NavyPrimary)
                                            else Modifier
                                                .border(1.dp, SoftGrayBorder, RoundedCornerShape(8.dp))
                                                .background(Color.White)
                                        )
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else DarkText
                                    )
                                }
                            }
                        }

                        if (selectedOrderType == "DELIVERY") {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(LightBackground, RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "رسوم التوصيل:",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DarkText
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { if (deliveryFee > 1000) viewModel.setDeliveryFee(deliveryFee - 1000) },
                                        modifier = Modifier.size(28.dp).background(Color.White, RoundedCornerShape(4.dp))
                                    ) {
                                        Icon(Icons.Default.Remove, contentDescription = "Decrease delivery fee", modifier = Modifier.size(14.dp))
                                    }
                                    Text(
                                        text = formatCurrency(deliveryFee),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp)
                                    )
                                    IconButton(
                                        onClick = { viewModel.setDeliveryFee(deliveryFee + 1000) },
                                        modifier = Modifier.size(28.dp).background(Color.White, RoundedCornerShape(4.dp))
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Increase delivery fee", modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = SoftGrayBorder)
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("المجموع النهائي:", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(
                            text = formatCurrency(cartTotal),
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            viewModel.printInvoice()
                            showMobileCartSheet = false
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = "Print")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تأكيد المبيعات وطباعة الوصل", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }

        // --- OPEN SHIFT MODAL DIALOG ---
        if (activeShift == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.82f))
                    .clickable(enabled = false) {}
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                var openingFloatInput by remember { mutableStateOf("") }
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 480.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .background(NavyPrimary.copy(alpha = 0.1f), RoundedCornerShape(50))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.LockOpen,
                                contentDescription = "Lock Open Icon",
                                tint = NavyPrimary,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(18.dp))
                        Text(
                            text = "فتح نقطة البيع والوردية",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "يرجى تسجيل رأس المال الحالي المتوفر في صندوق الكاشير (القاصة) لبدء العمل واستقبال طلبات الزبائن.",
                            fontSize = 14.sp,
                            color = SoftText,
                            textAlign = TextAlign.Center,
                            lineHeight = 20.sp
                        )
                        Spacer(modifier = Modifier.height(24.dp))

                        OutlinedTextField(
                            value = openingFloatInput,
                            onValueChange = { openingFloatInput = it.filter { char -> char.isDigit() } },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("رأس المال الافتتاحي بالدينار العراقي (د.ع)", fontWeight = FontWeight.Bold, color = Color.Black) },
                            placeholder = { Text("مثال: 50000") },
                            singleLine = true,
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NavyPrimary,
                                unfocusedBorderColor = SoftGrayBorder,
                                focusedTextColor = Color.Black,
                                unfocusedTextColor = Color.Black
                            )
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                val amount = openingFloatInput.toLongOrNull() ?: 0L
                                viewModel.openShift(amount)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                        ) {
                            Text(
                                text = "بدء الوردية والعمل الآن",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        // --- CLOSE SHIFT REPORT DIALOG ---
        if (showCloseShiftDialog && activeShift != null) {
            val shift = activeShift!!
            AlertDialog(
                onDismissRequest = { showCloseShiftDialog = false },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.closeShift()
                            showCloseShiftDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonError)
                    ) {
                        Text("إغلاق الوردية وحفظ التقرير المالي", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCloseShiftDialog = false }) {
                        Text("إلغاء", fontWeight = FontWeight.Bold, color = NavyPrimary)
                    }
                },
                title = {
                    Text(
                        text = "تقرير إغلاق نقطة البيع",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.Black,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            "عند تأكيد الإغلاق، سيتم حفظ مبيعات وأرباح هذا اليوم في الأرشيف وتصفير نقطة البيع لبدء وردية جديدة.",
                            fontSize = 13.sp,
                            color = SoftText,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = SoftGrayBorder)
                        Spacer(modifier = Modifier.height(4.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("وقت البدء والفتح:", fontWeight = FontWeight.Bold, color = Color.Black)
                            Text(shift.openTime, color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("وقت الإغلاق المتوقع:", fontWeight = FontWeight.Bold, color = Color.Black)
                            val sdf = java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale.US)
                            Text(sdf.format(java.util.Date()), color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("رأس المال الافتتاحي:", fontWeight = FontWeight.Bold, color = Color.Black)
                            Text(formatCurrency(shift.openingFloat), color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("إجمالي المبيعات:", fontWeight = FontWeight.Bold, color = Color.Black)
                            Text(formatCurrency(shift.totalSales), fontWeight = FontWeight.Black, color = Color.Black)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("صافي الأرباح (40%):", fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                            Text(formatCurrency(shift.netProfit), fontWeight = FontWeight.Black, color = EmeraldSuccess)
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}
}

@Composable
fun HeaderWidget(storeName: String, ownerName: String, username: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White, RoundedCornerShape(12.dp))
            .border(1.dp, SoftGrayBorder, RoundedCornerShape(12.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = storeName,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = NavyPrimary,
                modifier = Modifier.testTag("cashier_store_name")
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "المسؤول: $ownerName",
                fontSize = 12.sp,
                color = SoftText
            )
        }

        // Account status tag
        Box(
            modifier = Modifier
                .background(
                    if (username == "ali") EmeraldSuccess.copy(alpha = 0.15f) else Color(0xFFF59E0B).copy(alpha = 0.15f),
                    RoundedCornerShape(8.dp)
                )
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(if (username == "ali") EmeraldSuccess else Color(0xFFF59E0B), RoundedCornerShape(50))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (username == "ali") "النسخة الأصلية" else "فترة تجريبية",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (username == "ali") EmeraldSuccess else Color(0xFFD97706)
                )
            }
        }
    }
}

@Composable
fun CategoryTab(
    categoryName: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) NavyPrimary else Color.White)
            .border(1.dp, if (isSelected) NavyPrimary else SoftGrayBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = categoryName,
            color = if (isSelected) Color.White else SoftText,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            fontSize = 13.sp
        )
    }
}

@Composable
fun MenuItemCard(
    item: MenuItem,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("menu_item_${item.id}"),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Food Badge Icon Container
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(LightBackground, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Fastfood,
                    contentDescription = "Food icon",
                    tint = NavyPrimary.copy(alpha = 0.8f),
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Meal Name
            Text(
                text = item.name,
                fontWeight = FontWeight.Black,
                fontSize = 18.sp,
                color = Color(0xFF000000), // Pure Black
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Meal Price
            Text(
                text = formatCurrency(item.price),
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                color = Color(0xFF000000), // Pure Black
                textAlign = TextAlign.Left,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun CartWidget(
    cart: List<CartItem>,
    cartTotal: Long,
    viewModel: PosViewModel
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ShoppingCart, contentDescription = "Shopping Cart", tint = NavyPrimary)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "سلة المشتريات",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = DarkText
                )
            }

            if (cart.isNotEmpty()) {
                IconButton(onClick = { viewModel.clearCart() }) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear all items",
                        tint = CrimsonError
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        HorizontalDivider(color = SoftGrayBorder)
        Spacer(modifier = Modifier.height(10.dp))

        if (cart.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1.0f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.AddShoppingCart,
                        contentDescription = "Empty cart",
                        modifier = Modifier.size(46.dp),
                        tint = SoftText.copy(alpha = 0.4f)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "السلة فارغة",
                        fontWeight = FontWeight.SemiBold,
                        color = SoftText,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "اختر الوجبات لإضافتها هنا",
                        color = SoftText.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1.0f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cart) { item ->
                    CartItemRow(item = item, viewModel = viewModel)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = SoftGrayBorder)
            Spacer(modifier = Modifier.height(12.dp))

            // Dynamic Order Options for Restaurant (Cart Widget)
            val businessType by viewModel.businessType.collectAsState()
            val selectedOrderType by viewModel.selectedOrderType.collectAsState()
            val deliveryFee by viewModel.deliveryFee.collectAsState()

            if (businessType == "RESTAURANT") {
                Text(
                    text = "نوع الطلب (المطعم):",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = SoftText
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val orderTypes = listOf(
                        "DINE_IN" to "صالة",
                        "TAKEAWAY" to "سفري",
                        "DELIVERY" to "دليفري"
                    )
                    orderTypes.forEach { (type, label) ->
                        val isSelected = selectedOrderType == type
                        Box(
                            modifier = Modifier
                                .weight(1.0f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { viewModel.setOrderType(type) }
                                .testTag("order_type_$type")
                                .then(
                                    if (isSelected) Modifier.background(NavyPrimary)
                                    else Modifier
                                        .border(1.dp, SoftGrayBorder, RoundedCornerShape(8.dp))
                                        .background(Color.White)
                                )
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else DarkText
                            )
                        }
                    }
                }

                if (selectedOrderType == "DELIVERY") {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(LightBackground, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "رسوم التوصيل:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = DarkText
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { if (deliveryFee > 1000) viewModel.setDeliveryFee(deliveryFee - 1000) },
                                modifier = Modifier.size(28.dp).background(Color.White, RoundedCornerShape(4.dp))
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "Decrease delivery fee", modifier = Modifier.size(14.dp))
                            }
                            Text(
                                text = formatCurrency(deliveryFee),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp)
                            )
                            IconButton(
                                onClick = { viewModel.setDeliveryFee(deliveryFee + 1000) },
                                modifier = Modifier.size(28.dp).background(Color.White, RoundedCornerShape(4.dp))
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Increase delivery fee", modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = SoftGrayBorder)
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Total Block
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "المجموع الكلي:",
                    fontWeight = FontWeight.Bold,
                    color = DarkText,
                    fontSize = 15.sp
                )
                Text(
                    text = formatCurrency(cartTotal),
                    fontWeight = FontWeight.ExtraBold,
                    color = NavyPrimary,
                    fontSize = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Print Receipt Button
            Button(
                onClick = { viewModel.printInvoice() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("print_receipt_btn"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
            ) {
                Icon(Icons.Default.Print, contentDescription = "Print printer Icon")
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "طباعة الوصل للزبون",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun CartItemRow(
    item: CartItem,
    viewModel: PosViewModel
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("cart_item_${item.id}"),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = LightBackground),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(0.55f)) {
                Text(
                    text = item.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = DarkText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = formatCurrency(item.price),
                    fontSize = 11.sp,
                    color = AmberAccent,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Quantity adjust buttons row
            Row(
                modifier = Modifier.weight(0.45f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.End
            ) {
                // Decrement Button
                IconButton(
                    onClick = { viewModel.decreaseQuantity(item.id) },
                    modifier = Modifier
                        .size(28.dp)
                        .background(Color.White, RoundedCornerShape(6.dp))
                        .testTag("decrement_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Remove,
                        contentDescription = "Decrease",
                        modifier = Modifier.size(14.dp),
                        tint = DarkText
                    )
                }

                Text(
                    text = item.quantity.toString(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .testTag("quantity_${item.id}"),
                    textAlign = TextAlign.Center
                )

                // Increment Button
                IconButton(
                    onClick = { viewModel.increaseQuantity(item.id) },
                    modifier = Modifier
                        .size(28.dp)
                        .background(Color.White, RoundedCornerShape(6.dp))
                        .testTag("increment_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Increase",
                        modifier = Modifier.size(14.dp),
                        tint = DarkText
                    )
                }
            }
        }
    }
}

// Utility to format Iraq currency in Arabic presentation
fun formatCurrency(amount: Long): String {
    return String.format(Locale.ENGLISH, "%,d د.ع", amount)
}
