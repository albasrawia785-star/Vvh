package com.example.auth

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("pos_auth_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_USERNAME = "username"
        private const val KEY_TRIAL_START_TIME = "trial_start_time"
        private const val KEY_TRIAL_LOCKED = "trial_locked"
        
        // 24 hours in milliseconds = 24 * 60 * 60 * 1000 = 86,400,000
        private const val TRIAL_DURATION_MS = 24 * 60 * 60 * 1000L
    }

    fun login(username: String) {
        prefs.edit().apply {
            putBoolean(KEY_IS_LOGGED_IN, true)
            putString(KEY_USERNAME, username)
            
            if (username == "1") {
                // Trial User: Check if we already have a start time, if not, set it
                val existingStart = prefs.getLong(KEY_TRIAL_START_TIME, 0L)
                if (existingStart == 0L) {
                    putLong(KEY_TRIAL_START_TIME, System.currentTimeMillis())
                }
            }
            apply()
        }
    }

    fun logout() {
        prefs.edit().apply {
            putBoolean(KEY_IS_LOGGED_IN, false)
            putString(KEY_USERNAME, null)
            apply()
        }
    }

    fun isLoggedIn(): Boolean {
        // If the current session is trial and it's expired, force them out
        if (prefs.getBoolean(KEY_IS_LOGGED_IN, false)) {
            val user = getUsername()
            if (user == "1" && isTrialExpired()) {
                logout()
                lockTrial()
                return false
            }
            return true
        }
        return false
    }

    fun getUsername(): String? {
        return prefs.getString(KEY_USERNAME, null)
    }

    fun isOriginalUser(): Boolean {
        return getUsername() == "ali"
    }

    fun isTrialUser(): Boolean {
        return getUsername() == "1"
    }

    fun getTrialStartTime(): Long {
        return prefs.getLong(KEY_TRIAL_START_TIME, 0L)
    }

    fun getBusinessType(): String {
        return prefs.getString("business_type", "RESTAURANT") ?: "RESTAURANT"
    }

    fun setBusinessType(type: String) {
        prefs.edit().putString("business_type", type).apply()
    }

    fun getTrialTimeRemainingMs(): Long {
        val start = getTrialStartTime()
        if (start == 0L) return TRIAL_DURATION_MS
        val elapsed = System.currentTimeMillis() - start
        val remaining = TRIAL_DURATION_MS - elapsed
        return if (remaining < 0) 0L else remaining
    }

    fun isTrialExpired(): Boolean {
        if (isTrialLocked()) return true
        val start = getTrialStartTime()
        if (start == 0L) return false
        val elapsed = System.currentTimeMillis() - start
        val expired = elapsed >= TRIAL_DURATION_MS
        if (expired) {
            lockTrial()
        }
        return expired
    }

    fun lockTrial() {
        prefs.edit().putBoolean(KEY_TRIAL_LOCKED, true).apply()
    }

    fun isTrialLocked(): Boolean {
        return prefs.getBoolean(KEY_TRIAL_LOCKED, false)
    }
}
