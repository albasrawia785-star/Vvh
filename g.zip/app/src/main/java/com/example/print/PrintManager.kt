package com.example.print

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class PrintManager(private val context: Context) {

    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothManager.adapter
    }

    private val _discoveredDevices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<BluetoothDevice>> = _discoveredDevices

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected

    private val _selectedDeviceName = MutableStateFlow<String?>(null)
    val selectedDeviceName: StateFlow<String?> = _selectedDeviceName

    private var activeSocket: BluetoothSocket? = null
    private val prnUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    // State flow for receipt preview bitmap
    private val _receiptPreview = MutableStateFlow<Bitmap?>(null)
    val receiptPreview: StateFlow<Bitmap?> = _receiptPreview

    fun hasBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    @SuppressLint("MissingPermission")
    fun getPairedDevices(): List<BluetoothDevice> {
        if (!hasBluetoothPermission() || bluetoothAdapter == null) return emptyList()
        return bluetoothAdapter?.bondedDevices?.toList() ?: emptyList()
    }

    @SuppressLint("MissingPermission")
    suspend fun connectToDevice(device: BluetoothDevice): Boolean = withContext(Dispatchers.IO) {
        if (!hasBluetoothPermission()) return@withContext false
        try {
            activeSocket?.close()
            val socket = device.createRfcommSocketToServiceRecord(prnUuid)
            socket.connect()
            activeSocket = socket
            _isConnected.value = true
            _selectedDeviceName.value = device.name ?: device.address
            return@withContext true
        } catch (e: Exception) {
            Log.e("PrintManager", "Error connecting to Bluetooth printer", e)
            _isConnected.value = false
            _selectedDeviceName.value = null
            return@withContext false
        }
    }

    fun disconnect() {
        try {
            activeSocket?.close()
            activeSocket = null
            _isConnected.value = false
            _selectedDeviceName.value = null
        } catch (e: Exception) {
            Log.e("PrintManager", "Error disconnecting", e)
        }
    }

    // Helper to format currency in English numbers with (د.ع) suffix
    private fun formatCurrency(amount: Long): String {
        return String.format(Locale.ENGLISH, "%,d د.ع", amount)
    }

    // Generates a receipt bitmap with business-specific logos and order type details
    fun generateReceiptBitmap(
        storeName: String,
        storePhone: String,
        items: List<CartItem>,
        totalAmount: Long,
        paperWidthMm: Int = 58, // 58 or 80
        businessType: String = "RESTAURANT",
        orderType: String = "DINE_IN",
        deliveryFee: Long = 0L
    ): Bitmap {
        val width = if (paperWidthMm == 80) 576 else 384
        
        // Calculate estimated height dynamically based on items
        val itemLineHeight = 35
        val headerHeight = 350 // increased to account for logo and business type details
        val footerHeight = 220
        val dynamicHeight = headerHeight + (items.size * itemLineHeight) + footerHeight
        
        val bitmap = Bitmap.createBitmap(width, dynamicHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        
        // Fill white background
        canvas.drawColor(Color.WHITE)
        
        val paint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
        }
        
        val textPaint = TextPaint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        var currentY = 40f

        // Draw Business Logo (Restaurant Chef Hat / Cafe Shisha)
        val logoCenterX = (width / 2).toFloat()
        val logoCenterY = currentY + 35f
        
        // Draw the appropriate vector logo
        if (businessType == "RESTAURANT") {
            // Draw decorative outer plate outline
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = Color.BLACK
            canvas.drawCircle(logoCenterX, logoCenterY, 35f, paint)

            // Draw Chef hat inside (filled)
            paint.style = Paint.Style.FILL
            val chefPath = android.graphics.Path().apply {
                // Base band of hat
                moveTo(logoCenterX - 18f, logoCenterY + 18f)
                lineTo(logoCenterX + 18f, logoCenterY + 18f)
                lineTo(logoCenterX + 18f, logoCenterY + 10f)
                lineTo(logoCenterX - 18f, logoCenterY + 10f)
                close()
            }
            canvas.drawPath(chefPath, paint)

            // Middle puff
            canvas.drawCircle(logoCenterX, logoCenterY - 5f, 12f, paint)
            // Left puff
            canvas.drawCircle(logoCenterX - 11f, logoCenterY, 9f, paint)
            // Right puff
            canvas.drawCircle(logoCenterX + 11f, logoCenterY, 9f, paint)
        } else {
            // Cafe Hookah / Shisha Logo
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = Color.BLACK
            canvas.drawCircle(logoCenterX, logoCenterY, 35f, paint)

            // Draw Hookah parts (filled)
            paint.style = Paint.Style.FILL
            // 1. Bottom glass bowl: bulbous/bulb shape
            val bowlPath = android.graphics.Path().apply {
                moveTo(logoCenterX - 12f, logoCenterY + 22f)
                lineTo(logoCenterX + 12f, logoCenterY + 22f)
                quadTo(logoCenterX + 18f, logoCenterY + 12f, logoCenterX + 6f, logoCenterY + 5f)
                lineTo(logoCenterX - 6f, logoCenterY + 5f)
                quadTo(logoCenterX - 18f, logoCenterY + 12f, logoCenterX - 12f, logoCenterY + 22f)
                close()
            }
            canvas.drawPath(bowlPath, paint)

            // 2. Vertical stem (shaft)
            canvas.drawRect(logoCenterX - 2f, logoCenterY - 25f, logoCenterX + 2f, logoCenterY + 5f, paint)

            // 3. Tray near the top
            canvas.drawRect(logoCenterX - 10f, logoCenterY - 27f, logoCenterX + 10f, logoCenterY - 24f, paint)

            // 4. Head/Clay bowl on the very top
            val headPath = android.graphics.Path().apply {
                moveTo(logoCenterX - 6f, logoCenterY - 27f)
                lineTo(logoCenterX + 6f, logoCenterY - 27f)
                lineTo(logoCenterX + 8f, logoCenterY - 33f)
                lineTo(logoCenterX - 8f, logoCenterY - 33f)
                close()
            }
            canvas.drawPath(headPath, paint)

            // 5. Shisha hose coming out from bottom bowl side and curling up/down
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2f
            val hosePath = android.graphics.Path().apply {
                moveTo(logoCenterX + 10f, logoCenterY + 12f) // starts from bowl
                cubicTo(logoCenterX + 22f, logoCenterY + 16f, logoCenterX + 25f, logoCenterY, logoCenterX + 18f, logoCenterY - 5f)
            }
            canvas.drawPath(hosePath, paint)
        }

        // Reset paint style
        paint.style = Paint.Style.FILL
        currentY += 105f

        // 1. Draw Store Name (Large Bold)
        paint.textSize = 34f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(storeName, (width / 2).toFloat(), currentY, paint)
        
        currentY += 45f

        // 2. Draw Store Phone & Subheader
        paint.textSize = 22f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("هاتف: $storePhone", (width / 2).toFloat(), currentY, paint)
        
        currentY += 35f
        
        val dateFormat = SimpleDateFormat("yyyy/MM/dd hh:mm a", Locale("ar"))
        val currentDateStr = dateFormat.format(Date())
        canvas.drawText(currentDateStr, (width / 2).toFloat(), currentY, paint)
        
        currentY += 30f

        // Draw Order Type
        val labelOrderType = if (businessType == "RESTAURANT") {
            when (orderType) {
                "DINE_IN" -> "نوع الطلب: صالة"
                "TAKEAWAY" -> "نوع الطلب: سفري"
                "DELIVERY" -> "نوع الطلب: توصيل (دليفري)"
                else -> "نوع الطلب: صالة"
            }
        } else {
            "نوع الطلب: صالة / طلب طاولة مباشر"
        }
        canvas.drawText(labelOrderType, (width / 2).toFloat(), currentY, paint)
        
        currentY += 30f
        
        // Dotted Separator
        paint.textSize = 22f
        val separator = if (paperWidthMm == 80) "------------------------------------------------" else "--------------------------------"
        canvas.drawText(separator, (width / 2).toFloat(), currentY, paint)
        
        currentY += 35f

        // 3. Draw Table Header
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 20f
        
        if (paperWidthMm == 80) {
            // 80mm columns: Item name, Qty, Price, Total
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText("المادة", (width - 15).toFloat(), currentY, paint)
            
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("العدد", (width * 0.50).toFloat(), currentY, paint)
            canvas.drawText("السعر", (width * 0.30).toFloat(), currentY, paint)
            
            paint.textAlign = Paint.Align.LEFT
            canvas.drawText("المجموع", 15f, currentY, paint)
        } else {
            // 58mm columns: Item name & Qty on right, Total on left
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText("المادة والكمية", (width - 10).toFloat(), currentY, paint)
            
            paint.textAlign = Paint.Align.LEFT
            canvas.drawText("المجموع", 10f, currentY, paint)
        }

        currentY += 25f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText(separator, (width / 2).toFloat(), currentY, paint)
        
        currentY += 30f

        // 4. Draw Cart Items
        paint.textSize = 20f
        for (item in items) {
            val truncatedName = if (item.name.length > 20) item.name.substring(0, 18) + ".." else item.name
            
            if (paperWidthMm == 80) {
                // Name
                paint.textAlign = Paint.Align.RIGHT
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText(truncatedName, (width - 15).toFloat(), currentY, paint)
                
                // Qty, Unit Price, Total Price
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                paint.textAlign = Paint.Align.CENTER
                canvas.drawText(item.quantity.toString(), (width * 0.50).toFloat(), currentY, paint)
                canvas.drawText(formatCurrency(item.price), (width * 0.30).toFloat(), currentY, paint)
                
                paint.textAlign = Paint.Align.LEFT
                canvas.drawText(formatCurrency(item.price * item.quantity), 15f, currentY, paint)
            } else {
                // 58mm
                paint.textAlign = Paint.Align.RIGHT
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText("$truncatedName (x${item.quantity})", (width - 10).toFloat(), currentY, paint)
                
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                paint.textAlign = Paint.Align.LEFT
                canvas.drawText(formatCurrency(item.price * item.quantity), 10f, currentY, paint)
            }
            
            currentY += itemLineHeight
        }

        currentY += 10f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(separator, (width / 2).toFloat(), currentY, paint)
        
        currentY += 35f

        // 5. Draw Total and Delivery Breakdown
        paint.textSize = 20f
        if (businessType == "RESTAURANT" && orderType == "DELIVERY") {
            // Subtotal
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText("مجموع المواد:", (width - 15).toFloat(), currentY, paint)
            
            paint.textAlign = Paint.Align.LEFT
            canvas.drawText(formatCurrency(totalAmount - deliveryFee), 15f, currentY, paint)
            
            currentY += 35f
            
            // Delivery Fee
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText("رسوم التوصيل:", (width - 15).toFloat(), currentY, paint)
            
            paint.textAlign = Paint.Align.LEFT
            canvas.drawText(formatCurrency(deliveryFee), 15f, currentY, paint)
            
            currentY += 35f
            
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText(separator, (width / 2).toFloat(), currentY, paint)
            
            currentY += 35f
        }

        // Draw Grand Total
        paint.textSize = 24f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText("المجموع النهائي:", (width - 15).toFloat(), currentY, paint)
        
        paint.textAlign = Paint.Align.LEFT
        canvas.drawText(formatCurrency(totalAmount), 15f, currentY, paint)

        currentY += 45f

        // 6. Draw Footer
        paint.textSize = 18f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("شكراً لزيارتكم وصحتين وعافية!", (width / 2).toFloat(), currentY, paint)
        
        currentY += 25f
        canvas.drawText("صمم وبرمج بواسطة المطور علي", (width / 2).toFloat(), currentY, paint)

        _receiptPreview.value = bitmap
        return bitmap
    }

    // Converts a Bitmap into ESC/POS binary graphics print commands (GS v 0 format)
    suspend fun printBitmap(bitmap: Bitmap): Boolean = withContext(Dispatchers.IO) {
        val socket = activeSocket ?: return@withContext false
        try {
            val outputStream: OutputStream = socket.outputStream
            
            // ESC/POS Initialization
            outputStream.write(byteArrayOf(0x1B, 0x40)) // ESC @ (Init)
            
            val width = bitmap.width
            val height = bitmap.height
            val widthBytes = (width + 7) / 8
            
            // GS v 0 m xL xH yL yH d1...dk
            // m = 0 (Normal mode), xL, xH specifies width bytes, yL, yH specifies height pixels
            val xL = (widthBytes and 0xFF).toByte()
            val xH = ((widthBytes ushr 8) and 0xFF).toByte()
            val yL = (height and 0xFF).toByte()
            val yH = ((height ushr 8) and 0xFF).toByte()
            
            val header = byteArrayOf(0x1D, 0x76, 0x30, 0x00, xL, xH, yL, yH)
            outputStream.write(header)
            
            // Build the pixel byte data
            val bytes = ByteArray(widthBytes * height)
            var byteIdx = 0
            
            for (y in 0 until height) {
                for (xb in 0 until widthBytes) {
                    var byteVal = 0
                    for (b in 0 until 8) {
                        val x = xb * 8 + b
                        if (x < width) {
                            val pixel = bitmap.getPixel(x, y)
                            val r = (pixel shr 16) and 0xFF
                            val g = (pixel shr 8) and 0xFF
                            val bVal = pixel and 0xFF
                            val gray = (r * 0.3 + g * 0.59 + bVal * 0.11).toInt()
                            
                            // If pixel is dark enough, count as black (1), else white (0)
                            if (gray < 160) {
                                byteVal = byteVal or (1 shl (7 - b))
                            }
                        }
                    }
                    bytes[byteIdx++] = byteVal.toByte()
                }
            }
            
            outputStream.write(bytes)
            
            // Feed paper and cut (or space)
            outputStream.write(byteArrayOf(0x1B, 0x64, 0x04)) // Feed 4 lines
            outputStream.flush()
            return@withContext true
        } catch (e: Exception) {
            Log.e("PrintManager", "Error printing bitmap to device", e)
            return@withContext false
        }
    }
}

// Data holder for cart items
data class CartItem(
    val id: Int,
    val name: String,
    val price: Long,
    val quantity: Int
)
